#import "FoundationMinimal.h"

/* rh8.3 - built-in cleanup extension.
 *
 * The two source packages each carried their own rule list:
 *   - iCleaner Pro's built-in steps are compiled blocks. Their coverage was
 *     read out of the shipped binary (cleanLogFiles / cleanTempFiles /
 *     cleanCacheFiles / cleanApplications) and is listed in the README.
 *   - Cleaner 1.0.0 (com.yg.cleaner) keeps its rule table inside its daemon.
 *
 * Everything the built-in steps already delete is left alone here, so the
 * same path is never cleaned by two rules. Only the genuinely missing paths
 * are appended to the matching built-in step, using iCleaner's own
 * -delrAll: helper so test mode, backup handling and freed-space accounting
 * keep working exactly as for built-in items.
 */

static NSString * const ICRBuiltinCleanupVersion = @"2026.11.22.rh8.4";

/* ICCore owns the deletion helpers; declared here because the package does
 * not ship iCleaner's headers. */
@interface ICCore : NSObject
- (void)del:(NSString *)path;
- (void)delr:(NSString *)path;
- (void)delAll:(NSString *)path;
- (void)delrAll:(NSString *)path;
- (void)cleanLogFiles;
- (void)cleanTempFiles;
- (void)cleanCacheFiles;
- (void)cleanApplications;
@end

static IMP ICRLogFilesIMP = NULL;
static IMP ICRTempFilesIMP = NULL;
static IMP ICRCacheFilesIMP = NULL;
static IMP ICRApplicationsIMP = NULL;
static BOOL ICRBuiltinInstalled = NO;

static BOOL ICRIsDirectory(NSString *path) {
    BOOL directory = NO;
    NSFileManager *fm = [NSFileManager defaultManager];
    [fm fileExistsAtPath:path isDirectory:&directory];
    return directory;
}

/* Deletes the contents of an existing directory and keeps the directory
 * itself, matching how the built-in steps treat /var/mobile/Library/Logs. */
static void ICRClearDirectory(id core, NSString *path) {
    if (!path || !ICRIsDirectory(path)) return;
    @try {
        [core delrAll:path];
    } @catch (NSException *ignored) {
        /* A single unreadable directory must not abort the whole step. */
    }
}

/* Documents/Inbox carries received .deb/.dylib/.zip payloads. The built-in
 * steps do not look at Inbox at all, so the extension list comes from the
 * previous custom-rule set. Files only, one entry at a time, so a directory
 * named like a payload is never matched. */
static void ICRClearInbox(id core, NSString *container) {
    NSString *inbox = [container stringByAppendingPathComponent:@"Documents/Inbox"];
    if (!ICRIsDirectory(inbox)) return;
    NSArray *allowed = @[@".deb", @".dylib", @".zip", @".ipa", @".tipa", @".ipcc", @".png"];
    NSArray *names = nil;
    @try {
        names = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:inbox error:NULL];
    } @catch (NSException *ignored) {
        return;
    }
    for (NSUInteger i = 0; i < [names count]; i++) {
        NSString *name = [names objectAtIndex:i];
        for (NSUInteger j = 0; j < [allowed count]; j++) {
            if (![name hasSuffix:[allowed objectAtIndex:j]]) continue;
            @try {
                [core del:[inbox stringByAppendingPathComponent:name]];
            } @catch (NSException *ignored) {
                /* Skip the entry and keep going. */
            }
            break;
        }
    }
}

static void ICRCleanApplicationExtras(id core) {
    /* -cleanApp: already runs -cleanGenericDataContainer on the app data
     * container, on every app-group container and on every plugin container,
     * which covers ./Library/Caches, ./tmp, ./Library/Saved Application State
     * and ./Library/SplashBoard. Only the two things it does not touch are
     * added here. */
    NSString *apps = @"/var/mobile/Containers/Data/Application";
    if (!ICRIsDirectory(apps)) return;
    NSArray *names = nil;
    @try {
        names = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:apps error:NULL];
    } @catch (NSException *ignored) {
        names = nil;
    }
    for (NSUInteger i = 0; i < [names count]; i++) {
        NSString *container = [apps stringByAppendingPathComponent:[names objectAtIndex:i]];
        if (!ICRIsDirectory(container)) continue;
        ICRClearDirectory(core, [container stringByAppendingPathComponent:@"Library/HTTPStorages"]);
        ICRClearInbox(core, container);
    }
}

static id ICRHookLogFiles(id self, SEL _cmd, ...) {
    ICRLogFilesIMP(self, _cmd);
    /* /var/log, /var/logs, /var/mobile/Library/Logs (recursive) and
     * /var/wireless/Library/Logs are already built in. */
    ICRClearDirectory(self, @"/Library/Logs/CrashReporter");
    return nil;
}

static id ICRHookTempFiles(id self, SEL _cmd, ...) {
    ICRTempFilesIMP(self, _cmd);
    /* /var/tmp is already built in. */
    ICRClearDirectory(self, @"/tmp");
    ICRClearDirectory(self, @"/var/mobile/tmp");
    return nil;
}

static id ICRHookCacheFiles(id self, SEL _cmd, ...) {
    ICRCacheFilesIMP(self, _cmd);
    /* /var/mobile/Library/Caches and per-container Library/Caches are already
     * built in. The /var/db diagnostics children stay as before: the parent
     * /var/db/diagnostics is deliberately not cleaned as a whole. */
    ICRClearDirectory(self, @"/var/db/uuidtext");
    ICRClearDirectory(self, @"/var/db/diagnostics/Persist");
    ICRClearDirectory(self, @"/var/db/diagnostics/Signpost");
    ICRClearDirectory(self, @"/var/db/diagnostics/Special");
    ICRClearDirectory(self, @"/var/db/analyticsd");
    ICRClearDirectory(self, @"/var/db/powerlog");
    ICRClearDirectory(self, @"/var/mobile/Media/PhotoData/Caches");
    ICRClearDirectory(self, @"/var/mobile/Media/PhotoData/Thumbnails");
    return nil;
}

static id ICRHookApplications(id self, SEL _cmd, ...) {
    ICRApplicationsIMP(self, _cmd);
    ICRCleanApplicationExtras(self);
    return nil;
}

void ICRInstallBuiltinCleanup(void) {
    if (ICRBuiltinInstalled) return;
    Class core = NSClassFromString(@"ICCore");
    if (!core) return;
    Method method = NULL;
    method = class_getInstanceMethod(core, @selector(cleanLogFiles));
    if (method) ICRLogFilesIMP = method_setImplementation(method, (IMP)ICRHookLogFiles);
    method = class_getInstanceMethod(core, @selector(cleanTempFiles));
    if (method) ICRTempFilesIMP = method_setImplementation(method, (IMP)ICRHookTempFiles);
    method = class_getInstanceMethod(core, @selector(cleanCacheFiles));
    if (method) ICRCacheFilesIMP = method_setImplementation(method, (IMP)ICRHookCacheFiles);
    method = class_getInstanceMethod(core, @selector(cleanApplications));
    if (method) ICRApplicationsIMP = method_setImplementation(method, (IMP)ICRHookApplications);
    ICRBuiltinInstalled = (ICRLogFilesIMP && ICRTempFilesIMP && ICRCacheFilesIMP && ICRApplicationsIMP);
}
