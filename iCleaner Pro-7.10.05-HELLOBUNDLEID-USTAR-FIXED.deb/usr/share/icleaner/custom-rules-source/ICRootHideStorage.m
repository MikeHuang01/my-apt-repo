﻿#import "ICRootHideStorage.h"
#ifdef ICR_HOST_TEST
#include <unistd.h>
#include <stdio.h>
#include <sys/file.h>
#include <fcntl.h>
#include <errno.h>
#else
/* Verified against roothide/libroothide's public C ABI. */
extern const char *jbroot(const char *path);
extern int rename(const char *from, const char *to);
extern int open(const char *path, int flags, ...);
extern int flock(int fd, int operation);
extern int close(int fd);
extern int unlink(const char *path);
extern int *__error(void);
#define errno (*__error())
#define LOCK_EX 2
#define LOCK_NB 4
#define LOCK_UN 8
#endif

static NSString *LegacyData = @"/var/mobile/Library/iCleaner";
static NSString *StoragePath;
static BOOL StorageAttempted;
static NSString *StorageFailure;
static id (*OriginalDataDir)(id, SEL);
static BOOL (*OriginalCreateDirectory)(id, SEL, NSString *, BOOL, NSDictionary *, NSError **);
static BOOL (*OriginalStringWrite)(id, SEL, NSString *, BOOL, NSUInteger, NSError **);
static id (*OriginalStringRead)(id, SEL, NSString *, NSUInteger, NSError **);
static BOOL LegacyWritersReady;

static BOOL Fail(NSString *reason) {
    StorageFailure = reason;
    return NO;
}

static NSString *Resolved(NSString *path) {
    return [[path stringByStandardizingPath] stringByResolvingSymlinksInPath];
}

static BOOL Inside(NSString *path, NSString *parent) {
    return [Resolved(path) hasPrefix:[NSString stringWithFormat:@"%@/", Resolved(parent)]];
}

static NSString *JailbreakPath(const char *relative) {
    const char *path = jbroot(relative);
    return path ? [NSString stringWithUTF8String:path] : nil;
}

NSString *ICRActiveJailbreakRoot(void) {
    NSString *root = JailbreakPath("/");
    if (![root length]) return nil;
    root = Resolved(root);
    /* Reject rootful/rootless no-op stubs, rather than silently writing to iOS. */
    if ([root isEqualToString:@"/"] || [root isEqualToString:@"/var/jb"] ||
        [root isEqualToString:@"/var"] || [root isEqualToString:@"/private/var"]) return nil;
    return root;
}

static BOOL Directory(NSFileManager *fm, NSString *path) {
    return [[[fm attributesOfItemAtPath:path error:NULL] objectForKey:NSFileType] isEqualToString:NSFileTypeDirectory];
}

/* Validate all descendants before a recursive copy or comparison. Never follow
 * source symlinks or copy special files, and keep migration work bounded. */
static BOOL PlainTree(NSFileManager *fm, NSString *root) {
    NSMutableArray *queue = [NSMutableArray array];
    [queue addObject:root];
    for (NSUInteger i = 0; i < [queue count]; i++) {
        NSString *path = [queue objectAtIndex:i];
        NSString *type = [[fm attributesOfItemAtPath:path error:NULL] objectForKey:NSFileType];
        if ([type isEqualToString:NSFileTypeRegular]) continue;
        if (![type isEqualToString:NSFileTypeDirectory]) return NO;
        NSArray *children = [fm contentsOfDirectoryAtPath:path error:NULL];
        if (!children || [children count] + [queue count] > 20000) return NO;
        for (NSUInteger j = 0; j < [children count]; j++) {
            NSString *p = [path stringByAppendingPathComponent:[children objectAtIndex:j]];
            if (!Inside(p, root) || [[[p substringFromIndex:[root length]] componentsSeparatedByString:@"/"] count] > 32) return NO;
            [queue addObject:p];
        }
    }
    return YES;
}

static BOOL EqualTree(NSFileManager *fm, NSString *a, NSString *b) {
    return PlainTree(fm, a) && PlainTree(fm, b) && [fm contentsEqualAtPath:a andPath:b];
}

static BOOL Missing(NSError *error) {
    return ([[error domain] isEqualToString:NSCocoaErrorDomain] && ([error code] == 4 || [error code] == 260)) ||
           ([[error domain] isEqualToString:NSPOSIXErrorDomain] && [error code] == 2);
}

/* A component may run before our constructor on a later launch and recreate
 * just license.cached. An identical SUBSET is safe to retire without replacing
 * the fuller active Data tree. Differing content still fails closed. */
static BOOL ContainedTree(NSFileManager *fm, NSString *source, NSString *data) {
    if (!PlainTree(fm, source) || !PlainTree(fm, data)) return NO;
    NSMutableArray *queue = [NSMutableArray array];
    [queue addObject:@""];
    for (NSUInteger i = 0; i < [queue count]; i++) {
        NSString *suffix = [queue objectAtIndex:i];
        NSString *a = [suffix length] ? [source stringByAppendingPathComponent:suffix] : source;
        NSString *b = [suffix length] ? [data stringByAppendingPathComponent:suffix] : data;
        if (Directory(fm, a)) {
            if (!Directory(fm, b)) return NO;
            NSArray *children = [fm contentsOfDirectoryAtPath:a error:NULL];
            if (!children) return NO;
            for (NSUInteger j = 0; j < [children count]; j++)
                [queue addObject:[suffix stringByAppendingPathComponent:[children objectAtIndex:j]]];
        } else if (![fm contentsEqualAtPath:a andPath:b]) return NO;
    }
    return YES;
}

static NSString *UnusedArchive(NSFileManager *fm, NSString *base, NSString *name) {
    for (NSUInteger i = 0; i < 10000; i++) {
        NSString *leaf = i ? [NSString stringWithFormat:@"%@-%lu", name, i] : name;
        NSString *path = [base stringByAppendingPathComponent:leaf];
        NSError *error = nil;
        if (![fm attributesOfItemAtPath:path error:&error]) {
            if (Missing(error)) return path;
            return nil;
        }
    }
    return nil;
}

static BOOL ProbeData(NSString *data) {
    /* Exclusively create an empty probe; never overwrite or remove an existing
     * file. Keep Data identical to the source after checking writability. */
    for (NSUInteger i = 0; i < 64; i++) {
        NSString *path = [data stringByAppendingPathComponent:[NSString stringWithFormat:@".rh3-write-probe-%lu", i]];
#ifdef ICR_HOST_TEST
        int flags = O_CREAT | O_EXCL | O_RDWR | O_NOFOLLOW;
#else
        int flags = 0x200 | 0x800 | 2 | 0x100;
#endif
        int fd = open([path fileSystemRepresentation], flags, 0600);
        if (fd < 0) continue;
        int closed = close(fd);
        int removed = unlink([path fileSystemRepresentation]);
        return (!closed && !removed) || Fail(@"write-probe-cleanup-failed");
    }
    return Fail(@"data-not-writable-or-probe-names-occupied");
}

/* No source removal occurs until both the live copy and hidden archive have
 * been compared. If something is unfamiliar, fall back without deleting it. */
static BOOL __attribute__((unused)) Migrate(NSFileManager *fm, NSString *source, NSString *base) {
    StorageFailure = nil;
    NSString *data = [base stringByAppendingPathComponent:@"Data"];
    NSString *stage = [base stringByAppendingPathComponent:@"Migration.pending"];
    NSString *archive = [base stringByAppendingPathComponent:@"LegacyData"];
    NSError *sourceError = nil, *dataError = nil;
    NSDictionary *s = [fm attributesOfItemAtPath:source error:&sourceError];
    NSDictionary *d = [fm attributesOfItemAtPath:data error:&dataError];
    /* Permission/I/O errors must not masquerade as a fresh installation. */
    if ((!s && !Missing(sourceError)) || (!d && !Missing(dataError))) return Fail(@"source-or-destination-unreadable");
    if (!s) {
        if (d && !Directory(fm, data)) return Fail(@"destination-not-plain-directory");
        if (!d && ![fm createDirectoryAtPath:data withIntermediateDirectories:NO attributes:nil error:NULL]) return Fail(@"create-data-directory-failed");
        return ProbeData(data);
    }
    if (!Directory(fm, source) || !PlainTree(fm, source)) return Fail(@"source-has-link-special-file-or-scan-limit");
    if (d && !Directory(fm, data)) return Fail(@"destination-not-plain-directory");
    /* An existing live directory must never be overwritten or merged
     * speculatively. The archived old tree makes repeated starts idempotent. */
    if (d && !EqualTree(fm, source, data) && !EqualTree(fm, source, archive) &&
        !ContainedTree(fm, source, data)) return Fail(@"existing-data-conflict-preserved-both");
    if (!d) {
        if ([fm attributesOfItemAtPath:stage error:NULL]) {
            if (!EqualTree(fm, source, stage)) return Fail(@"incomplete-or-conflicting-stage-preserved");
        } else if (![fm copyItemAtPath:source toPath:stage error:NULL]) return Fail(@"copy-to-stage-failed");
        if (!EqualTree(fm, source, stage)) return Fail(@"stage-verification-failed");
        /* rename is atomic; unlike moveItemAtPath it cannot silently perform
         * a cross-filesystem copy-and-delete. Both paths share this parent. */
        if (rename([stage fileSystemRepresentation], [data fileSystemRepresentation])) return Fail([NSString stringWithFormat:@"activate-stage-errno-%d", errno]);
    }
    if (!EqualTree(fm, source, archive)) {
        archive = UnusedArchive(fm, base, @"LegacyData");
        if (!archive) return Fail(@"no-safe-archive-slot");
        if (![fm copyItemAtPath:source toPath:archive error:NULL]) return Fail(@"copy-to-archive-failed");
    }
    if (!EqualTree(fm, source, archive)) return Fail(@"archive-verification-failed");
    if (!ProbeData(data)) return NO;
    /* Archive before retirement: if the move is not atomic on this volume,
     * preserve the old tree and keep the original app working. */
    NSString *retired = UnusedArchive(fm, base, @"LegacyData.retired");
    if (!retired) return Fail(@"no-safe-retirement-slot");
    if (!EqualTree(fm, source, archive)) return Fail(@"source-changed-before-retirement");
    if (rename([source fileSystemRepresentation], [retired fileSystemRepresentation])) return Fail([NSString stringWithFormat:@"retire-source-errno-%d", errno]);
    /* Do not delete even this redundant tree. No recursive removal is used. */
    return YES;
}

/* Older builds recreated a symlink for the preference plist inside this very
 * data directory. PlainTree rejects link and special entries, so such a tree
 * could never be consolidated: every launch failed closed and the app kept
 * writing to /var. Move each of those entries into Backups/links/<label>/ first.
 * The object itself is moved, so nothing is copied, rewritten or deleted, and
 * the source tree becomes plain so the normal verified merge can proceed. */
static BOOL QuarantineNonPlain(NSFileManager *fm, NSString *source, NSString *base, NSString *label) {
    NSError *error = nil;
    NSDictionary *attributes = [fm attributesOfItemAtPath:source error:&error];
    if (!attributes) return Missing(error) || Fail(@"quarantine-source-unreadable");
    if (!Directory(fm, source)) return Fail(@"source-root-is-link-or-special-preserved");
    NSString *root = [base stringByAppendingPathComponent:@"Backups/links"];
    if (![fm createDirectoryAtPath:root withIntermediateDirectories:YES attributes:nil error:NULL])
        return Fail(@"quarantine-directory-unavailable");
    NSMutableArray *queue = [NSMutableArray array];
    [queue addObject:@""];
    NSMutableArray *links = [NSMutableArray array];
    for (NSUInteger i = 0; i < [queue count]; i++) {
        NSString *suffix = [queue objectAtIndex:i];
        if ([[suffix componentsSeparatedByString:@"/"] count] > 32 || [queue count] > 20000)
            return Fail(@"quarantine-scan-limit");
        NSString *path = [suffix length] ? [source stringByAppendingPathComponent:suffix] : source;
        NSString *type = [[fm attributesOfItemAtPath:path error:NULL] objectForKey:NSFileType];
        if ([type isEqualToString:NSFileTypeRegular]) continue;
        if (![type isEqualToString:NSFileTypeDirectory]) {
            if (![suffix length]) return Fail(@"source-root-is-link-or-special-preserved");
            [links addObject:suffix];
            continue;
        }
        NSArray *children = [fm contentsOfDirectoryAtPath:path error:NULL];
        if (!children || [children count] + [queue count] > 20000)
            return Fail(@"quarantine-scan-limit");
        for (NSUInteger j = 0; j < [children count]; j++)
            [queue addObject:[suffix stringByAppendingPathComponent:[children objectAtIndex:j]]];
    }
    if (![links count]) return YES;
    NSString *slot = UnusedArchive(fm, root, label);
    if (!slot) return Fail(@"no-safe-quarantine-slot");
    for (NSUInteger i = 0; i < [links count]; i++) {
        NSString *suffix = [links objectAtIndex:i];
        NSString *from = [source stringByAppendingPathComponent:suffix];
        NSString *to = [slot stringByAppendingPathComponent:suffix];
        if (![fm createDirectoryAtPath:[to stringByDeletingLastPathComponent]
            withIntermediateDirectories:YES attributes:nil error:NULL])
            return Fail(@"quarantine-parent-unavailable");
        if (!rename([from fileSystemRepresentation], [to fileSystemRepresentation])) continue;
        /* A different volume refuses rename. Only a symlink can then be
         * recreated and verified exactly; every other type stays in place. */
        NSString *type = [[fm attributesOfItemAtPath:from error:NULL] objectForKey:NSFileType];
        if (![type isEqualToString:NSFileTypeSymbolicLink])
            return Fail(@"quarantine-special-file-cross-volume-preserved");
        NSString *destination = [fm destinationOfSymbolicLinkAtPath:from error:NULL];
        if (![destination length]) return Fail(@"quarantine-link-unreadable-preserved");
        if (![fm createSymbolicLinkAtPath:to withDestinationPath:destination error:NULL])
            return Fail(@"quarantine-link-recreate-failed");
        if (![[fm destinationOfSymbolicLinkAtPath:to error:NULL] isEqualToString:destination])
            return Fail(@"quarantine-link-verification-failed");
        if (unlink([from fileSystemRepresentation]))
            return Fail(@"quarantine-link-source-unlink-failed");
    }
    return YES;
}

#include "ICRootHideMerge.inc"

NSString *ICRStatusDirectory(void) {
    NSString *root = ICRActiveJailbreakRoot();
    if (![root length]) return nil;
    NSString *base = JailbreakPath("/Library/iCleanerRootHide");
    NSString *expected = [root stringByAppendingPathComponent:@"Library/iCleanerRootHide"];
    if (![base length] || !Inside(base, root) || ![Resolved(base) isEqualToString:expected]) return nil;
    NSFileManager *fm = [NSFileManager defaultManager];
    if (![fm attributesOfItemAtPath:base error:NULL] &&
        ![fm createDirectoryAtPath:base withIntermediateDirectories:YES attributes:nil error:NULL]) return nil;
    return Directory(fm, base) ? base : nil;
}

NSString *ICRStateDirectory(void) {
    @synchronized([NSFileManager class]) {
        if (StoragePath) return StoragePath;
        if (MergeBusy) return nil;
        if (StorageAttempted) return nil;
        NSFileManager *fm = [NSFileManager defaultManager];
        NSString *root = ICRActiveJailbreakRoot();
        NSString *base = JailbreakPath("/Library/iCleanerRootHide");
        /* RootHide's /var can resolve into its SECONDARY AppGroup root. This
         * user explicitly wants the PRIMARY Bundle/Application root instead.
         * Reject symlinked Library/base directories, including in-root aliases. */
        NSString *expected = [root stringByAppendingPathComponent:@"Library/iCleanerRootHide"];
        if (![root length] || ![base length] || !Inside(base, root) || Inside(base, LegacyData) ||
            ![Resolved(base) isEqualToString:expected]) return nil;
        NSString *library = [root stringByAppendingPathComponent:@"Library"];
        if ([fm attributesOfItemAtPath:library error:NULL] && !Directory(fm, library)) return nil;
        if (![fm createDirectoryAtPath:base withIntermediateDirectories:YES attributes:nil error:NULL] || !Directory(fm, base)) return nil;
        /* These Darwin constants are deliberately not shared with host tests. */
#ifdef ICR_HOST_TEST
        int flags = O_CREAT | O_RDWR | O_NOFOLLOW;
#else
        int flags = 0x200 | 2 | 0x100; /* O_CREAT | O_RDWR | O_NOFOLLOW */
#endif
        int fd = open([[base stringByAppendingPathComponent:@"migration.lock"] fileSystemRepresentation], flags, 0600);
        if (fd < 0) return nil;
        if (flock(fd, LOCK_EX | LOCK_NB)) { close(fd); return nil; }
        StorageAttempted = YES;
        MergeBusy = YES;
        BOOL ok = NO;
        NSString *source = LegacyData;
        @try {
            NSString *data = [base stringByAppendingPathComponent:@"Data"];
            StorageFailure = nil;
            ok = ConsolidateStorage(fm, base);
            MergeRemaining = MergeCountRemaining(fm, base);
            if (ok) StoragePath = data;
            /* Consolidation probes the live directory before source retirement. */
            NSDictionary *status = @{@"version":@"2026.11.18.rh8", @"date":[NSDate date],
                @"success":[NSNumber numberWithBool:ok && !MergeRemaining], @"legacySource":LegacyData,
                @"primaryDataActive":[NSNumber numberWithBool:ok],
                @"migrationSource":source, @"failureReason":StorageFailure ?: @"",
                @"activeRoot":root, @"dataDirectory":data, @"primaryRootStorage":@YES,
                @"ownedLegacyWritersRedirected":[NSNumber numberWithBool:LegacyWritersReady],
                @"mergeConflictsArchived":[NSNumber numberWithUnsignedInteger:MergeConflicts],
                @"legacyDirectoriesRemaining":[NSNumber numberWithUnsignedInteger:MergeRemaining],
                @"linkEntriesQuarantined":[NSNumber numberWithUnsignedInteger:
                    [[fm contentsOfDirectoryAtPath:[base stringByAppendingPathComponent:@"Backups/links"] error:NULL] count]],
                @"mergeRecords":MergeRecords ?: @[],
                @"preferencesStatusFile":@"preferences-migration-status.plist",
                @"nativeTestBackupsRelocated":@NO};
            /* Migration already probes before retiring a source. A status
             * reporting failure must not undo an otherwise successful switch. */
            [status writeToFile:[base stringByAppendingPathComponent:@"storage-migration-status.plist"] atomically:YES];
        } @catch (NSException *ignored) {
            /* No exception from a storage hook is allowed to break the app. */
        } @finally {
            MergeBusy = NO;
            flock(fd, LOCK_UN);
            close(fd);
        }
        return StoragePath;
    }
}

/* Only this app's OWNED directory is mapped, never general /var paths or
 * arbitrary cleaning targets. Standardize before matching so ../ escapes do
 * not acquire hidden-root privileges. No symlink is left at the legacy path. */
NSString *ICRRedirectOwnedDataPath(NSString *path) {
    if (![path isKindOfClass:[NSString class]]) return path;
    if (MergeBusy) return path;
    NSString *normalized = [path stringByStandardizingPath];
    NSString *legacy = [LegacyData stringByStandardizingPath];
    NSString *suffix = nil;
    if ([normalized isEqualToString:legacy]) suffix = @"";
    else if ([normalized hasPrefix:[NSString stringWithFormat:@"%@/", legacy]])
        suffix = [normalized substringFromIndex:[legacy length] + 1];
    if (!suffix && [legacy isEqualToString:@"/var/mobile/Library/iCleaner"]) {
        NSString *alias = @"/private/var/mobile/Library/iCleaner";
        if ([normalized isEqualToString:alias]) suffix = @"";
        else if ([normalized hasPrefix:[NSString stringWithFormat:@"%@/", alias]])
            suffix = [normalized substringFromIndex:[alias length] + 1];
    }
    NSString *stateSuffix = nil;
    if (!suffix) {
        NSString *hiddenData = JailbreakPath("/var/mobile/Library/iCleaner");
        NSString *hiddenState = JailbreakPath("/var/mobile/Library/iCleanerRootHide");
        if ([hiddenData length] && [hiddenState length]) {
            NSArray *aliases = @[hiddenData, PhysicalLeaf(hiddenData), hiddenState, PhysicalLeaf(hiddenState)];
            for (NSUInteger i = 0; i < [aliases count]; i++) {
                NSString *alias = [[aliases objectAtIndex:i] stringByStandardizingPath];
                BOOL exact = [normalized isEqualToString:alias];
                if (!exact && ![normalized hasPrefix:[NSString stringWithFormat:@"%@/",alias]]) continue;
                NSString *tail = exact ? @"" : [normalized substringFromIndex:[alias length]+1];
                if (i < 2) suffix = tail; else stateSuffix = tail;
                break;
            }
        }
    }
    if (!suffix && !stateSuffix) return path;
    NSString *destination = ICRStateDirectory();
    if (!destination) return path; /* preserve the working old app on failure */
    if (stateSuffix) {
        NSString *base = [destination stringByDeletingLastPathComponent];
        return [stateSuffix length] ? [base stringByAppendingPathComponent:stateSuffix] : base;
    }
    return [suffix length] ? [destination stringByAppendingPathComponent:suffix] : destination;
}

static BOOL HookCreateDirectory(id self, SEL cmd, NSString *path, BOOL intermediate, NSDictionary *attributes, NSError **error) {
    return OriginalCreateDirectory(self, cmd, ICRRedirectOwnedDataPath(path), intermediate, attributes, error);
}

static BOOL HookStringWrite(id self, SEL cmd, NSString *path, BOOL atomic, NSUInteger encoding, NSError **error) {
    return OriginalStringWrite(self, cmd, ICRRedirectOwnedDataPath(path), atomic, encoding, error);
}

static id HookStringRead(id self, SEL cmd, NSString *path, NSUInteger encoding, NSError **error) {
    return OriginalStringRead(self, cmd, ICRRedirectOwnedDataPath(path), encoding, error);
}

static id HookDataDir(id self, SEL cmd) {
    return ICRStateDirectory() ?: OriginalDataDir(self, cmd);
}

void ICRInstallRootHideStorage(void) {
#if !defined(ICR_HOST_TEST) || defined(ICR_TEST_RUNTIME_HOOKS)
    Method method = class_getClassMethod(NSClassFromString(@"ICPathLocator"), @selector(appDataDir));
    if (method && !OriginalDataDir) OriginalDataDir = (void *)method_setImplementation(method, (IMP)HookDataDir);
    /* The bundled extra component bypasses ICPathLocator and creates the old
     * directory + writes license.cached through these Foundation methods.
     * Forward paths only: do not modify file contents or license decisions. */
    Method create = class_getInstanceMethod([NSFileManager class], @selector(createDirectoryAtPath:withIntermediateDirectories:attributes:error:));
    Method write = class_getInstanceMethod([NSString class], @selector(writeToFile:atomically:encoding:error:));
    Method read = class_getClassMethod([NSString class], @selector(stringWithContentsOfFile:encoding:error:));
    if (create && !OriginalCreateDirectory) OriginalCreateDirectory = (void *)method_setImplementation(create, (IMP)(void *)HookCreateDirectory);
    if (write && !OriginalStringWrite) OriginalStringWrite = (void *)method_setImplementation(write, (IMP)(void *)HookStringWrite);
    if (read && !OriginalStringRead) OriginalStringRead = (void *)method_setImplementation(read, (IMP)HookStringRead);
    LegacyWritersReady = OriginalCreateDirectory && OriginalStringWrite;
#endif
}
