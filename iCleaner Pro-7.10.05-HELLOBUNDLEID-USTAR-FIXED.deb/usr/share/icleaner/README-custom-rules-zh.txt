iCleaner Pro — RootHide 主隐根统一存储 rh8.3（内置规则合并版）
版本：7.10.0+customrules.4.rh8.3；包标识：com.sini.icleanerpro
仅用于 Dopamine RootHide，依赖 rootless-compat >= 0.9，最低 iOS 15。
请在现有 RootHide 环境直接升级，不要再次 RootHidePatcher 转换。

【rh8.3 改了什么：两个包的清理规则并入 iCleaner 内置步骤】

rh8.2 之前，本包把清理规则作为"自定义文件夹(CUSTOMFILES)"导入。
rh8.3 改为：规则直接并入 iCleaner 的内置清理步骤（缓存文件/临时文件/
日志文件/应用程序），"自定义文件夹"里不再出现这批条目，因此同一个路径
不会被两条规则各清一次。

一、内置步骤原本清理什么（从 iCleaner 7.10.0 主程序静态读取，作为去重依据）
  · 日志步骤 -cleanLogFiles：/var/log、/var/logs、
    /var/mobile/Library/Logs（递归，已覆盖其下 CrashReporter 与
    DiagnosticReports）、/var/wireless/Library/Logs
  · 临时文件 -cleanTempFiles：/var/tmp、/var/mobile/Media/ApplicationArchives、
    /var/spool/mdt，以及若干固定文件名
  · 缓存文件 -cleanCacheFiles：/var/mobile/Library/Caches、/var/root/Library/Caches、
    每个 App 容器的 Library/Caches、/var/lib/apt/lists/partial，以及大量
    具名缓存条目
  · 应用程序 -cleanApplications：对每个 App 数据容器，以及该 App 的
    groupDataContainers 与 pluginDataContainers，调用 -cleanGenericDataContainer，
    其中清理 ./Library/Caches、./tmp、./Library/Saved Application State、
    ./Library/SplashBoard、./Library/WebKit/*、./Library/FlurryFiles 等

二、本次补进内置步骤的路径（只补内置没覆盖的，已去重）

  日志步骤（-cleanLogFiles 之后追加）
    /Library/Logs/CrashReporter

  临时文件（-cleanTempFiles 之后追加）
    /tmp、/var/mobile/tmp

  缓存文件（-cleanCacheFiles 之后追加）
    /var/db/uuidtext
    /var/db/diagnostics/Persist
    /var/db/diagnostics/Signpost
    /var/db/diagnostics/Special
    /var/db/analyticsd
    /var/db/powerlog
    /var/mobile/Media/PhotoData/Caches
    /var/mobile/Media/PhotoData/Thumbnails

  应用程序（-cleanApplications 之后追加）
    每个 App 容器：Library/HTTPStorages、Documents/Inbox 内指定扩展名文件
    （.deb/.dylib/.zip/.ipa/.tipa/.ipcc/.png，仅文件，不含目录）

  全部调用 iCleaner 自带的 -delrAll: / -del: 删除，因此测试模式(只统计不删)、
  备份与"已释放空间"计数与内置条目完全一致。

三、被判为重复而**没有**新增的规则（内置已覆盖）
    /var/mobile/Library/Caches          内置缓存步骤
    /var/log                            内置日志步骤
    /var/mobile/Library/Logs            内置日志步骤（递归）
    /var/mobile/Library/Logs/CrashReporter    内置日志步骤（父目录递归覆盖）
    /var/mobile/Library/Logs/DiagnosticReports 内置日志步骤（父目录递归覆盖）
    /var/tmp                            内置临时文件步骤
    各 App 的 Library/Caches           内置缓存/应用程序步骤
    各 App 的 tmp                       内置应用程序步骤
    各 App 的 Library/Saved Application State  内置应用程序步骤
    各 App 的 Library/SplashBoard       内置应用程序步骤
    扩展容器 PluginKitPlugin/<id>/Library/Caches   内置应用程序步骤
        （-cleanApp: 会对 pluginDataContainers 逐个调用
         -cleanGenericDataContainer，其中已含 ./Library/Caches）
    共享容器 Shared/AppGroup/<id>/Library/Caches   内置应用程序步骤
        （同上，groupDataContainers 路径已覆盖）

四、没有合并的一项，及原因
    Cleaner 1.0.0 的 sys.residue（卸载残留）需要先判断哪些数据容器属于"已卸载
    应用"（读 MCM 元数据并与已安装应用列表比对）。iCleaner 的内置应用程序步骤
    只遍历已安装应用，盲目清理未知容器可能删掉正在使用的应用数据，因此本包
    没有加入该条，也没有用近似规则替代。

五、偏好与存储
    存储迁移（rh8 的 /var 残留、符号链接隔离、主隐根统一）保持原样。
    升级后 custom-rules-status.plist 新增：
      retiredManagedRules      本次从自定义文件夹移除的旧托管规则条数
      builtinExtensionInstalled 内置扩展是否已挂钩（true）
      cleanupStepEnabled       固定为 false（自定义步骤不再启用）
    ICCustomRules.original 备份与 CustomRulesBackup 目录照旧保留。

【设备验收（仍未在手机上执行）】
1. 覆盖安装 rh8.3 后打开 iCleaner，"自定义文件夹"里不应再出现 uuidtext、
   diagnostics、Caches、Inbox 这批旧条目（用户自己写的规则不受影响）。
2. 主隐根 Library/iCleanerRootHide/custom-rules-status.plist 应为
   version=2026.11.22.rh8.3、success=true、retiredManagedRules>=0、
   builtinExtensionInstalled=true、cleanupStepEnabled=false。
3. 勾选"日志文件/临时文件/缓存文件/应用程序"四个步骤执行分析，再清理：
   /var/db/uuidtext、/var/db/diagnostics/Persist、PhotoData/Thumbnails、
   /var/mobile/tmp 的体积应计入对应步骤的释放量。
4. 测试模式下不应真正删除，只统计。

【验证边界】
本次修改完成了：源码修补、iOS 交叉编译、Mach-O 结构与加载项对比、
代码签名 superblob 检查、字符串级差异审计。未连接 iPhone，内置步骤在
真机上的实际执行仍需按上面 4 步确认。

【回退】
退出软件，备份整个主隐根 Library/iCleanerRootHide，再安装已知可用的旧包。
