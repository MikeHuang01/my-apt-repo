iCleaner Pro — RootHide 主隐根统一存储 rh8.4（内置规则合并版）
版本：7.10.0+customrules.4.rh8.4；包标识：com.sini.icleanerpro
仅用于 Dopamine RootHide，依赖 rootless-compat >= 0.9，最低 iOS 15。
请在现有 RootHide 环境直接升级，不要再次 RootHidePatcher 转换。

【rh8.4 修了什么：HelloBundleID 伪装后自定义设置里的规则全消失】

症状
  装上 HelloBundleID（cn.zqbb.hello.bundleid，1.6.2-6）并把 iCleaner 设为
  伪装对象后，iCleaner「自定义设置/自定义文件夹」里的规则、以及各清理步骤
  的勾选状态全部变回空/默认；把伪装关掉，它们又原样出现。

根因
  rh8 的偏好层用下面这一行决定"当前进程是不是 iCleaner"：
      if ([[[NSBundle mainBundle] bundleIdentifier] isEqualToString:PrefDomain])
  HelloBundleID 的 0HBIDHook.dylib 注入所有 UIKit 进程，hook 的正是
  -[NSBundle bundleIdentifier]。伪装开启后这行判定为假，
  InstallPreferenceEntryHooks() / InstallPreferences() 整套都不执行，
  于是 iCleaner 继续用"伪装后的 bundle id"那个空的 preferences 域，
  规则和步骤勾选自然全部读不到；关掉伪装，域恢复，数据又回来了。
  数据本身从未丢失，丢的是"去哪个域读"。

修法（rh8.4）
  新增 PrefOwnsThisBundle()：不再看运行时的 bundleIdentifier，改用两个
  伪装插件不会改的锚点——
    1) 主可执行文件路径以 /iCleaner.app/iCleaner（或 iCleaner_exe、
       iCleaner_launcher）结尾；
    2) 主 bundle 目录下的 Info.plist 文件里 CFBundleIdentifier 等于
       com.ivanobilenchi.icleaner（直接读磁盘文件，不走被 hook 的 API）。
  两者任一成立即安装偏好钩子。伪装开关从此与规则存储无关。

【以后加规则的强制约束（写进流程，避免同类问题复发）】
  1. 新清理规则只能加在 ICRBuiltinCleanup.m（挂到内置步骤），或走
     ICRootHidePreferences 这套 file-backed 偏好存储，不得另起一套读写。
  2. 任何判定"是否 iCleaner 进程/是否本应用的偏好域"的代码，禁止使用
     [[NSBundle mainBundle] bundleIdentifier]；必须用 PrefOwnsThisBundle()
     这类"可执行路径 / 磁盘 Info.plist"锚点，或 NSClassFromString 判定
     本应用独有的类。
  3. 规则、状态、备份的路径与键名不得由运行时 bundle id 拼接。
  4. 新增规则后必须复查：伪装开启与关闭两种状态下，规则列表、步骤勾选、
     custom-rules-status.plist 是否一致。

【rh8.3 改了什么：两个包的清理规则并入 iCleaner 内置步骤】

rh8.2 之前，本包把清理规则作为"自定义文件夹(CUSTOMFILES)"导入。
rh8.3 改为：规则直接并入 iCleaner 的内置清理步骤（缓存文件/临时文件/
日志文件/应用程序），"自定义文件夹"里不再出现这批条目，因此同一个路径
不会被两条规则各清一次。

一、内置步骤原本清理什么（从 iCleaner 7.10.0 主程序静态读取，作为去重依据）
  · 日志步骤 -cleanLogFiles：/var/log、/var/logs、
    /var/mobile/Library/Logs（递归，已覆盖其下 CrashReporter 与
    DiagnosticReports）、/var/wireless/Library/Logs
  · 临时文件 -cleanTempFiles：/var/tmp、/var/mobile/Media/ApplicationArchives、
    /var/spool/mdt，以及若干固定文件名
  · 缓存文件 -cleanCacheFiles：/var/mobile/Library/Caches、/var/root/Library/Caches、
    每个 App 容器的 Library/Caches、/var/lib/apt/lists/partial，以及大量
    具名缓存条目
  · 应用程序 -cleanApplications：对每个 App 数据容器，以及该 App 的
    groupDataContainers 与 pluginDataContainers，调用 -cleanGenericDataContainer，
    其中清理 ./Library/Caches、./tmp、./Library/Saved Application State、
    ./Library/SplashBoard、./Library/WebKit/*、./Library/FlurryFiles 等

二、本次补进内置步骤的路径（只补内置没覆盖的，已去重）

  日志步骤（-cleanLogFiles 之后追加）
    /Library/Logs/CrashReporter

  临时文件（-cleanTempFiles 之后追加）
    /tmp、/var/mobile/tmp

  缓存文件（-cleanCacheFiles 之后追加）
    /var/db/uuidtext
    /var/db/diagnostics/Persist
    /var/db/diagnostics/Signpost
    /var/db/diagnostics/Special
    /var/db/analyticsd
    /var/db/powerlog
    /var/mobile/Media/PhotoData/Caches
    /var/mobile/Media/PhotoData/Thumbnails

  应用程序（-cleanApplications 之后追加）
    每个 App 容器：Library/HTTPStorages、Documents/Inbox 内指定扩展名文件
    （.deb/.dylib/.zip/.ipa/.tipa/.ipcc/.png，仅文件，不含目录）

  全部调用 iCleaner 自带的 -delrAll: / -del: 删除，因此测试模式(只统计不删)、
  备份与"已释放空间"计数与内置条目完全一致。

三、被判为重复而**没有**新增的规则（内置已覆盖）
    /var/mobile/Library/Caches          内置缓存步骤
    /var/log                            内置日志步骤
    /var/mobile/Library/Logs            内置日志步骤（递归）
    /var/mobile/Library/Logs/CrashReporter    内置日志步骤（父目录递归覆盖）
    /var/mobile/Library/Logs/DiagnosticReports 内置日志步骤（父目录递归覆盖）
    /var/tmp                            内置临时文件步骤
    各 App 的 Library/Caches           内置缓存/应用程序步骤
    各 App 的 tmp                       内置应用程序步骤
    各 App 的 Library/Saved Application State  内置应用程序步骤
    各 App 的 Library/SplashBoard       内置应用程序步骤
    扩展容器 PluginKitPlugin/<id>/Library/Caches   内置应用程序步骤
        （-cleanApp: 会对 pluginDataContainers 逐个调用
         -cleanGenericDataContainer，其中已含 ./Library/Caches）
    共享容器 Shared/AppGroup/<id>/Library/Caches   内置应用程序步骤
        （同上，groupDataContainers 路径已覆盖）

四、没有合并的一项，及原因
    Cleaner 1.0.0 的 sys.residue（卸载残留）需要先判断哪些数据容器属于"已卸载
    应用"（读 MCM 元数据并与已安装应用列表比对）。iCleaner 的内置应用程序步骤
    只遍历已安装应用，盲目清理未知容器可能删掉正在使用的应用数据，因此本包
    没有加入该条，也没有用近似规则替代。

五、偏好与存储
    存储迁移（rh8 的 /var 残留、符号链接隔离、主隐根统一）保持原样。
    升级后 custom-rules-status.plist 新增：
      retiredManagedRules      本次从自定义文件夹移除的旧托管规则条数
      builtinExtensionInstalled 内置扩展是否已挂钩（true）
      cleanupStepEnabled       固定为 false（自定义步骤不再启用）
    ICCustomRules.original 备份与 CustomRulesBackup 目录照旧保留。

【设备验收（仍未在手机上执行）】
0. HelloBundleID 回归（rh8.4 重点，必须先过）：
   装上 HelloBundleID，把 iCleaner 设为伪装对象并 respring/重开，
   「自定义设置」里的规则与各清理步骤勾选必须和未伪装时完全一致；
   关掉伪装再开一次，仍要一致。status plist 里 preferenceDomain 相关
   失败原因不应出现 preference-* 类错误。
1. 覆盖安装 rh8.4 后打开 iCleaner，"自定义文件夹"里不应再出现 uuidtext、
   diagnostics、Caches、Inbox 这批旧条目（用户自己写的规则不受影响）。
2. 主隐根 Library/iCleanerRootHide/custom-rules-status.plist 应为
   version=2026.11.22.rh8.4、success=true、retiredManagedRules>=0、
   builtinExtensionInstalled=true、cleanupStepEnabled=false。
3. 勾选"日志文件/临时文件/缓存文件/应用程序"四个步骤执行分析，再清理：
   /var/db/uuidtext、/var/db/diagnostics/Persist、PhotoData/Thumbnails、
   /var/mobile/tmp 的体积应计入对应步骤的释放量。
4. 测试模式下不应真正删除，只统计。

【验证边界】
本次修改完成了：源码修补、iOS 交叉编译、Mach-O 结构与加载项对比、
代码签名 superblob 检查、字符串级差异审计。未连接 iPhone：HelloBundleID
伪装下的实际读取路径、以及内置步骤在真机上的执行，仍需按上面 0–4 步确认。

【回退】
退出软件，备份整个主隐根 Library/iCleanerRootHide，再安装已知可用的旧包。
