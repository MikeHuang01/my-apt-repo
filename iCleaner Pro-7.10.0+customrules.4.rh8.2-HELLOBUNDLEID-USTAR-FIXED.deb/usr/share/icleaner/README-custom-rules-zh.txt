iCleaner Pro — RootHide 主隐根统一存储 rh8（修复 /var 残留与自定义规则丢失）
版本：7.10.0+customrules.4.rh8；包标识：com.sini.icleanerpro
仅用于 Dopamine RootHide，依赖 rootless-compat >= 0.9，最低 iOS 15。
请在现有 RootHide 环境直接升级，不要再次 RootHidePatcher 转换。
rh3 至 rh7 安装包与源码不覆盖，仍可保留作回退参考。

【rh8 修的是什么：三个独立缺陷】

缺陷 1：旧 symlink 让合并永久失败，数据一直留在 /var
rh1–rh5 的 `-[ICAppDelegate symlinkPreferenceFile]` 会在应用自己的数据目录
/var/mobile/Library/iCleaner 里放一个偏好 plist 的符号链接。
rh7 的合并前置检查 PlainTree() 把任何符号链接或特殊文件判为不可合并，
MergeOne() 随即 Fail("merge-source-link-special-or-overlap-preserved")，
ConsolidateStorage() 返回 NO，ICRStateDirectory() 返回 nil。
结果是：
  · 数据目录永不切换，应用继续写 /var/mobile/Library/iCleaner（即"还在 /var"）；
  · InstallPreferences() 在 "data-consolidation-unavailable-preferences-not-moved"
    处直接退出，偏好钩子一个都没装；
  · Refresh() 在创建备份目录处调用 RecordFailure 后 return，
    合并后的规则列表根本没写回，固定 5 条与动态规则都不会出现。
而且 rh7 没有任何代码会清理 /var/mobile/Library/iCleaner 内部的这个链接，
PrefRetireDanglingMobileLinks() 只处理 mobile 偏好路径，所以这是死锁：
每次启动都失败，失败原因写在 storage-migration-status.plist 的 failureReason。

rh8 处理：新增 QuarantineNonPlain()，合并前把源目录里的符号链接/特殊文件
整体移动到 <主隐根>/Backups/links/<源目录名>[-N]/ 下。移动的是对象本身，
不复制、不改写、不删除；跨卷 rename 失败时只对符号链接做"重建+校验+unlink源"，
其他特殊文件则保持原位并记错。源目录因此变成纯净目录，正常合并得以继续。
storage-migration-status.plist 新增 linkEntriesQuarantined 计数字段。

缺陷 2：合并失败时禁止导入规则，把"备份失败"当成"不许导入"
rh7 的 Refresh() 在 state == nil 时直接 return，规则一条都不导入。
rh8 改为：备份只是便利措施。能写就写，写不了就把 backupSkipped 记进状态，
规则照常导入；原始列表仍写入 ICCustomRules.original 键作为兜底。
status plist 新增 preferencesBackupSkipped 字段。

缺陷 3：受管规则被无证据删除，清理步骤不再勾选
a) rh7 的合并循环对"上次由本组件生成"的规则一律丢弃，除非本次又重新生成。
   而本次生成受 3 秒时限与 60000 条目上限约束，目录暂不可读、扫描被截断，
   都会被当成"用户删了规则"，规则因此静默消失。
   rh8 只在"完整扫描（未 limited）+ 目录确实不存在"时才丢弃。
b) CUSTOMFILES 清理步骤只在"首次导入"时启用一次。偏好或存储迁移把规则搬到
   新存储后，新存储没有这个一次性标记，规则在列表里但步骤是未勾选状态。
   rh8 以 ICCustomRules.stepVersion 记录"本次构建是否已启用过"，
   每次版本变更重新启用一次，之后不再和用户的手动取消对抗。
   status plist 新增 cleanupStepEnabled 字段。
c) 规则状态文件以前写进 ICRStateDirectory()，合并失败时是 nil，状态无从查证。
   rh8 新增 ICRStatusDirectory()，返回主隐根基目录（不要求 Data 已激活），
   因此 custom-rules-status.plist 在失败情况下也能落盘。

【设备验收（仍未在手机上执行）】
1. 覆盖安装 rh8 后打开 iCleaner。
2. 主隐根 Library/iCleanerRootHide/storage-migration-status.plist 应为
   version=2026.11.18.rh8、primaryDataActive=true、success=true、
   legacyDirectoriesRemaining=0、failureReason 为空；
   linkEntriesQuarantined 可能大于 0，表示旧链接已归档到 Backups/links，不是错误。
3. 同一目录下 custom-rules-status.plist 应为 success=true，
   managedRuleCount/generatedRuleCount 大于 0，cleanupStepEnabled=true。
4. 打开"自定义文件夹"：5 条固定规则（/var/db/uuidtext、diagnostics 的
   Persist/Signpost/Special、/var/mobile/Library/Caches）应存在且清理步骤已勾选。
5. 确认 /var/mobile/Library/iCleaner 不再被重新写入；旧内容在
   Backups/snapshot*、Backups/retired*、Backups/links 内可核对。
6. 多次启动后复查上述两点，规则不应再消失或变回未勾选。

【验证边界】
本次修改完成了：源码修补、iOS 交叉编译、Mach-O 结构与加载项对比、
代码签名 superblob 检查、字符串级差异审计，以及清理脚本的真实 dash 执行对比。
未连接 iPhone，iOS Foundation 与 RootHide 的实际行为仍需按上面 6 步在真机确认。

【回退】
退出软件，备份整个主隐根 Library/iCleanerRootHide，再安装已知可用的旧包。
降级不会自动还原已迁移数据，也不应先清空新目录。
