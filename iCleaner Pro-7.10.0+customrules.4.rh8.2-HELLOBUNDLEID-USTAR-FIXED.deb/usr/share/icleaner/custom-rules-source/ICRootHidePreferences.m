﻿/* File-backed preferences for ONE existing standardUserDefaults instance.
 * Keep the native categories, identity, default registration and synchronization
 * notification wrapper. Never redirect other preferences domains or processes.
 */
#import "ICRootHideStorage.h"
#ifdef ICR_HOST_TEST
#import <objc/runtime.h>
#include <fcntl.h>
#include <sys/file.h>
#include <unistd.h>
#include <sys/stat.h>
#else
extern const char *jbroot(const char *path);
extern int open(const char *path, int flags, ...);
extern int flock(int fd, int operation);
extern int close(int fd);
extern int rename(const char *from, const char *to);
extern int unlink(const char *path);
extern int chmod(const char *path, unsigned short mode);
#define LOCK_EX 2
#define LOCK_NB 4
#define LOCK_UN 8
#endif

static NSString *const PrefDomain = @"com.ivanobilenchi.icleaner";
static NSString *const PrefLeaf = @"com.ivanobilenchi.icleaner.plist";
static id ManagedDefaults;
static NSString *PrefBase, *PrefDirectory, *PrefFile, *PrefLock, *PrefArchive;
static NSMutableDictionary *Values, *Fallback, *Pending;
static NSMutableSet *Removed;
static BOOL PrefActive;
static NSUInteger PendingRemovals;
static BOOL ReplaceDomain;
static NSString *PrefFailure;
static NSArray *PrefSources;
static BOOL LegacyLinkCreationBlocked;
static NSString *LegacyLinkCleanupFailure;
static NSUInteger DanglingLinksArchived;
static BOOL (*OriginalCreateSymbolicLink)(id, SEL, NSString *, NSString *, NSError **);
static BOOL (*OriginalConcreteCreateSymbolicLink)(id, SEL, NSString *, NSString *, NSError **);
static Class ConcreteFileManagerClass;

static id PrefKeep(id object) {
#ifdef ICR_HOST_TEST
    /* GNUstep harness uses MRC; model ARC's strong static references across
     * notification-center autorelease pools. Each isolated test exits shortly. */
    return [object retain];
#else
    return object;
#endif
}

static BOOL PrefFail(NSString *reason) { PrefFailure = reason; return NO; }
static BOOL PrefMissing(NSError *error) {
    return error && (([[error domain] isEqualToString:NSCocoaErrorDomain] && ([error code] == 260 || [error code] == 4)) ||
                     ([[error domain] isEqualToString:NSPOSIXErrorDomain] && [error code] == 2));
}
static NSDictionary *PrefAttributes(NSString *path, NSError **error) {
    return [[NSFileManager defaultManager] attributesOfItemAtPath:path error:error];
}
static BOOL PrefType(NSString *path, NSString *type) {
    return [[PrefAttributes(path, NULL) objectForKey:NSFileType] isEqual:type];
}
static BOOL PrefPlainDirectory(NSString *path) {
    return PrefType(path, NSFileTypeDirectory) &&
           [[path stringByResolvingSymlinksInPath] isEqualToString:path];
}
static BOOL PrefEnsureDirectory(NSString *path) {
    NSError *error = nil;
    if (!PrefAttributes(path, &error)) {
        if (!PrefMissing(error) || ![[NSFileManager defaultManager] createDirectoryAtPath:path
             withIntermediateDirectories:NO attributes:nil error:NULL]) return NO;
    }
    return PrefPlainDirectory(path);
}
static NSDictionary *PrefRead(NSString *path) {
    if (!PrefType(path, NSFileTypeRegular)) return nil;
    id dictionary = [NSDictionary dictionaryWithContentsOfFile:path];
    return [dictionary isKindOfClass:[NSDictionary class]] ? dictionary : nil;
}
static int PrefAcquire(void) {
    if (!PrefPlainDirectory(PrefBase) || !PrefPlainDirectory(PrefDirectory) || !PrefPlainDirectory(PrefArchive)) return -1;
#ifdef ICR_HOST_TEST
    int flags = O_CREAT | O_RDWR | O_NOFOLLOW;
#else
    int flags = 0x200 | 2 | 0x100;
#endif
    int fd = open([PrefLock fileSystemRepresentation], flags, 0600);
    if (fd >= 0 && flock(fd, LOCK_EX | LOCK_NB)) { close(fd); return -1; }
    return fd;
}
static void PrefRelease(int fd) { flock(fd, LOCK_UN); close(fd); }
static void PrefStatus(BOOL saved) {
    if (![PrefBase length]) return;
    [@{@"version":@"2026.11.18.rh8", @"active":[NSNumber numberWithBool:PrefActive],
       @"lastSaveVerified":[NSNumber numberWithBool:saved], @"file":PrefFile ?: @"",
       @"failureReason":PrefFailure ?: @"", @"date":[NSDate date],
       @"legacyItemsRemaining":[NSNumber numberWithUnsignedInteger:PendingRemovals],
        @"legacyLinkCreationDisabled":[NSNumber numberWithBool:LegacyLinkCreationBlocked],
         @"legacyLinkCreationBlocked":[NSNumber numberWithBool:LegacyLinkCreationBlocked],
        @"danglingMobileLinksArchived":[NSNumber numberWithUnsignedInteger:DanglingLinksArchived],
        @"legacyLinkCleanupFailure":LegacyLinkCleanupFailure ?: @"",
       @"otherPreferenceDomainsRedirected":@NO}
       writeToFile:[PrefBase stringByAppendingPathComponent:@"preferences-migration-status.plist"] atomically:YES];
}
static BOOL PrefWrite(NSDictionary *dictionary, NSString *path) {
    NSError *error = nil;
    NSDictionary *attributes = PrefAttributes(path, &error);
    if (attributes ? !PrefType(path, NSFileTypeRegular) : !PrefMissing(error)) return NO;
    if (![dictionary writeToFile:path atomically:YES]) return NO;
    if (chmod([path fileSystemRepresentation], 0600)) return NO;
    return [dictionary isEqualToDictionary:PrefRead(path)];
}
static NSString *PrefUnused(NSString *prefix) {
    for (NSUInteger i = 0; i < 10000; i++) {
        NSString *path = [PrefArchive stringByAppendingPathComponent:
            [NSString stringWithFormat:@"%@-%lu.plist", prefix, i]];
        NSError *error = nil;
        if (!PrefAttributes(path, &error)) return PrefMissing(error) ? path : nil;
    }
    return nil;
}

static id (*OriginalObject)(id, SEL, NSString *);
static void (*OriginalSet)(id, SEL, id, NSString *);
static void (*OriginalRemove)(id, SEL, NSString *);
static void (*OriginalRegister)(id, SEL, NSDictionary *);
static id (*OriginalRepresentation)(id, SEL);
static BOOL (*OriginalSync)(id, SEL);
static id (*OriginalDomain)(id, SEL, NSString *);
static void (*OriginalSetDomain)(id, SEL, NSDictionary *, NSString *);
static void (*OriginalRemoveDomain)(id, SEL, NSString *);

static BOOL PrefFlush(void) {
    int fd = PrefAcquire();
    if (fd < 0) return PrefFail(@"preferences-lock-or-directory-unavailable");
    BOOL ok = NO;
    @try {
        NSDictionary *disk = PrefRead(PrefFile);
        if (!disk) PrefFail(@"active-preferences-unreadable-preserved");
        else {
            NSMutableDictionary *next = ReplaceDomain ? [NSMutableDictionary dictionary] : [disk mutableCopy];
            NSArray *keys = [disk allKeys];
            for (NSUInteger i = 0; i < [keys count]; i++) {
                NSString *key = [keys objectAtIndex:i];
                if ([Removed containsObject:key]) [next removeObjectForKey:key];
            }
            [next addEntriesFromDictionary:Pending];
            if (PrefWrite(next, PrefFile)) {
                Values = PrefKeep(next); Pending = PrefKeep([NSMutableDictionary dictionary]); Removed = PrefKeep([NSMutableSet set]);
                ReplaceDomain = NO; PrefFailure = nil; ok = YES;
            } else PrefFail(@"preferences-save-failed-pending-changes-kept-in-memory");
        }
    } @finally { PrefRelease(fd); }
    PrefStatus(ok);
    return ok;
}
static id PrefObject(NSString *key) {
    /* Refresh other instances' committed changes, without discarding pending
     * in-memory edits after a failed write. No CFPreferences call is made. */
    if (![Pending count] && ![Removed count] && !ReplaceDomain) {
        NSDictionary *disk = PrefRead(PrefFile);
        if (disk) Values = [disk mutableCopy];
    }
    id object = [Values objectForKey:key];
    return object ?: [Fallback objectForKey:key];
}
static id HookObject(id self, SEL cmd, NSString *key) {
    if (self != ManagedDefaults || !PrefActive) return OriginalObject(self, cmd, key);
    @synchronized(ManagedDefaults) { return PrefObject(key); }
}
static void PrefChanged(void) {
    [[NSNotificationCenter defaultCenter] postNotificationName:NSUserDefaultsDidChangeNotification object:ManagedDefaults];
}
static void HookSet(id self, SEL cmd, id value, NSString *key) {
    if (self != ManagedDefaults || !PrefActive) { OriginalSet(self, cmd, value, key); return; }
    @synchronized(ManagedDefaults) {
        if (value) { [Values setObject:value forKey:key]; [Pending setObject:value forKey:key]; }
        else { [Values removeObjectForKey:key]; [Pending removeObjectForKey:key]; [Removed addObject:key]; }
        PrefFlush(); PrefChanged();
    }
}
static void HookRemove(id self, SEL cmd, NSString *key) {
    if (self != ManagedDefaults || !PrefActive) { OriginalRemove(self, cmd, key); return; }
    HookSet(self, @selector(setObject:forKey:), nil, key);
}
static void HookRegister(id self, SEL cmd, NSDictionary *defaults) {
    if (self != ManagedDefaults || !PrefActive) { OriginalRegister(self, cmd, defaults); return; }
    @synchronized(ManagedDefaults) { [Fallback addEntriesFromDictionary:defaults]; }
}
static id HookRepresentation(id self, SEL cmd) {
    if (self != ManagedDefaults || !PrefActive) return OriginalRepresentation(self, cmd);
    @synchronized(ManagedDefaults) {
        NSMutableDictionary *all = [Fallback mutableCopy];
        [all addEntriesFromDictionary:Values]; return all;
    }
}
static BOOL HookSync(id self, SEL cmd) {
    if (self != ManagedDefaults || !PrefActive) return OriginalSync(self, cmd);
    @synchronized(ManagedDefaults) { return PrefFlush(); }
}
static id HookDomain(id self, SEL cmd, NSString *domain) {
    if (self != ManagedDefaults || !PrefActive || ![domain isEqualToString:PrefDomain]) return OriginalDomain(self, cmd, domain);
    @synchronized(ManagedDefaults) { return [Values copy]; }
}
static void HookSetDomain(id self, SEL cmd, NSDictionary *values, NSString *domain) {
    if (self != ManagedDefaults || !PrefActive || ![domain isEqualToString:PrefDomain]) { OriginalSetDomain(self, cmd, values, domain); return; }
    @synchronized(ManagedDefaults) {
        Values = [values mutableCopy]; Pending = [values mutableCopy]; Removed = PrefKeep([NSMutableSet set]); ReplaceDomain = YES;
        PrefFlush(); PrefChanged();
    }
}
static void HookRemoveDomain(id self, SEL cmd, NSString *domain) {
    if (self != ManagedDefaults || !PrefActive || ![domain isEqualToString:PrefDomain]) { OriginalRemoveDomain(self, cmd, domain); return; }
    HookSetDomain(self, @selector(setPersistentDomain:forName:), @{}, domain);
}

#define PREF_GET_OBJECT(NAME, SELECTOR, TYPE) \
static id (*Original##NAME)(id, SEL, NSString *); \
static id Hook##NAME(id self, SEL cmd, NSString *key) { \
    if (self != ManagedDefaults || !PrefActive) return Original##NAME(self, cmd, key); \
    id value = HookObject(self, @selector(objectForKey:), key); \
    return [value isKindOfClass:[TYPE class]] ? value : nil; \
}
PREF_GET_OBJECT(String, stringForKey, NSString)
PREF_GET_OBJECT(Array, arrayForKey, NSArray)
PREF_GET_OBJECT(Dictionary, dictionaryForKey, NSDictionary)
PREF_GET_OBJECT(Data, dataForKey, NSData)

#define PREF_NUMBER(NAME, TYPE, GET, SET, VALUE, BOX) \
static TYPE (*Original##NAME)(id, SEL, NSString *); \
static void (*OriginalSet##NAME)(id, SEL, TYPE, NSString *); \
static TYPE Hook##NAME(id self, SEL cmd, NSString *key) { \
    if (self != ManagedDefaults || !PrefActive) return Original##NAME(self, cmd, key); \
    id value = HookObject(self, @selector(objectForKey:), key); \
    return [value respondsToSelector:@selector(VALUE)] ? [value VALUE] : (TYPE)0; \
} \
static void HookSet##NAME(id self, SEL cmd, TYPE value, NSString *key) { \
    if (self != ManagedDefaults || !PrefActive) { OriginalSet##NAME(self, cmd, value, key); return; } \
    HookSet(self, @selector(setObject:forKey:), [NSNumber BOX:value], key); \
}
PREF_NUMBER(Bool, BOOL, boolForKey, setBool, boolValue, numberWithBool)
PREF_NUMBER(Integer, NSInteger, integerForKey, setInteger, integerValue, numberWithInteger)
PREF_NUMBER(Float, float, floatForKey, setFloat, floatValue, numberWithFloat)
PREF_NUMBER(Double, double, doubleForKey, setDouble, doubleValue, numberWithDouble)

static id (*OriginalStringArray)(id, SEL, NSString *);
static id HookStringArray(id self, SEL cmd, NSString *key) {
    if (self != ManagedDefaults || !PrefActive) return OriginalStringArray(self, cmd, key);
    NSArray *array = HookArray(self, @selector(arrayForKey:), key);
    for (NSUInteger i = 0; i < [array count]; i++)
        if (![[array objectAtIndex:i] isKindOfClass:[NSString class]]) return nil;
    return array;
}

/* Sources are fixed to this app's domain. No arbitrary link targets are read
 * or removed; a link is archived verbatim, not confused with plist content. */
static NSArray *PrefDefaultSources(void) {
    NSMutableArray *paths = [NSMutableArray array];
    NSArray *users = @[@"root", @"mobile"];
    for (NSUInteger i = 0; i < [users count]; i++) {
        NSString *user = [users objectAtIndex:i];
        NSString *path = [NSString stringWithFormat:@"/var/%@/Library/Preferences/%@", user, PrefLeaf];
        [paths addObject:path];
        const char *hidden = jbroot([path fileSystemRepresentation]);
        if (hidden) {
            NSString *physical = [[[[NSString stringWithUTF8String:hidden] stringByDeletingLastPathComponent]
                stringByResolvingSymlinksInPath] stringByAppendingPathComponent:PrefLeaf];
            if (![paths containsObject:physical]) [paths addObject:physical];
        }
    }
    return paths;
}
static BOOL PrefBackup(NSString *source, NSString *backup) {
    NSFileManager *fm = [NSFileManager defaultManager];
    if (![fm copyItemAtPath:source toPath:backup error:NULL]) return NO;
    if (PrefType(source, NSFileTypeSymbolicLink)) {
        return [[fm destinationOfSymbolicLinkAtPath:source error:NULL] isEqualToString:
                [fm destinationOfSymbolicLinkAtPath:backup error:NULL]];
    }
    return PrefType(backup, NSFileTypeRegular) && [fm contentsEqualAtPath:source andPath:backup];
}
static void PrefRetireSources(void);
static BOOL PrefIsMobilePreferencePath(NSString *path) {
    if (![path isKindOfClass:[NSString class]]) return NO;
    NSString *normalized = [path stringByStandardizingPath];
    NSString *canonical = @"/var/mobile/Library/Preferences/com.ivanobilenchi.icleaner.plist";
    if ([normalized isEqualToString:canonical] ||
        [normalized isEqualToString:@"/private/var/mobile/Library/Preferences/com.ivanobilenchi.icleaner.plist"])
        return YES;
#ifdef ICR_HOST_TEST
    /* The isolated host fixture never accesses the real machine's /var. */
    if ([PrefSources count] > 1 &&
        [normalized isEqualToString:[[PrefSources objectAtIndex:1] stringByStandardizingPath]]) return YES;
#endif
    const char *hidden = jbroot([canonical fileSystemRepresentation]);
    if (!hidden) return NO;
    NSString *hiddenPath = [[NSString stringWithUTF8String:hidden] stringByStandardizingPath];
    if ([normalized isEqualToString:hiddenPath]) return YES;
    NSString *physical = [[[[NSString stringWithUTF8String:hidden] stringByDeletingLastPathComponent]
        stringByResolvingSymlinksInPath] stringByAppendingPathComponent:PrefLeaf];
    return [normalized isEqualToString:[physical stringByStandardizingPath]];
}
static BOOL PrefTargetDefinitelyMissing(NSString *link, NSString *destination) {
    NSString *target = [destination hasPrefix:@"/"] ? destination :
        [[link stringByDeletingLastPathComponent] stringByAppendingPathComponent:destination];
    /* Do not inspect arbitrary targets. Only the app's known old root plist
     * is eligible for pre-migration dangling-link cleanup. */
    NSArray *known = @[@"/rootfs/var/root/Library/Preferences/com.ivanobilenchi.icleaner.plist",
        @"/var/root/Library/Preferences/com.ivanobilenchi.icleaner.plist",
        @"/private/var/root/Library/Preferences/com.ivanobilenchi.icleaner.plist"];
    if (![known containsObject:target]) return NO;
    NSString *canonical = @"/var/root/Library/Preferences/com.ivanobilenchi.icleaner.plist";
    NSArray *candidates = @[target, canonical,
        @"/private/var/root/Library/Preferences/com.ivanobilenchi.icleaner.plist"];
    for (NSUInteger i = 0; i < [candidates count]; i++) {
        NSString *candidate = [candidates objectAtIndex:i];
        NSError *error = nil;
        if (PrefAttributes(candidate, &error) || !PrefMissing(error)) return NO;
        const char *hidden = jbroot([candidate fileSystemRepresentation]);
        /* Without the dynamic hidden-root mapping, absence cannot be proven. */
        if (!hidden) return NO;
        error = nil;
        if (PrefAttributes([NSString stringWithUTF8String:hidden], &error) || !PrefMissing(error)) return NO;
    }
    return YES;
}
static void PrefRetireDanglingMobileLinks(void) {
    NSFileManager *fm = [NSFileManager defaultManager];
    for (NSUInteger i = 0; i < [PrefSources count]; i++) {
        NSString *source = [PrefSources objectAtIndex:i];
        if (!PrefIsMobilePreferencePath(source) || !PrefType(source, NSFileTypeSymbolicLink)) continue;
        NSString *destination = [fm destinationOfSymbolicLinkAtPath:source error:NULL];
        if (![destination length] || !PrefTargetDefinitelyMissing(source, destination)) continue;
        NSString *backup = PrefUnused(@"dangling-mobile-link");
        if (!backup || !PrefBackup(source, backup) ||
            !PrefType(source, NSFileTypeSymbolicLink) ||
            ![[fm destinationOfSymbolicLinkAtPath:source error:NULL] isEqualToString:
                [fm destinationOfSymbolicLinkAtPath:backup error:NULL]] ||
            !PrefTargetDefinitelyMissing(source, destination) ||
            unlink([source fileSystemRepresentation])) {
            PendingRemovals++;
            LegacyLinkCleanupFailure = @"dangling-mobile-link-preserved-backup-or-unlink-failed";
            continue;
        }
        if (PrefAttributes(source, NULL)) {
            PendingRemovals++;
            LegacyLinkCleanupFailure = @"dangling-mobile-link-still-present-after-retirement";
        } else {
            DanglingLinksArchived++;
        }
    }
}
static BOOL PrefLinkTargetsSource(NSString *link, NSString *source) {
    NSFileManager *fm = [NSFileManager defaultManager];
    NSString *destination = [fm destinationOfSymbolicLinkAtPath:link error:NULL];
    if (![destination length]) return NO;
    NSString *target = [destination hasPrefix:@"/"] ? destination :
        [[link stringByDeletingLastPathComponent] stringByAppendingPathComponent:destination];
    target = [target stringByStandardizingPath];
    if ([target hasPrefix:@"/rootfs/var/"])
        target = [@"/var" stringByAppendingPathComponent:[target substringFromIndex:12]];
    else if ([target hasPrefix:@"/private/var/"])
        target = [@"/var" stringByAppendingPathComponent:[target substringFromIndex:13]];
    NSString *physicalSource = [[[source stringByDeletingLastPathComponent] stringByResolvingSymlinksInPath]
        stringByAppendingPathComponent:[source lastPathComponent]];
    NSString *physicalTarget = [[[target stringByDeletingLastPathComponent] stringByResolvingSymlinksInPath]
        stringByAppendingPathComponent:[target lastPathComponent]];
    if ([physicalTarget isEqualToString:physicalSource]) return YES;
    const char *mappedTarget = jbroot([target fileSystemRepresentation]);
    if (!mappedTarget) return NO;
    NSString *mapped = [NSString stringWithUTF8String:mappedTarget];
    NSString *physicalMapped = [[[mapped stringByDeletingLastPathComponent] stringByResolvingSymlinksInPath]
        stringByAppendingPathComponent:[mapped lastPathComponent]];
    return [physicalSource isEqualToString:physicalMapped];
}
static BOOL HookCreateSymbolicLink(id self, SEL cmd, NSString *path, NSString *destination, NSError **error) {
    if (PrefIsMobilePreferencePath(path)) return NO;
    return OriginalCreateSymbolicLink(self, cmd, path, destination, error);
}
static BOOL HookConcreteCreateSymbolicLink(id self, SEL cmd, NSString *path, NSString *destination, NSError **error) {
    if (PrefIsMobilePreferencePath(path)) return NO;
    return OriginalConcreteCreateSymbolicLink(self, cmd, path, destination, error);
}
static void HookSymlink(id self, SEL cmd) {
    (void)self; (void)cmd;
    /* Never run the app's method that recreates the obsolete mobile link,
     * including when preference migration has not yet succeeded. */
    if (PrefActive) {
        @synchronized(ManagedDefaults ?: [NSUserDefaults class]) {
            int fd = PrefAcquire();
            if (fd >= 0) { PrefRetireSources(); PrefRelease(fd); PrefStatus(YES); }
        }
    }
}
static void InstallLegacyLinkBlocker(void) {
    if (!OriginalCreateSymbolicLink) {
        Method create = class_getInstanceMethod([NSFileManager class],
            @selector(createSymbolicLinkAtPath:withDestinationPath:error:));
        if (create) OriginalCreateSymbolicLink = (void *)method_setImplementation(create, (IMP)(void *)HookCreateSymbolicLink);
    }
    if (!ConcreteFileManagerClass) ConcreteFileManagerClass = [[NSFileManager defaultManager] class];
    if (ConcreteFileManagerClass && ConcreteFileManagerClass != [NSFileManager class]) {
        Method concrete = class_getInstanceMethod(ConcreteFileManagerClass,
            @selector(createSymbolicLinkAtPath:withDestinationPath:error:));
        IMP current = concrete ? method_getImplementation(concrete) : NULL;
        if (current && current != (IMP)(void *)HookCreateSymbolicLink && current != (IMP)(void *)HookConcreteCreateSymbolicLink) {
            const char *encoding = method_getTypeEncoding(concrete);
            if (!class_addMethod(ConcreteFileManagerClass,
                    @selector(createSymbolicLinkAtPath:withDestinationPath:error:),
                    (IMP)(void *)HookConcreteCreateSymbolicLink, encoding))
                OriginalConcreteCreateSymbolicLink = (void *)method_setImplementation(concrete, (IMP)(void *)HookConcreteCreateSymbolicLink);
            else OriginalConcreteCreateSymbolicLink = (void *)current;
        }
    }
    Class delegate = NSClassFromString(@"ICAppDelegate");
    Method link = delegate ? class_getInstanceMethod(delegate, @selector(symlinkPreferenceFile)) : NULL;
    if (link && method_getImplementation(link) != (IMP)(void *)HookSymlink)
        method_setImplementation(link, (IMP)(void *)HookSymlink);
    LegacyLinkCreationBlocked = OriginalCreateSymbolicLink || OriginalConcreteCreateSymbolicLink || link != NULL;
}
static BOOL PrefPreparePaths(void) {
    NSString *root = ICRActiveJailbreakRoot();
    if (![root length]) return NO;
    NSString *library = [root stringByAppendingPathComponent:@"Library"];
    if (!PrefPlainDirectory(library)) return NO;
    PrefBase = PrefKeep([library stringByAppendingPathComponent:@"iCleanerRootHide"]);
    if (!PrefEnsureDirectory(PrefBase)) return NO;
    PrefDirectory = PrefKeep([PrefBase stringByAppendingPathComponent:@"Preferences"]);
    PrefArchive = PrefKeep([PrefBase stringByAppendingPathComponent:@"Preferences-legacy"]);
    PrefFile = PrefKeep([PrefDirectory stringByAppendingPathComponent:PrefLeaf]);
    PrefLock = PrefKeep([PrefBase stringByAppendingPathComponent:@"preferences.lock"]);
    return PrefEnsureDirectory(PrefDirectory) && PrefEnsureDirectory(PrefArchive);
}
static NSUInteger PrefCountArchivedDanglingLinks(void) {
    NSUInteger count = 0;
    NSArray *archives = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:PrefArchive error:NULL];
    for (NSUInteger i = 0; i < [archives count]; i++) {
        NSString *name = [archives objectAtIndex:i];
        if ([name hasPrefix:@"dangling-mobile-link-"] &&
            PrefType([PrefArchive stringByAppendingPathComponent:name], NSFileTypeSymbolicLink))
            count++;
    }
    return count;
}
static void PrefCleanupLegacyLink(void) {
    if (!PrefPreparePaths()) return;
    if (!PrefSources) PrefSources = PrefKeep(PrefDefaultSources());
    int fd = PrefAcquire();
    if (fd < 0) { LegacyLinkCleanupFailure = @"legacy-link-cleanup-lock-unavailable"; return; }
    @try {
        LegacyLinkCleanupFailure = nil;
        /* Keep the status count meaningful across launches: the archived
         * link remains in Preferences-legacy after its live entry is gone. */
        DanglingLinksArchived = PrefCountArchivedDanglingLinks();
        PrefRetireDanglingMobileLinks();
    } @finally { PrefRelease(fd); }
    PrefStatus(PrefActive && [Values isEqualToDictionary:PrefRead(PrefFile)]);
}
static void PrefRetireSources(void) {
    PendingRemovals = 0;
    for (NSUInteger i = 0; i < [PrefSources count]; i++) {
        NSString *source = [PrefSources objectAtIndex:i];
        NSError *error = nil;
        NSDictionary *attributes = PrefAttributes(source, &error);
        if (!attributes && PrefMissing(error)) continue;
        NSString *backup = PrefUnused(@"retired");
        NSString *type = [attributes objectForKey:NSFileType];
        /* A valid or unclassifiable link is not a preference backup. The
         * dedicated mobile-link cleanup above handles only verified dangling
         * links to the known old root plist; leave every other link untouched. */
        if ([type isEqual:NSFileTypeSymbolicLink]) { PendingRemovals++; continue; }
        BOOL referencedByLink = NO;
        for (NSUInteger j = 0; j < [PrefSources count]; j++) {
            NSString *link = [PrefSources objectAtIndex:j];
            if (![link isEqualToString:source] && PrefType(link, NSFileTypeSymbolicLink) &&
                PrefLinkTargetsSource(link, source)) { referencedByLink = YES; break; }
        }
        if (referencedByLink) { PendingRemovals++; continue; }
        BOOL matches = [type isEqual:NSFileTypeRegular] &&
                       [Values isEqualToDictionary:PrefRead(source)];
        if (!matches || !backup || !PrefBackup(source, backup)) { PendingRemovals++; continue; }
        /* Keep the independently verified copy and atomically retire the exact
         * source item into another unused slot. Never remove the parent. */
        NSString *retired = PrefUnused(@"original");
        BOOL unchanged = [[NSFileManager defaultManager] contentsEqualAtPath:source andPath:backup];
        if (!retired || !unchanged || rename([source fileSystemRepresentation], [retired fileSystemRepresentation])) PendingRemovals++;
    }
    if (PendingRemovals) PrefFailure = @"some-legacy-items-preserved-in-place-or-archive";
}

typedef struct { SEL selector; IMP hook; void **original; } PrefHook;
#define ENTRY(SELNAME, NAME) {@selector(SELNAME), (IMP)(void *)Hook##NAME, (void **)&Original##NAME}

/* Call only after native ICUserDefaultsSync +load exchanged the aliases.
 * Its synchronize wrapper remains intact and still emits the native will-sync
 * notification, so registered native objects keep writing their settings. */
static BOOL InstallPreferences(NSUserDefaults *standard) {
    if (PrefActive) return YES;
    InstallLegacyLinkBlocker();
    PrefCleanupLegacyLink();
    Class cls = [standard class];
    Class delegate = NSClassFromString(@"ICAppDelegate");
    PrefHook hooks[] = {
        ENTRY(objectForKey:, Object), ENTRY(setObject:forKey:, Set), ENTRY(removeObjectForKey:, Remove),
        ENTRY(registerDefaults:, Register), ENTRY(dictionaryRepresentation, Representation),
        ENTRY(IC_synchronize, Sync), ENTRY(persistentDomainForName:, Domain),
        ENTRY(setPersistentDomain:forName:, SetDomain), ENTRY(removePersistentDomainForName:, RemoveDomain),
        ENTRY(stringForKey:, String), ENTRY(arrayForKey:, Array), ENTRY(dictionaryForKey:, Dictionary),
        ENTRY(dataForKey:, Data), ENTRY(stringArrayForKey:, StringArray),
        ENTRY(boolForKey:, Bool), ENTRY(setBool:forKey:, SetBool),
        ENTRY(integerForKey:, Integer), ENTRY(setInteger:forKey:, SetInteger),
        ENTRY(floatForKey:, Float), ENTRY(setFloat:forKey:, SetFloat),
        ENTRY(doubleForKey:, Double), ENTRY(setDouble:forKey:, SetDouble)
    };
    NSString *data = ICRStateDirectory();
    NSString *root = ICRActiveJailbreakRoot();
    PrefBase = PrefKeep(data ? [data stringByDeletingLastPathComponent] : [root stringByAppendingPathComponent:@"Library/iCleanerRootHide"]);
    PrefDirectory = PrefKeep([PrefBase stringByAppendingPathComponent:@"Preferences"]);
    PrefArchive = PrefKeep([PrefBase stringByAppendingPathComponent:@"Preferences-legacy"]);
    PrefFile = PrefKeep([PrefDirectory stringByAppendingPathComponent:PrefLeaf]);
    PrefLock = PrefKeep([PrefBase stringByAppendingPathComponent:@"preferences.lock"]);
    if (!data) { PrefFail(@"data-consolidation-unavailable-preferences-not-moved"); PrefStatus(NO); return NO; }
    NSUInteger count = sizeof(hooks) / sizeof(hooks[0]);
    for (NSUInteger i = 0; i < count; i++) {
        if (!class_getInstanceMethod(cls, hooks[i].selector)) {
            PrefFail(@"native-preference-method-missing-no-hooks-installed"); PrefStatus(NO); return NO;
        }
    }
    if (!delegate || !class_getInstanceMethod(delegate, @selector(symlinkPreferenceFile)) ||
        !PrefEnsureDirectory(PrefDirectory) || !PrefEnsureDirectory(PrefArchive)) {
        PrefFail(@"preference-directory-or-native-link-method-unavailable"); PrefStatus(NO); return NO;
    }
    int fd = PrefAcquire();
    if (fd < 0) { PrefFail(@"migration-lock-unavailable"); PrefStatus(NO); return NO; }
    BOOL ready = NO;
    @try {
        /* Flush and inspect ONLY the app's persisted domain, not the combined
         * dictionaryRepresentation (which includes Apple/global defaults). */
        /* On subsequent launches never synchronize the abandoned CF domain:
         * it could recreate a retired plist using its stale daemon cache. */
        NSDictionary *existing = PrefRead(PrefFile);
        if (!existing && ![standard synchronize]) PrefFail(@"native-preferences-sync-failed-no-migration");
        else {
            NSDictionary *domain = [standard persistentDomainForName:PrefDomain];
            NSDictionary *snapshot = existing;
            NSError *destinationError = nil;
            NSDictionary *destination = PrefAttributes(PrefFile, &destinationError);
            BOOL conflict = (destination && !snapshot) || (!destination && !PrefMissing(destinationError));
            BOOL hadSource = NO;
            if (!PrefSources) PrefSources = PrefKeep(PrefDefaultSources());
            PrefRetireDanglingMobileLinks();
            NSDictionary *candidate = [domain count] ? domain : nil;
            for (NSUInteger i = 0; i < [PrefSources count]; i++) {
                NSString *source = [PrefSources objectAtIndex:i];
                NSError *error = nil;
                NSDictionary *attributes = PrefAttributes(source, &error);
                if (!attributes && PrefMissing(error)) continue;
                hadSource = YES;
                NSString *type = [attributes objectForKey:NSFileType];
                if ([type isEqual:NSFileTypeRegular]) {
                    NSDictionary *file = PrefRead(source);
                    if (!snapshot && (!file || (candidate && ![candidate isEqualToDictionary:file]))) conflict = YES;
                    if (!candidate) candidate = file;
                } else if (![type isEqual:NSFileTypeSymbolicLink]) conflict = YES;
            }
            if (conflict) PrefFail(@"unreadable-or-conflicting-preference-files-preserved");
            /* A confirmed dangling link was archived above and is no longer in
             * PrefSources. With no other readable source, activate an empty
             * store so custom rules can be generated into the new location.
             * Any remaining link, unreadable file, or directory still fails. */
            else if (!snapshot && !candidate && hadSource) PrefFail(@"link-only-no-readable-persisted-domain-preserved");
            else {
                if (!snapshot) {
                    snapshot = candidate ?: @{};
                    NSString *backup = PrefUnused(@"runtime-snapshot");
                    if (!backup || !PrefWrite(snapshot, backup) || !PrefWrite(snapshot, PrefFile)) snapshot = nil;
                }
                if (!snapshot) PrefFail(@"preference-snapshot-save-or-verification-failed");
                else {
                    ManagedDefaults = PrefKeep(standard); Values = [snapshot mutableCopy];
                    Fallback = PrefKeep([NSMutableDictionary dictionary]);
                    [Fallback addEntriesFromDictionary:[standard persistentDomainForName:NSGlobalDomain] ?: @{}];
                    [Fallback addEntriesFromDictionary:[standard volatileDomainForName:NSRegistrationDomain] ?: @{}];
                    [Fallback addEntriesFromDictionary:[standard volatileDomainForName:NSArgumentDomain] ?: @{}];
                    Pending = PrefKeep([NSMutableDictionary dictionary]); Removed = PrefKeep([NSMutableSet set]);
                    for (NSUInteger i = 0; i < count; i++) {
                        Method method = class_getInstanceMethod(cls, hooks[i].selector);
                        *hooks[i].original = (void *)method_getImplementation(method);
                        const char *types = method_getTypeEncoding(method);
                        if (!class_addMethod(cls, hooks[i].selector, hooks[i].hook, types))
                            class_replaceMethod(cls, hooks[i].selector, hooks[i].hook, types);
                    }
                    PrefActive = YES; PrefFailure = nil;
                    PrefRetireSources(); ready = YES;
                }
            }
        }
    } @finally { PrefRelease(fd); }
    PrefStatus(ready);
    return ready;
}

static BOOL ActivatePreferences(NSUserDefaults *standard) {
    BOOL wasActive = PrefActive;
    BOOL active = InstallPreferences(standard);
    if (!wasActive && active) {
        /* Preferences are active and the migration lock is released. Import
         * rules now so a pre-activation refresh cannot leave the new store
         * without customFiles. */
        @try { ICRRulesPreferencesDidActivate(standard); }
        @catch (NSException *exception) { (void)exception; }
    }
    return active;
}

BOOL ICRInstallRootHidePreferences(void) {
    return ActivatePreferences([NSUserDefaults standardUserDefaults]);
}

/* The main image may exchange its +standardUserDefaults aliases AFTER a
 * dependent dylib constructor. Hook BOTH slots and preserve both original
 * implementations. The native wrapper calls the other slot; activate only
 * after this two-slot chain has completed (including registerDefaultSettings).
 * This avoids eagerly invoking an unexchanged recursive IC_synchronize alias.
 */
static id (*Getter0)(id, SEL), (*Getter1)(id, SEL);
static NSUInteger GetterDepth, GetterMask;
static BOOL InstallingPreferences;
static id HookGetter(id self, SEL cmd, NSUInteger slot) {
    if (PrefActive) return slot ? Getter1(self, cmd) : Getter0(self, cmd);
    @synchronized([NSUserDefaults class]) {
        if (!GetterDepth) GetterMask = 0;
        GetterDepth++; GetterMask |= (1UL << slot);
        @try {
            id result = slot ? Getter1(self, cmd) : Getter0(self, cmd);
            if (GetterDepth == 1 && GetterMask == 3 && !InstallingPreferences && !PrefActive) {
                InstallingPreferences = YES;
                @try { ActivatePreferences(result); }
                @catch (NSException *exception) { (void)exception; PrefFail(@"preference-initialization-exception"); PrefStatus(NO); }
                @finally { InstallingPreferences = NO; }
            }
            return result;
        } @finally { GetterDepth--; }
    }
}
static id HookGetter0(id self, SEL cmd) { return HookGetter(self, cmd, 0); }
static id HookGetter1(id self, SEL cmd) { return HookGetter(self, cmd, 1); }
static void InstallPreferenceEntryHooks(void) {
    InstallLegacyLinkBlocker();
    if (Getter0 || Getter1) return;
    Method a = class_getClassMethod([NSUserDefaults class], @selector(standardUserDefaults));
    Method b = class_getClassMethod([NSUserDefaults class], @selector(IC_standardUserDefaults));
    if (!a || !b) return;
    Getter0 = (void *)method_getImplementation(a); Getter1 = (void *)method_getImplementation(b);
    method_setImplementation(a, (IMP)HookGetter0); method_setImplementation(b, (IMP)HookGetter1);
}

/* Independent late entry: a dependent dylib constructor may not see classes
 * or categories in the executable yet. A missing early method no longer
 * permanently disables initialization with no status at all. */
@interface ICRootHideLaunchObserver : NSObject
- (void)didLaunch:(id)notification;
@end
@implementation ICRootHideLaunchObserver
- (void)didLaunch:(id)notification {
    (void)notification;
    ICRInstallRootHideStorage();
    InstallLegacyLinkBlocker();
    PrefCleanupLegacyLink();
    InstallPreferenceEntryHooks();
    ICRInstallRootHidePreferences();
}
@end

#ifndef ICR_HOST_TEST
__attribute__((constructor)) static void InitializeRootHidePreferences(void) {
    @autoreleasepool {
        if ([[[NSBundle mainBundle] bundleIdentifier] isEqualToString:PrefDomain]) {
            InstallLegacyLinkBlocker();
            PrefCleanupLegacyLink();
            InstallPreferenceEntryHooks();
            id observer = [[ICRootHideLaunchObserver alloc] init];
            [[NSNotificationCenter defaultCenter] addObserver:observer selector:@selector(didLaunch:)
                name:@"UIApplicationDidFinishLaunchingNotification" object:nil];
            /* NotificationCenter does not retain selector observers. */
            static id LaunchObserver __attribute__((unused));
            LaunchObserver = observer;
        }
    }
}
#endif
