#ifdef ICR_HOST_TEST
#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#include <unistd.h>
#include <time.h>
#undef YES
#undef NO
#define YES ((BOOL)1)
#define NO ((BOOL)0)
#else
#import "FoundationMinimal.h"
#endif
#import "ICRootHideStorage.h"

/* Integration only: this library never deletes cache or Inbox files.
 * The original iCleaner engine handles Analyze/Clean and its test mode.
 */
@interface NSUserDefaults (ICRulesNative)
- (NSArray *)customFiles;
- (void)setCleanupStep:(NSString *)step enabled:(BOOL)enabled;
@end
@interface NSObject (ICRulesConversion)
+ (id)fromDictionary:(NSDictionary *)dictionary;
- (NSDictionary *)toDictionary;
@end

static NSString * const Version = @"2026.11.18.rh8";
static NSString * const ManagedKey = @"ICCustomRules.managed";
static NSString * const VersionKey = @"ICCustomRules.version";
static NSString * const BackupKey = @"ICCustomRules.original";
static NSString * const StatusKey = @"ICCustomRules.status";
static NSString * const StepKey = @"ICCustomRules.stepVersion";
static id (*OriginalCustomFiles)(id, SEL);
static id (*OriginalCleanupSteps)(id, SEL);
static BOOL Ready = NO;
static BOOL Running = NO;

static double MonotonicTime(void) {
#ifdef ICR_HOST_TEST
    struct timespec t = {0, 0};
    if (clock_gettime(CLOCK_MONOTONIC, &t)) return 0;
#else
    ICRTimespec t = {0, 0};
    /* Darwin CLOCK_MONOTONIC = 6. A failed clock still leaves the count cap. */
    if (clock_gettime(6, &t)) return 0;
#endif
    return (double)t.tv_sec + (double)t.tv_nsec / 1000000000.0;
}

static BOOL IsDirectory(NSFileManager *fm, NSString *path) {
    /* Never import a symlink as a cleanup target. */
    NSDictionary *a = [fm attributesOfItemAtPath:path error:NULL];
    return [[a objectForKey:NSFileType] isEqualToString:NSFileTypeDirectory];
}

static NSArray *Children(NSFileManager *fm, NSString *path) {
    NSArray *names = [fm contentsOfDirectoryAtPath:path error:NULL];
    return names ? [names sortedArrayUsingSelector:@selector(compare:)] : [NSArray array];
}

static NSString *Canonical(NSString *path) {
    return [[path stringByStandardizingPath] stringByResolvingSymlinksInPath];
}

static void AddDirectory(NSMutableArray *list, NSMutableSet *seen, NSFileManager *fm, NSString *path) {
    if (!IsDirectory(fm, path)) return;
    NSString *p = Canonical(path);
    if (![seen containsObject:p]) {
        [seen addObject:p];
        [list addObject:p];
    }
}

static void AddDirectoryUnder(NSMutableArray *list, NSMutableSet *seen, NSFileManager *fm, NSString *root, NSString *relative) {
    if (!IsDirectory(fm, root)) return;
    NSString *path = [root stringByAppendingPathComponent:relative];
    /* A symlink in Library/Documents/var must not redirect an otherwise
     * innocent-looking cache/Inbox path outside the trusted container.
     */
    NSString *prefix = [NSString stringWithFormat:@"%@/", Canonical(root)];
    if ([Canonical(path) hasPrefix:prefix]) AddDirectory(list, seen, fm, path);
}

static void FindInbox(NSFileManager *fm, NSString *root, NSMutableArray *inboxes, NSMutableSet *seen, NSUInteger *scanned, double deadline, BOOL *limited) {
    /* Breadth-first, skipping symlink entries. Finite work/time/depth limits
     * bound the fallback scan; an individual filesystem call can still block.
     */
    NSMutableArray *queue = [NSMutableArray array];
    [queue addObject:root];
    for (NSUInteger i = 0; i < [queue count]; i++) {
      @autoreleasepool {
        if (*scanned >= 60000 || MonotonicTime() > deadline) { *limited = YES; return; }
        NSString *dir = [queue objectAtIndex:i];
        (*scanned)++;
        if ([[dir lastPathComponent] isEqualToString:@"Inbox"] &&
            [[[dir stringByDeletingLastPathComponent] lastPathComponent] isEqualToString:@"Documents"]) {
            AddDirectory(inboxes, seen, fm, dir);
            continue;
        }
        NSString *relative = [dir substringFromIndex:[root length]];
        if ([[relative componentsSeparatedByString:@"/"] count] > 24) { *limited = YES; continue; }
        NSArray *names = Children(fm, dir);
        for (NSUInteger j = 0; j < [names count]; j++) {
            if (j % 128 == 0 && MonotonicTime() > deadline) { *limited = YES; return; }
            NSString *name = [names objectAtIndex:j];
            if ([name isEqualToString:@"."] || [name isEqualToString:@".."] ||
                [name isEqualToString:@"dev"] || [name isEqualToString:@"proc"] ||
                [name isEqualToString:@"sys"] || [name isEqualToString:@".git"]) continue;
            NSString *p = [dir stringByAppendingPathComponent:name];
            if (IsDirectory(fm, p)) {
                if ([queue count] >= 60000) { *limited = YES; return; }
                [queue addObject:p];
            }
        }
      }
    }
}

static void AddContainerInboxes(NSFileManager *fm, NSString *parent, NSMutableArray *inboxes, NSMutableSet *seen) {
    if (!IsDirectory(fm, parent)) return;
    NSArray *names = Children(fm, parent);
    for (NSUInteger i = 0; i < [names count]; i++) {
      @autoreleasepool {
        NSString *container = [parent stringByAppendingPathComponent:[names objectAtIndex:i]];
        NSString *prefix = [NSString stringWithFormat:@"%@/", Canonical(parent)];
        if ([Canonical(container) hasPrefix:prefix])
            AddDirectoryUnder(inboxes, seen, fm, container, @"Documents/Inbox");
      }
    }
}

static NSDictionary *Rule(NSString *path, NSUInteger mode, NSString *suffix) {
    NSMutableDictionary *r = [NSMutableDictionary dictionary];
    [r setObject:path forKey:@"filePath"];
    [r setObject:NSFileTypeDirectory forKey:@"fileType"];
    /* Verified against ICCustomFile::fromDictionary in the supplied binary:
     * 0=whole directory; 1=contents (files+subfolders); 2=files only.
     */
    [r setObject:[NSNumber numberWithUnsignedInteger:mode] forKey:@"customFolderSetting"];
    [r setObject:@NO forKey:@"recursive"];
    if (suffix) [r setObject:suffix forKey:@"endPattern"];
    return r;
}

static NSArray *GenerateRules(NSFileManager *fm, NSUInteger *cacheCount, NSUInteger *inboxCount, BOOL *limited) {
    NSMutableArray *rules = [NSMutableArray array];
    /* Always keep these five visible; absent directories are skipped by
     * the cleaner. AssetsV2 is deliberately NOT included.
     */
    NSArray *system = @[@"/var/db/uuidtext", @"/var/db/diagnostics/Persist", @"/var/db/diagnostics/Signpost",
                        @"/var/db/diagnostics/Special", @"/var/mobile/Library/Caches"];
    for (NSUInteger i = 0; i < [system count]; i++)
        [rules addObject:Rule([system objectAtIndex:i], 1, nil)];

    NSMutableArray *caches = [NSMutableArray array];
    NSMutableSet *cacheSeen = [NSMutableSet set];
    NSString *apps = @"/var/mobile/Containers/Data/Application";
    NSArray *ids = Children(fm, apps);
    NSMutableArray *inboxes = [NSMutableArray array];
    NSMutableSet *inboxSeen = [NSMutableSet set];
    for (NSUInteger i = 0; i < [ids count]; i++) {
      @autoreleasepool {
        NSString *container = [apps stringByAppendingPathComponent:[ids objectAtIndex:i]];
        if (!IsDirectory(fm, container)) continue;
        AddDirectoryUnder(caches, cacheSeen, fm, container, @"Library/Caches");
        AddDirectoryUnder(inboxes, inboxSeen, fm, container, @"Documents/Inbox");
      }
    }
    AddDirectoryUnder(inboxes, inboxSeen, fm, @"/private/var/mobile/Library/Application Support/Containers/wiki.qaq.TrollFools", @"Documents/Inbox");

    NSMutableArray *roots = [NSMutableArray array];
    NSMutableSet *rootSeen = [NSMutableSet set];
    NSString *activeRoot = ICRActiveJailbreakRoot();
    if (activeRoot) AddDirectory(roots, rootSeen, fm, activeRoot);
    /* /var/jb may be a symlink. Resolve it explicitly as a trusted jailbreak
     * entry point; targets beneath it are still checked for symlinks.
     */
    NSString *jb = Canonical(@"/var/jb");
    if (![jb isEqualToString:@"/"] && ![jb isEqualToString:@"/private/var"] &&
        ![jb isEqualToString:@"/var"] && IsDirectory(fm, jb))
        AddDirectory(roots, rootSeen, fm, jb);

    NSString *groups = @"/private/var/mobile/Containers/Shared/AppGroup";
    NSArray *names = Children(fm, groups);
    for (NSUInteger i = 0; i < [names count]; i++) {
        NSString *name = [names objectAtIndex:i];
        if ([name hasPrefix:@".jbroot-"])
            AddDirectory(roots, rootSeen, fm, [groups stringByAppendingPathComponent:name]);
    }
    NSString *preboot = @"/private/preboot";
    NSArray *boots = Children(fm, preboot);
    for (NSUInteger i = 0; i < [boots count]; i++) {
        NSString *boot = [preboot stringByAppendingPathComponent:[boots objectAtIndex:i]];
        if (!IsDirectory(fm, boot)) continue;
        NSArray *dopamines = Children(fm, boot);
        for (NSUInteger j = 0; j < [dopamines count]; j++) {
            NSString *name = [dopamines objectAtIndex:j];
            if ([name hasPrefix:@"dopamine-"])
                AddDirectory(roots, rootSeen, fm, [[boot stringByAppendingPathComponent:name] stringByAppendingPathComponent:@"procursus"]);
        }
    }
    NSUInteger scanned = 0;
    /* Import the script's known container locations before the bounded
     * fallback scan, so a large unrelated tree cannot starve these rules.
     */
    for (NSUInteger i = 0; i < [roots count]; i++) {
        NSString *root = [roots objectAtIndex:i];
        AddDirectoryUnder(inboxes, inboxSeen, fm, root, @"var/mobile/RootHidePatcher");
        AddDirectoryUnder(inboxes, inboxSeen, fm, root, @"var/mobile/RootHidePatcher/.Inbox");
        NSArray *parents = @[@"var/mobile/Library/Application Support/Containers", @"var/mobile/Containers/Data/Application"];
        NSString *prefix = [NSString stringWithFormat:@"%@/", root];
        for (NSUInteger j = 0; j < [parents count]; j++) {
            NSString *parent = [root stringByAppendingPathComponent:[parents objectAtIndex:j]];
            if ([Canonical(parent) hasPrefix:prefix]) AddContainerInboxes(fm, parent, inboxes, inboxSeen);
        }
    }
    double deadline = MonotonicTime() + 3.0;
    for (NSUInteger i = 0; i < [roots count]; i++)
        FindInbox(fm, [roots objectAtIndex:i], inboxes, inboxSeen, &scanned, deadline, limited);
    for (NSUInteger i = 0; i < [caches count]; i++)
        [rules addObject:Rule([caches objectAtIndex:i], 1, nil)];
    NSArray *extensions = @[@".deb", @".dylib", @".zip", @".ipa", @".tipa", @".ipcc", @".png"];
    for (NSUInteger i = 0; i < [inboxes count]; i++)
        for (NSUInteger j = 0; j < [extensions count]; j++)
            [rules addObject:Rule([inboxes objectAtIndex:i], 2, [extensions objectAtIndex:j])];
    *cacheCount = [caches count];
    *inboxCount = [inboxes count];
    return rules;
}

static BOOL IsLegacyBadRule(NSDictionary *r) {
    /* Only migrate the exact malformed rules from the supplied old package.
     * Other user-authored rules, including deliberate Assets rules, survive.
     */
    id type = [r objectForKey:@"fileType"];
    id mode = [r objectForKey:@"customFolderSetting"];
    if (![type isKindOfClass:[NSString class]] || ![type isEqualToString:@"folder"] ||
        ![mode isKindOfClass:[NSString class]]) return NO;
    NSString *p = [r objectForKey:@"filePath"];
    NSArray *oldPaths = @[@"/var/MobileAsset/AssetsV2", @"/var/db/uuidtext", @"/var/db/diagnostics/Persist",
                         @"/var/db/diagnostics/Signpost", @"/var/db/diagnostics/Special", @"/var/mobile/Library/Caches"];
    if ([mode isEqualToString:@"wholeFolder"] && [oldPaths containsObject:p]) return YES;
    return [p isEqualToString:@"/var/mobile/Containers/Data/Application"] &&
           [mode isEqualToString:@"filesAndSubfolders"] &&
           [[r objectForKey:@"startPattern"] isEqualToString:@"Library/Caches/"];
}

static void RecordFailure(NSUserDefaults *defaults, NSString *message) {
    /* Fail closed without repeatedly rescanning on each settings getter. */
    Ready = YES;
    @try {
        NSDictionary *status = @{@"version":Version, @"date":[NSDate date], @"success":@NO, @"error":message};
        [defaults setObject:status forKey:StatusKey];
        [defaults synchronize];
        NSString *state = ICRStatusDirectory();
        if (state) [status writeToFile:[state stringByAppendingPathComponent:@"custom-rules-status.plist"] atomically:YES];
    } @catch (NSException *ignored) {
        /* The original app remains usable even if preferences/storage fail. */
    }
}

static void Refresh(NSUserDefaults *defaults) {
    @synchronized([NSUserDefaults class]) {
        if (Ready || Running) return;
        Running = YES;
        @try {
            NSFileManager *fm = [NSFileManager defaultManager];
            Class customClass = NSClassFromString(@"ICCustomFile");
            if (!customClass || ![customClass respondsToSelector:@selector(fromDictionary:)] ||
                ![defaults respondsToSelector:@selector(setCleanupStep:enabled:)]) {
                RecordFailure(defaults, @"Native custom-rule API unavailable");
                return;
            }

            NSArray *raw = [defaults arrayForKey:@"customFiles"] ?: [NSArray array];
            NSArray *previous = [defaults arrayForKey:ManagedKey] ?: [NSArray array];
            NSUInteger cacheCount = 0, inboxCount = 0;
            BOOL limited = NO;
            NSArray *discovered = GenerateRules(fm, &cacheCount, &inboxCount, &limited);
            NSMutableArray *generated = [NSMutableArray array];
            /* Canonicalize only our rules through the actual native codec.
             * Existing user dictionaries are kept byte-for-value intact,
             * including metadata unknown to the native serializer.
             */
            for (NSUInteger i = 0; i < [discovered count]; i++) {
                id object = [customClass fromDictionary:[discovered objectAtIndex:i]];
                NSDictionary *rule = [object toDictionary];
                if (![rule isKindOfClass:[NSDictionary class]]) {
                    RecordFailure(defaults, @"Native rule conversion failed");
                    return;
                }
                [generated addObject:rule];
            }
            /* A limited scan must not drop previously found Inbox rules
             * that remain present and unedited in the user's list.
             */
            if (limited) {
                for (NSUInteger i = 0; i < [previous count]; i++) {
                    id r = [previous objectAtIndex:i];
                    if (![r isKindOfClass:[NSDictionary class]] || ![raw containsObject:r]) continue;
                    if ([[r objectForKey:@"customFolderSetting"] unsignedIntegerValue] == 2 &&
                        [[r objectForKey:@"fileType"] isEqualToString:NSFileTypeDirectory] &&
                        IsDirectory(fm, [r objectForKey:@"filePath"]) && ![generated containsObject:r])
                        [generated addObject:r];
                }
            }
            NSMutableArray *merged = [NSMutableArray array];
            NSMutableArray *managed = [NSMutableArray array];
            for (NSUInteger i = 0; i < [raw count]; i++) {
                id r = [raw objectAtIndex:i];
                if (![r isKindOfClass:[NSDictionary class]]) {
                    RecordFailure(defaults, @"Existing customFiles contains a non-dictionary; original list left unchanged");
                    return;
                }
                /* A rule this component created is dropped only when a complete
                 * scan proved its directory is gone. A time- or entry-limited
                 * scan, or a missing directory we never resolved, must not be
                 * read as "the user deleted the rule". */
                BOOL owned = [previous containsObject:r];
                BOOL confirmedGone = !IsDirectory(fm, [r objectForKey:@"filePath"]);
                if (!owned || !confirmedGone || limited) {
                    if (!IsLegacyBadRule(r)) [merged addObject:r];
                }
            }
            for (NSUInteger i = 0; i < [generated count]; i++) {
                NSDictionary *r = [generated objectAtIndex:i];
                if (![merged containsObject:r]) {
                    [merged addObject:r];
                    [managed addObject:r];
                }
            }
            BOOL first = ![defaults objectForKey:VersionKey];
            BOOL backupSkipped = NO;
            if (first) {
                NSDictionary *snapshot = [defaults dictionaryRepresentation];
                NSString *state = ICRStateDirectory();
                NSString *backup = nil;
                if (state) {
                    NSString *dir = [state stringByAppendingPathComponent:@"CustomRulesBackup"];
                    if ([fm createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:NULL])
                        backup = [dir stringByAppendingPathComponent:[NSString stringWithFormat:@"before-custom-rules-%u.plist", getuid()]];
                }
                /* The disk copy is a convenience, never a precondition. When the
                 * storage migration is blocked, refusing to import would leave the
                 * user with an empty rule list, which is the reported symptom. */
                if (!backup) backupSkipped = YES;
                else if (![fm fileExistsAtPath:backup isDirectory:NULL] && ![snapshot writeToFile:backup atomically:YES])
                    backupSkipped = YES;
                if (![defaults objectForKey:BackupKey]) [defaults setObject:raw forKey:BackupKey];
            }
            /* Native -customFiles reads this dictionary array directly.
             * Do not reserialize unrelated existing rules through its setter.
             */
            if (![raw isEqualToArray:merged]) [defaults setObject:merged forKey:@"customFiles"];
            /* Re-arm the cleanup step once per build. Enabling it on every launch
             * would fight the user; enabling it only on the very first import is
             * what left imported rules visible but unchecked after a storage or
             * preference migration moved the rules into a fresh store. */
            id marker = [defaults objectForKey:StepKey];
            BOOL stepKnown = [marker isKindOfClass:[NSString class]] && [marker isEqualToString:Version];
            if (first || !stepKnown) {
                [defaults setCleanupStep:@"CUSTOMFILES" enabled:YES];
                [defaults setObject:Version forKey:StepKey];
            }
            [defaults setObject:managed forKey:ManagedKey];
            [defaults setObject:Version forKey:VersionKey];
            NSDictionary *status = @{@"version": Version, @"date": [NSDate date], @"success":@YES,
                @"appCaches": [NSNumber numberWithUnsignedInteger:cacheCount],
                @"inboxDirectories": [NSNumber numberWithUnsignedInteger:inboxCount],
                @"managedRuleCount": [NSNumber numberWithUnsignedInteger:[managed count]],
                @"generatedRuleCount": [NSNumber numberWithUnsignedInteger:[generated count]],
                @"scanLimited": [NSNumber numberWithBool:limited], @"assetsV2Included": @NO,
                @"preferencesBackupSkipped": [NSNumber numberWithBool:backupSkipped],
                @"cleanupStepEnabled": [NSNumber numberWithBool:(first || !stepKnown)]};
            [defaults setObject:status forKey:StatusKey];
            [defaults synchronize];
            /* Do not redo a full scan on every getter if preferences are
             * temporarily unable to flush. The next process launch retries.
             */
            Ready = YES;
            NSString *state = ICRStatusDirectory();
            if (state) [status writeToFile:[state stringByAppendingPathComponent:@"custom-rules-status.plist"] atomically:YES];
        } @catch (NSException *exception) {
            RecordFailure(defaults, [exception reason] ?: @"Rule import failed");
        } @finally {
            Running = NO;
        }
    }
}

void ICRRulesPreferencesDidActivate(NSUserDefaults *defaults) {
    if (!defaults) return;
    @synchronized([NSUserDefaults class]) {
        /* No pre-activation getter touched the rules and this active store
         * already has an import marker: do not rescan on every launch. */
        if (!Running && !Ready && [defaults objectForKey:VersionKey]) return;
        /* A getter may have refreshed the abandoned native domain before the
         * file-backed store was active. Always force one import through the
         * now-active hooks so its rules land in the new preference file. */
        Ready = NO;
        if (Running) return;
        Refresh(defaults);
    }
}

static id HookCustomFiles(id self, SEL cmd, ...) {
    Refresh((NSUserDefaults *)self);
    return OriginalCustomFiles(self, cmd);
}
static id HookCleanupSteps(id self, SEL cmd, ...) {
    Refresh((NSUserDefaults *)self);
    return OriginalCleanupSteps(self, cmd);
}

#ifndef ICR_HOST_TEST
extern void ICRInstallFooterBranding(void);
__attribute__((constructor)) static void Initialize(void) {
    @autoreleasepool {
        ICRInstallRootHideStorage();
        ICRInstallFooterBranding();
        Method custom = class_getInstanceMethod([NSUserDefaults class], @selector(customFiles));
        Method steps = class_getInstanceMethod([NSUserDefaults class], @selector(cleanupSteps));
        if (!custom || !steps) return;
        OriginalCustomFiles = (void *)method_setImplementation(custom, (IMP)HookCustomFiles);
        OriginalCleanupSteps = (void *)method_setImplementation(steps, (IMP)HookCleanupSteps);
    }
}
#endif
