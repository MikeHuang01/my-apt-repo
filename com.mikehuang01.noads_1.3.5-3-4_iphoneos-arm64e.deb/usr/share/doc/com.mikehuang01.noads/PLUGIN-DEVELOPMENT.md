# NoAds 插件开发说明

本文件随 NoAds 安装，供后续维护者从安装包中查看。只接入获得授权、不会绕过第三方付费权益或访问控制的功能模块。

## 结构

- `Tweak.xm` 是统一入口。先检查 NoAds 总开关，再按 `NoAdsModules.json` 查目标 Bundle；专用规则由应用开关控制，通用功能由功能总开关和应用选择共同控制。
- `NoAdsModules.json` 是运行时应用到规则模块的清单。`config/apps.json` 提供设置界面名称、版本和功能说明；`config/module-sources.json` 记录载荷来源、SHA-256、架构及适配方式。
- 每个专用载荷只应在自己的应用进程加载。新应用支持应增加明确的 Bundle ID、描述和测试版本，不要把样例 Bundle ID 写成通用功能门槛。
- 通用能力应使用明确的 feature key，在 `GenericFeatures` 中实现共享逻辑，并由已安装应用列表中的用户选择驱动。不要把应用私有规则塞入通用引擎。

## 添加规则

1. 确认模块来源、许可/授权范围、目标 Bundle ID、CPU slice、最低系统版本、依赖库和初始化行为。记录原文件 SHA-256；来源改变时重新审查，不覆盖旧样本。
2. 先静态检查 Mach-O 架构、加载命令、符号/类和启动初始化。不要仅凭文件名或作者说明推断能力；不得把付费权益绕过模块加入本项目。
3. 将模块加入 `config/module-sources.json` 和 `NoAdsModules.json`，并在应用目录增加名称、经确认的功能说明及实际测试版本。所有开关都必须汇入统一总开关和应用开关门控。
4. 依赖路径必须适配 RootHide 容器；签名、slice 和 arm64e ABI 转换按项目构建流程执行。禁止把 arm64 payload 冒充 arm64e 或跳过 ABI 校验。
5. 运行 `scripts/build-deb.sh`。包校验应确认控制字段唯一、模块映射无重复、二进制已签名、依赖路径正确、设置 bundle 不含不兼容的 block ABI 对象。
6. 真机验证需覆盖：目标应用能冷启动、关闭开关后规则不命中、重新开启后规则生效、前后台往返、无关页面正常。记录设备/iOS/应用版本及观察结果；编译成功不等于功能通过。

## iOS 16 arm64e 设置注意事项

- 偏好设置 bundle 的类层级要直接继承系统 `PSViewController` 或常规 UIKit 控制器。避免新增自定义 Objective-C 控制器父类：本项目 `Preferences-2026-11-05-135113.ips` 在 `objc map_images/readClass` 阶段崩溃，寄存器关联到 `NAAppsController` superclass 元数据。
- 页面应通过 Preferences 的 `pushController:animate:` 导航，并实现 suspended-state 恢复；不要在 `viewDidAppear` 才从主页延迟推子页。
- 当前设置 bundle 禁止捕获 block 的 `UIAlertAction`、`dispatch_once` 初始化 block 和全局/栈 block 对象。使用 target/action、普通控制器方法或 `+initialize`。
- 状态开关只由开关控件的 value-changed 事件修改。列表重排应在下一次进入页面时应用，不能在用户操作时移动卡片。
- 滚动和图标应按需复用缓存；不要在 cell 布局、滚动回调中重复 LaunchServices 枚举、磁盘读取或同步网络请求。

## 隐私与发布

- 不记录账户、聊天、播放内容、收据或个人文件。日志与诊断导出当前已删除；新增功能默认不产生日志或诊断文件。
- 只维护用户授权的规则。不能确认适用范围时先隔离该模块，不把安装成功、注入提示或状态缓存写成“功能验证通过”。
- 正式包必须更新合理的 Debian 修订号。只有用户明确要求时才复用已发布版本；复用前备份旧成品并核对版本字段。
