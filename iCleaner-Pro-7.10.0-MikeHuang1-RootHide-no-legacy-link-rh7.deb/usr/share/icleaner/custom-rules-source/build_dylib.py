"""Cross-build a Mach-O using declaration-only, symbol-checked SDK stubs."""
import json
import pathlib
import struct
import subprocess

ROOT = pathlib.Path(__file__).resolve().parent
CLANG = '/usr/bin/clang'
LINKER = '/usr/lib/llvm-21/bin/ld64.lld'

def run(args):
    subprocess.run([str(a) for a in args], check=True)

def object_symbols(path):
    b = path.read_bytes()
    ncmds = struct.unpack_from('<I', b, 16)[0]
    p = 32
    result = []
    defined = set()
    for _ in range(ncmds):
        cmd, size = struct.unpack_from('<II', b, p)
        if cmd == 2:
            symoff, nsyms, stroff, strsize = struct.unpack_from('<IIII', b, p+8)
            for i in range(nsyms):
                sx, typ, sec, desc, val = struct.unpack_from('<IBBHQ', b, symoff+i*16)
                name = b[stroff+sx:b.index(0, stroff+sx)].decode()
                if typ & 0xe == 0:
                    result.append(name)
                elif typ & 1:
                    defined.add(name)
        p += size
    return set(result), defined

def build():
    objects = []
    undefined, defined = set(), set()
    for source in ['ICCustomRules', 'ICFooterBranding', 'ICRootHideStorage', 'ICRootHidePreferences']:
        obj = ROOT/(source+'.o')
        run([CLANG, '--target=arm64-apple-ios15.0', '-fobjc-arc', '-fobjc-exceptions',
             '-fvisibility=hidden', '-Os', '-Wall', '-Wextra', '-Werror', '-c',
             ROOT/(source+'.m'), '-o', obj])
        objects.append(obj)
        u, d = object_symbols(obj)
        undefined.update(u)
        defined.update(d)
    libraries = {
        'Foundation': ('/System/Library/Frameworks/Foundation.framework/Foundation', []),
        'CoreFoundation': ('/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation', []),
        'UIKit': ('/System/Library/Frameworks/UIKit.framework/UIKit', []),
        'objc': ('/usr/lib/libobjc.A.dylib', []),
        'System': ('/usr/lib/libSystem.B.dylib', []),
        'roothide': ('@loader_path/.jbroot/usr/lib/libroothide.dylib', []),
    }
    symbols = sorted(undefined - defined)
    for s in symbols:
        if s.startswith(('_OBJC_CLASS_$_UI', '_OBJC_METACLASS_$_UI', '_UIAccessibility')):
            lib = 'UIKit'
        elif s.startswith(('_OBJC_CLASS_$_', '_OBJC_METACLASS_$_', '_NS')) or s in ('___NSArray0__', '___NSDictionary0__'):
            lib = 'Foundation'
        elif s == '___CFConstantStringClassReference':
            lib = 'CoreFoundation'
        elif 'objc' in s or s in ('_class_getInstanceMethod', '_class_getClassMethod', '_method_setImplementation', '_method_getImplementation', '_method_getTypeEncoding', '_class_addMethod', '_class_replaceMethod'):
            lib = 'objc'
        elif s in ('_getuid', '_clock_gettime', '_rename', '_open', '_flock', '_close', '_unlink', '_chmod', '___error', '__Unwind_Resume', '___stack_chk_guard', '___stack_chk_fail'):
            lib = 'System'
        elif s == '_jbroot':
            lib = 'roothide'
        else:
            raise RuntimeError('Unclassified undefined symbol: '+s)
        libraries[lib][1].append(s)
    stubs = ROOT/'sdk-stubs'
    stubs.mkdir(exist_ok=True)
    inputs = []
    for name, (install, exported) in libraries.items():
        if not exported:
            continue
        path = stubs/(name+'.tbd')
        path.write_text('--- !tapi-tbd\ntbd-version: 4\ntargets: [ arm64-ios ]\n'
                        'install-name: '+json.dumps(install)+'\ncurrent-version: 1\ncompatibility-version: 1\n'
                        'exports:\n  - targets: [ arm64-ios ]\n    symbols: '+json.dumps(exported)+'\n...\n')
        inputs.append(path)
    run([LINKER, '-dylib', '-arch', 'arm64', '-platform_version', 'ios', '15.0', '15.5',
         '-install_name', '@loader_path/.jbroot/usr/lib/icleaner/ICCustomRules.dylib',
         '-adhoc_codesign', '-dead_strip', '-o', ROOT/'ICCustomRules.dylib',
         *objects, *inputs])
    (ROOT/'imports.json').write_text(json.dumps({k:{'path':p, 'symbols':s}
                                                for k,(p,s) in libraries.items()}, indent=2))
    print('Compiled and linked:', ROOT/'ICCustomRules.dylib')
    print('Checked imports:', json.dumps(symbols, indent=2))

if __name__ == '__main__':
    build()
