"""Disable ONE void Objective-C method; preserve layout, entitlements and loads.

Only hash-pinned baseline binaries without a CMS signature are accepted. Rehash
their existing CodeDirectories in place (RootHide/ldid format), no external SDK.
"""
import hashlib
import struct

INPUT_HASHES = {
    'a13e3248c9e601dc9d77faa09dae0fd92353ec3c623a83db40d0b71cb52e8043',
    '80270d754fb6a141afda567085fcb3371cef4f29770ca13ccfb14b261b66f068',
}
RET = bytes.fromhex('c0035fd6')


def layout(b):
    assert b[:4] == bytes.fromhex('cffaedfe')
    segments, sections, signature = [], {}, None
    p = 32
    for _ in range(struct.unpack_from('<I', b, 16)[0]):
        command, size = struct.unpack_from('<II', b, p)
        assert size >= 8 and p + size <= len(b)
        if command == 0x19:
            vm, vmsize, off, filesize = struct.unpack_from('<QQQQ', b, p + 24)
            segments.append((vm, off, filesize))
            for j in range(struct.unpack_from('<I', b, p + 64)[0]):
                s = p + 72 + j * 80
                name = b[s:s + 16].rstrip(b'\0').decode()
                sections[name] = struct.unpack_from('<QQI', b, s + 32)
        if command == 0x1d:
            signature = struct.unpack_from('<II', b, p + 8)
        p += size
    assert signature
    return segments, sections, signature


def method_offset(b):
    segments, sections, _ = layout(b)

    def offset(v):
        return next(off + v - vm for vm, off, size in segments if vm <= v < vm + size)

    def pointer(v):
        return struct.unpack_from('<Q', b, offset(v))[0]

    def string(v):
        p = offset(v)
        return b[p:b.index(0, p)].decode()

    _, size, off = sections['__objc_classlist']
    found = []
    for p in range(off, off + size, 8):
        cls = struct.unpack_from('<Q', b, p)[0]
        ro = pointer(cls + 32) & ~7
        if string(pointer(ro + 24)) != 'ICAppDelegate':
            continue
        methods = pointer(ro + 32)
        flags, count = struct.unpack_from('<II', b, offset(methods))
        stride = flags & 0xfffc
        for i in range(count):
            entry = methods + 8 + i * stride
            q = offset(entry)
            if flags & 0x80000000:
                name = entry + struct.unpack_from('<i', b, q)[0]
                if not flags & 0x40000000:
                    name = pointer(name)
                types = entry + 4 + struct.unpack_from('<i', b, q + 4)[0]
                imp = entry + 8 + struct.unpack_from('<i', b, q + 8)[0]
            else:
                name, types, imp = struct.unpack_from('<QQQ', b, q)
            if string(name) == 'symlinkPreferenceFile':
                assert string(types).startswith('v'), 'Must be a void method'
                found.append((offset(imp), imp))
    assert len(found) == 1
    return found[0]


def patch_binary(original):
    digest = hashlib.sha256(original).hexdigest()
    assert digest in INPUT_HASHES, 'Unknown binary: refuse guessed offsets'
    off, address = method_offset(original)
    assert address == 0x10007cd94 and off == 0x7cd94
    assert original[off:off + 16].hex() == 'ff8301d1fa6701a9f85f02a9f65703a9'
    result = bytearray(original)
    result[off:off + 4] = RET
    sigoff, siglen = layout(original)[2]
    magic, length, count = struct.unpack_from('>III', original, sigoff)
    assert magic == 0xfade0cc0 and length <= siglen
    slots = [struct.unpack_from('>II', original, sigoff + 12 + i * 8) for i in range(count)]
    assert all(slot != 0x10000 for slot, _ in slots), 'CMS signature cannot be rehashed'
    changed_hash_ranges = []
    for slot, relative in slots:
        if slot not in (0, 0x1000, 0x1001, 0x1002, 0x1003, 0x1004, 0x1005):
            continue
        cd = sigoff + relative
        hash_offset, _, _, pages, limit = struct.unpack_from('>5I', original, cd + 16)
        hash_size, hash_type, _, page_exp = struct.unpack_from('4B', original, cd + 36)
        assert limit == sigoff and hash_type in (1, 2, 3, 4)
        hasher = {1: hashlib.sha1, 2: hashlib.sha256, 3: hashlib.sha256, 4: hashlib.sha384}[hash_type]
        page = off // (1 << page_exp)
        start, end = page * (1 << page_exp), min((page + 1) * (1 << page_exp), limit)
        assert page < pages and off + 4 <= end
        position = cd + hash_offset + page * hash_size
        result[position:position + hash_size] = hasher(result[start:end]).digest()[:hash_size]
        changed_hash_ranges.append((position, position + hash_size))
    assert changed_hash_ranges
    allowed = set(range(off, off + 4))
    for start, end in changed_hash_ranges:
        allowed.update(range(start, end))
    assert len(result) == len(original)
    assert all(a == b or i in allowed for i, (a, b) in enumerate(zip(original, result)))
    assert method_offset(result) == (off, address)
    report = {'method': '-[ICAppDelegate symlinkPreferenceFile]',
              'virtual_address': hex(address), 'file_offset': hex(off),
              'old_instruction_hex': original[off:off + 4].hex(), 'new_instruction_hex': RET.hex(),
              'behavior': 'immediate return, independent of dylib initialization and preference migration',
              'only_code_change_bytes': 4, 'signature_code_directories_rehashed': len(changed_hash_ranges),
              'original_entitlements_and_load_commands_preserved': True,
              'input_sha256': digest, 'output_sha256': hashlib.sha256(result).hexdigest()}
    return bytes(result), report


def verify_patch(original, patched):
    expected, report = patch_binary(original)
    assert patched == expected
    assert patched[method_offset(patched)[0]:method_offset(patched)[0] + 4] == RET
    return report
