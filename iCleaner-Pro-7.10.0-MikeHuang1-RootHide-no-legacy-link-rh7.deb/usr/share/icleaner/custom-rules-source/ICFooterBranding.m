#ifdef ICR_UI_HOST_TEST
#import "UIKitTestDoubles.h"
#else
#import "UIKitMinimal.h"
#endif

static NSString * const RepositoryURL = @"https://mikehuang01.github.io/my-apt-repo/v3";
static NSString * const CreditLine = @"二改MikeHuang1";
static id (*OriginalCopyrightFooter)(id, SEL);
static Class CleanControllerClass;

/* One recognizer per footer; no associated objects, retained targets,
 * observers, timers, URL loading, or unrelated UI hooks are needed.
 */
@interface ICRRepositoryLongPress : UILongPressGestureRecognizer
@end
@implementation ICRRepositoryLongPress
- (id)init {
    self = [super initWithTarget:nil action:NULL];
    if (self) {
        [self addTarget:self action:@selector(copyRepository:)];
        [self setMinimumPressDuration:0.5];
        [self setCancelsTouchesInView:NO];
    }
    return self;
}
- (void)copyRepository:(UIGestureRecognizer *)recognizer {
    /* Began = 1. Changed/Ended must not repeatedly rewrite the pasteboard. */
    if ([recognizer state] != 1) return;
    [[UIPasteboard generalPasteboard] setString:RepositoryURL];
    UINotificationFeedbackGenerator *feedback = [[UINotificationFeedbackGenerator alloc] init];
    [feedback notificationOccurred:0]; /* UINotificationFeedbackTypeSuccess */
    UIAccessibilityPostNotification(UIAccessibilityAnnouncementNotification, @"越狱源地址已复制");
}
@end

static id HookCopyrightFooter(id self, SEL cmd, ...) {
    UILabel *footer = OriginalCopyrightFooter(self, cmd);
    if (![self isKindOfClass:CleanControllerClass] || ![footer isKindOfClass:[UILabel class]]) return footer;
    NSString *addition = [NSString stringWithFormat:@"\n%@\n越狱源%@", CreditLine, RepositoryURL];
    NSString *text = [footer text];
    if (![text length]) return footer;
    if (![text hasSuffix:addition]) [footer setText:[NSString stringWithFormat:@"%@%@", text, addition]];
    /* Keep the actual native footer label, including font/color/alignment,
     * theme handling and unlimited line count. Native sizeToFitWithWidth:
     * runs AFTER this getter, so its footer height includes the new lines.
     */
    [footer setUserInteractionEnabled:YES];
    [footer setAccessibilityHint:@"长按复制越狱源地址"];
    NSArray *gestures = [footer gestureRecognizers];
    for (NSUInteger i = 0; i < [gestures count]; i++)
        if ([[gestures objectAtIndex:i] isKindOfClass:[ICRRepositoryLongPress class]]) return footer;
    [footer addGestureRecognizer:[[ICRRepositoryLongPress alloc] init]];
    return footer;
}

void ICRInstallFooterBranding(void) {
    if (OriginalCopyrightFooter) return;
    CleanControllerClass = NSClassFromString(@"ICCleanViewController");
    Class base = NSClassFromString(@"ICTableViewController");
    Method method = class_getInstanceMethod(base, @selector(copyrightFooter));
    if (!CleanControllerClass || !method) return;
    OriginalCopyrightFooter = (void *)method_setImplementation(method, (IMP)HookCopyrightFooter);
}
