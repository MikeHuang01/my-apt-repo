import io
import pathlib
import subprocess
import tarfile
import unittest

from patch_legacy_link import patch_binary, verify_patch
from validate_roothide import inspect

ROOT = pathlib.Path(__file__).resolve().parent


class LegacyLinkPatchTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        raw = subprocess.check_output(['dpkg-deb', '--fsys-tarfile', str(ROOT / 'inputs/rh2-payload.fixture')])
        with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
            cls.binaries = {name: archive.extractfile(name).read() for name in (
                './Applications/iCleaner.app/iCleaner',
                './var/mobile/Library/pkgmirror/Applications/iCleaner.app/iCleaner')}

    def test_active_and_mirror_binaries_only_patch_known_method(self):
        for original in self.binaries.values():
            patched, evidence = patch_binary(original)
            self.assertEqual(verify_patch(original, patched), evidence)
            self.assertEqual(len(patched), len(original))
            self.assertEqual(original[:0x7cd94], patched[:0x7cd94])
            self.assertEqual(patched[0x7cd94:0x7cd98], bytes.fromhex('c0035fd6'))
            old_info, new_info = inspect(original)[0], inspect(patched)[0]
            self.assertEqual(old_info['entitlements'], new_info['entitlements'])
            self.assertEqual(old_info['loads'], new_info['loads'])
            self.assertEqual(old_info['rpaths'], new_info['rpaths'])

    def test_refuses_unknown_or_already_patched_binary(self):
        original = next(iter(self.binaries.values()))
        patched, _ = patch_binary(original)
        with self.assertRaises(AssertionError):
            patch_binary(patched)
        with self.assertRaises(AssertionError):
            patch_binary(original[:-1])


if __name__ == '__main__':
    unittest.main(verbosity=2)
