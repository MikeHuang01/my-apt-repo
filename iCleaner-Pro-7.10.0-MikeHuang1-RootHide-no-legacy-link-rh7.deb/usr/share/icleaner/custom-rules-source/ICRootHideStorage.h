#pragma once
#ifdef ICR_HOST_TEST
#import <Foundation/Foundation.h>
#else
#import "FoundationMinimal.h"
#endif

/* Paths returned here are physical rootfs paths suitable for Foundation. */
NSString *ICRActiveJailbreakRoot(void);
NSString *ICRStateDirectory(void);
NSString *ICRRedirectOwnedDataPath(NSString *path);
void ICRInstallRootHideStorage(void);
/* Re-import generated rules after the file-backed preference store becomes
 * active. A pre-activation refresh must not make later imports no-ops. */
void ICRRulesPreferencesDidActivate(NSUserDefaults *defaults);
