#pragma once
/* Small declaration-only subset for cross-compiling against iOS Foundation.
 * Implementations are provided by iOS; no third-party runtime is bundled.
 */
typedef _Bool BOOL; /* iOS arm64 uses OBJC_BOOL_IS_BOOL. */
typedef unsigned long NSUInteger;
typedef long NSInteger;
typedef struct _NSZone NSZone;
typedef struct objc_class *Class;
typedef struct objc_selector *SEL;
typedef struct objc_method *Method;
typedef id (*IMP)(id, SEL, ...);
#define YES ((BOOL)1)
#define NO ((BOOL)0)
#define nil ((id)0)
#define NULL ((void *)0)

@protocol NSCopying
- (id)copyWithZone:(NSZone *)zone;
@end

@interface NSObject
+ (id)alloc;
+ (Class)class;
- (Class)class;
- (id)init;
- (BOOL)isKindOfClass:(Class)cls;
- (BOOL)respondsToSelector:(SEL)sel;
- (BOOL)isEqual:(id)object;
- (id)copy;
- (id)mutableCopy;
@end

@interface NSString : NSObject <NSCopying>
+ (id)stringWithFormat:(NSString *)format, ...;
+ (id)stringWithUTF8String:(const char *)string;
- (const char *)fileSystemRepresentation;
- (BOOL)isEqualToString:(NSString *)string;
- (BOOL)hasPrefix:(NSString *)string;
- (BOOL)hasSuffix:(NSString *)string;
- (NSUInteger)length;
- (BOOL)boolValue;
- (NSInteger)integerValue;
- (float)floatValue;
- (double)doubleValue;
- (NSString *)stringByAppendingPathComponent:(NSString *)string;
- (NSString *)stringByStandardizingPath;
- (NSString *)stringByResolvingSymlinksInPath;
- (NSString *)stringByDeletingLastPathComponent;
- (NSString *)lastPathComponent;
- (NSString *)substringFromIndex:(NSUInteger)i;
- (id)componentsSeparatedByString:(NSString *)string;
@end

@interface NSNumber : NSObject
+ (id)numberWithInteger:(NSInteger)value;
+ (id)numberWithFloat:(float)value;
+ (id)numberWithDouble:(double)value;
+ (id)numberWithUnsignedInteger:(NSUInteger)value;
+ (id)numberWithBool:(BOOL)value;
- (NSUInteger)unsignedIntegerValue;
- (BOOL)boolValue;
- (NSInteger)integerValue;
- (float)floatValue;
- (double)doubleValue;
@end

@interface NSData : NSObject
@end

@interface NSArray : NSObject
+ (id)array;
+ (id)arrayWithObjects:(const id [])objects count:(NSUInteger)count;
- (NSUInteger)count;
- (id)objectAtIndex:(NSUInteger)index;
- (BOOL)containsObject:(id)value;
- (BOOL)isEqualToArray:(NSArray *)array;
- (NSArray *)sortedArrayUsingSelector:(SEL)selector;
@end

@interface NSMutableArray : NSArray
+ (id)array;
- (void)addObject:(id)object;
@end

@interface NSDictionary : NSObject
+ (id)dictionaryWithContentsOfFile:(NSString *)path;
+ (id)dictionaryWithDictionary:(NSDictionary *)dictionary;
- (NSArray *)allKeys;
- (NSUInteger)count;
- (BOOL)isEqualToDictionary:(NSDictionary *)dictionary;
+ (id)dictionaryWithObjects:(const id [])objects forKeys:(const id [])keys count:(NSUInteger)count;
- (id)objectForKey:(id)key;
- (BOOL)writeToFile:(NSString *)path atomically:(BOOL)flag;
@end

@interface NSMutableDictionary : NSDictionary
+ (id)dictionary;
- (void)setObject:(id)object forKey:(id)key;
- (void)removeObjectForKey:(id)key;
- (void)addEntriesFromDictionary:(NSDictionary *)dictionary;
@end

@interface NSSet : NSObject
- (BOOL)containsObject:(id)value;
- (NSUInteger)count;
@end
@interface NSMutableSet : NSSet
+ (id)set;
- (void)addObject:(id)object;
@end

@class NSError;
@interface NSError : NSObject
- (NSString *)domain;
- (NSInteger)code;
@end
@interface NSException : NSObject
- (NSString *)reason;
@end
@interface NSDate : NSObject
+ (id)date;
@end

@interface NSFileManager : NSObject
+ (id)defaultManager;
- (BOOL)fileExistsAtPath:(NSString *)path isDirectory:(BOOL *)directory;
- (NSArray *)contentsOfDirectoryAtPath:(NSString *)path error:(NSError **)error;
- (NSDictionary *)attributesOfItemAtPath:(NSString *)path error:(NSError **)error;
- (BOOL)createDirectoryAtPath:(NSString *)path withIntermediateDirectories:(BOOL)flag attributes:(NSDictionary *)attributes error:(NSError **)error;
- (BOOL)copyItemAtPath:(NSString *)source toPath:(NSString *)destination error:(NSError **)error;
- (BOOL)contentsEqualAtPath:(NSString *)a andPath:(NSString *)b;
- (NSString *)destinationOfSymbolicLinkAtPath:(NSString *)path error:(NSError **)error;
- (BOOL)createSymbolicLinkAtPath:(NSString *)path withDestinationPath:(NSString *)destination error:(NSError **)error;
@end

@interface NSUserDefaults : NSObject
+ (id)standardUserDefaults;
- (id)objectForKey:(NSString *)key;
- (NSArray *)arrayForKey:(NSString *)key;
- (void)setObject:(id)object forKey:(NSString *)key;
- (BOOL)synchronize;
- (NSDictionary *)dictionaryRepresentation;
- (NSDictionary *)persistentDomainForName:(NSString *)domain;
- (NSDictionary *)volatileDomainForName:(NSString *)domain;
- (void)registerDefaults:(NSDictionary *)defaults;
@end

@interface NSNotificationCenter : NSObject
+ (id)defaultCenter;
- (void)postNotificationName:(NSString *)name object:(id)object;
- (void)addObserver:(id)observer selector:(SEL)selector name:(NSString *)name object:(id)object;
@end

@interface NSBundle : NSObject
+ (id)mainBundle;
- (NSString *)bundleIdentifier;
@end

extern NSString * const NSFileType;
extern NSString * const NSFileTypeDirectory;
extern NSString * const NSFileTypeRegular;
extern NSString * const NSFileTypeSymbolicLink;
extern NSString * const NSUserDefaultsDidChangeNotification;
extern NSString * const NSGlobalDomain;
extern NSString * const NSRegistrationDomain;
extern NSString * const NSArgumentDomain;
extern NSString * const NSCocoaErrorDomain;
extern NSString * const NSPOSIXErrorDomain;
extern Class NSClassFromString(NSString *name);
extern Class class_getSuperclass(Class cls);
extern Method class_getInstanceMethod(Class cls, SEL selector);
extern Method class_getClassMethod(Class cls, SEL selector);
extern IMP method_setImplementation(Method method, IMP imp);
extern IMP method_getImplementation(Method method);
extern const char *method_getTypeEncoding(Method method);
extern BOOL class_addMethod(Class cls, SEL selector, IMP imp, const char *types);
extern IMP class_replaceMethod(Class cls, SEL selector, IMP imp, const char *types);
extern unsigned int getuid(void);
typedef struct { long tv_sec; long tv_nsec; } ICRTimespec;
extern int clock_gettime(int clock, ICRTimespec *value);
