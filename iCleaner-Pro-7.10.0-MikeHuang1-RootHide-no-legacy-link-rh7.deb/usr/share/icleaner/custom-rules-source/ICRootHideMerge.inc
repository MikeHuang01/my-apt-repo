/* Included in storage.m so the host exercises the production implementation.
 * One live Data tree. Every source is independently snapshotted and compared
 * before missing-file import or retirement. Conflicts retain current Data and
 * the full source snapshot; no arbitrary newest-file heuristic is used.
 */
static NSString *MergeBackups;
static NSMutableArray *MergeRecords;
static NSUInteger MergeConflicts, MergeRemaining;
static BOOL MergeBusy;

static NSString *PhysicalLeaf(NSString *path) {
    return [Resolved([path stringByDeletingLastPathComponent]) stringByAppendingPathComponent:[path lastPathComponent]];
}
static NSString *MergeUnused(NSFileManager *fm, NSString *prefix) {
    return UnusedArchive(fm, MergeBackups, prefix);
}
static NSUInteger MergeCountRemaining(NSFileManager *fm, NSString *base) {
    NSArray *sources = @[PhysicalLeaf(JailbreakPath("/var/mobile/Library/iCleaner")),
        PhysicalLeaf(LegacyData), PhysicalLeaf(JailbreakPath("/var/mobile/Library/iCleanerRootHide"))];
    NSMutableSet *seen = [NSMutableSet set]; NSUInteger remaining = 0;
    for (NSUInteger i = 0; i < [sources count]; i++) {
        NSString *source = [sources objectAtIndex:i];
        if ([seen containsObject:source] || [source isEqualToString:base]) continue;
        [seen addObject:source]; NSError *error = nil;
        if ([fm attributesOfItemAtPath:source error:&error] || !Missing(error)) remaining++;
    }
    return remaining;
}
static BOOL MergeFiles(NSFileManager *fm, NSString *source, NSString *data) {
    NSError *initialError = nil;
    NSDictionary *existing = [fm attributesOfItemAtPath:data error:&initialError];
    if (!PlainTree(fm, source) || (existing ? !PlainTree(fm, data) : !Missing(initialError)))
        return Fail(@"merge-nonplain-tree-preserved");
    NSMutableArray *queue = [NSMutableArray array]; [queue addObject:@""];
    for (NSUInteger i = 0; i < [queue count]; i++) {
        NSString *suffix = [queue objectAtIndex:i];
        NSString *a = [suffix length] ? [source stringByAppendingPathComponent:suffix] : source;
        NSString *b = [suffix length] ? [data stringByAppendingPathComponent:suffix] : data;
        NSError *error = nil;
        NSDictionary *attributes = [fm attributesOfItemAtPath:b error:&error];
        if (!attributes) {
            if (!Missing(error)) return Fail(@"merge-destination-unreadable");
            /* Never expose a partial copy as a live file after interruption.
             * Failed staging remains archived; a retry gets a new slot. */
            NSString *stage = MergeUnused(fm, @"import.pending");
            if (!stage || ![fm copyItemAtPath:a toPath:stage error:NULL] || !EqualTree(fm, a, stage))
                return Fail(@"merge-import-copy-or-verification-failed");
            NSError *recheck = nil;
            if ([fm attributesOfItemAtPath:b error:&recheck] || !Missing(recheck) ||
                rename([stage fileSystemRepresentation], [b fileSystemRepresentation]))
                return Fail(@"merge-import-activation-failed-source-and-stage-preserved");
            continue;
        }
        if (Directory(fm, a) && Directory(fm, b)) {
            NSArray *children = [fm contentsOfDirectoryAtPath:a error:NULL];
            if (!children || [children count] + [queue count] > 20000) return Fail(@"merge-scan-limit");
            for (NSUInteger j = 0; j < [children count]; j++)
                [queue addObject:[suffix stringByAppendingPathComponent:[children objectAtIndex:j]]];
        } else if (!EqualTree(fm, a, b)) {
            /* The complete differing input exists in this source's verified
             * Backups/snapshot-N tree before we reach this branch. */
            MergeConflicts++;
        }
    }
    return YES;
}
static BOOL MergeOne(NSFileManager *fm, NSString *source, NSString *ownedData, NSString *base) {
    NSError *error = nil;
    if (![fm attributesOfItemAtPath:source error:&error])
        return Missing(error) || Fail(@"merge-source-unreadable");
    NSString *data = [base stringByAppendingPathComponent:@"Data"];
    if (!Directory(fm, source) || !PlainTree(fm, source) || Inside(base, source) || Inside(source, base))
        return Fail(@"merge-source-link-special-or-overlap-preserved");
    NSString *snapshot = MergeUnused(fm, @"snapshot");
    if (!snapshot || ![fm copyItemAtPath:source toPath:snapshot error:NULL] || !EqualTree(fm, source, snapshot))
        return Fail(@"merge-full-source-backup-failed");
    NSError *dataError = nil;
    NSDictionary *owned = [fm attributesOfItemAtPath:ownedData error:&dataError];
    if (owned) {
        if (!Directory(fm, ownedData) || !MergeFiles(fm, ownedData, data)) return NO;
    } else if (!Missing(dataError)) return Fail(@"merge-owned-data-unreadable");
    /* Older state layouts can contain actual preferences as well as Data.
     * Import ONLY this application's plist; keep active primary preferences
     * on conflicts, with the complete other state in the snapshot. */
    if (![source isEqualToString:ownedData]) {
        NSString *leaf = @"com.ivanobilenchi.icleaner.plist";
        NSString *oldPref = [[source stringByAppendingPathComponent:@"Preferences"] stringByAppendingPathComponent:leaf];
        NSError *prefError = nil;
        if ([fm attributesOfItemAtPath:oldPref error:&prefError]) {
            if (![NSDictionary dictionaryWithContentsOfFile:oldPref]) return Fail(@"merge-old-preferences-unreadable-preserved");
            NSString *directory = [base stringByAppendingPathComponent:@"Preferences"];
            NSError *directoryError = nil;
            if (![fm attributesOfItemAtPath:directory error:&directoryError] &&
                (!Missing(directoryError) || ![fm createDirectoryAtPath:directory withIntermediateDirectories:NO attributes:nil error:NULL]))
                return Fail(@"merge-preference-directory-unavailable");
            if (!Directory(fm, directory) || ![Resolved(directory) isEqualToString:directory])
                return Fail(@"merge-preference-directory-is-alias");
            if (!MergeFiles(fm, oldPref, [directory stringByAppendingPathComponent:leaf])) return NO;
        } else if (!Missing(prefError)) return Fail(@"merge-old-preferences-unreadable-preserved");
    }
    if (!ProbeData(data) || !EqualTree(fm, source, snapshot)) return Fail(@"merge-source-changed-before-retirement");
    [MergeRecords addObject:@{@"source":source, @"snapshot":snapshot}];
    return YES;
}
static BOOL ConsolidateStorage(NSFileManager *fm, NSString *base) {
    MergeRecords = [NSMutableArray array]; MergeConflicts = 0; MergeRemaining = 0;
    MergeBackups = [base stringByAppendingPathComponent:@"Backups"];
    NSString *data = [base stringByAppendingPathComponent:@"Data"];
    NSArray *directories = @[MergeBackups, data];
    for (NSUInteger i = 0; i < [directories count]; i++) {
        NSString *path = [directories objectAtIndex:i];
        NSError *error = nil;
        if (![fm attributesOfItemAtPath:path error:&error] &&
            (!Missing(error) || ![fm createDirectoryAtPath:path withIntermediateDirectories:NO attributes:nil error:NULL]))
            return Fail(@"merge-create-directory-failed");
        if (!Directory(fm, path) || ![Resolved(path) isEqualToString:path]) return Fail(@"merge-directory-is-alias");
    }
    if (!PlainTree(fm, data)) return Fail(@"merge-existing-data-nonplain-preserved");
    NSString *hiddenData = PhysicalLeaf(JailbreakPath("/var/mobile/Library/iCleaner"));
    NSString *hiddenState = PhysicalLeaf(JailbreakPath("/var/mobile/Library/iCleanerRootHide"));
    /* Priority: existing primary Data > hidden iCleaner > real legacy iCleaner
     * > old hidden iCleanerRootHide/Data. All differing values are archived. */
    NSArray *sources = @[hiddenData, PhysicalLeaf(LegacyData), hiddenState];
    NSMutableSet *seen = [NSMutableSet set]; BOOL ok = YES;
    for (NSUInteger i = 0; i < [sources count]; i++) {
        NSString *source = [sources objectAtIndex:i];
        if ([seen containsObject:source] || [source isEqualToString:base]) continue;
        [seen addObject:source];
        NSString *owned = [source isEqualToString:hiddenState] ? [source stringByAppendingPathComponent:@"Data"] : source;
        if (!MergeOne(fm, source, owned, base)) { ok = NO; MergeRemaining++; }
    }
    if (!ok || !ProbeData(data)) return NO;
    /* Validate ALL sources before the first retirement. An unmergeable source
     * therefore cannot cause a previous working source to disappear. */
    for (NSUInteger i = 0; i < [MergeRecords count]; i++) {
        NSDictionary *record = [MergeRecords objectAtIndex:i];
        if (!EqualTree(fm, [record objectForKey:@"source"], [record objectForKey:@"snapshot"]))
            return Fail(@"merge-input-changed-all-originals-preserved");
    }
    NSMutableArray *completed = [NSMutableArray array];
    for (NSUInteger i = 0; i < [MergeRecords count]; i++) {
        NSDictionary *record = [MergeRecords objectAtIndex:i];
        NSString *retired = MergeUnused(fm, @"retired");
        BOOL moved = [retired length] && !rename([[record objectForKey:@"source"] fileSystemRepresentation], [retired fileSystemRepresentation]);
        NSMutableDictionary *result = [record mutableCopy];
        [result setObject:moved ? retired : @"" forKey:@"retired"];
        [result setObject:[NSNumber numberWithBool:moved] forKey:@"success"];
        [completed addObject:result];
        if (!moved) {
            MergeRemaining++; Fail(@"merge-retirement-failed-source-preserved-primary-data-active");
        }
    }
    MergeRecords = completed;
    /* Every input is represented in verified Data or an immutable snapshot.
     * A retirement-only failure must not switch the app back to a moved path. */
    return YES;
}
