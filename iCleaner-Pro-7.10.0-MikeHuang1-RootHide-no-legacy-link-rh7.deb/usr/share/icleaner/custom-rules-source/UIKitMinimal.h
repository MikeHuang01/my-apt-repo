#pragma once
#import "FoundationMinimal.h"

/* Declaration-only UIKit subset. All implementations come from iOS. */
@interface UIView : NSObject
- (void)setUserInteractionEnabled:(BOOL)enabled;
- (NSArray *)gestureRecognizers;
- (void)addGestureRecognizer:(id)recognizer;
- (void)setAccessibilityHint:(NSString *)hint;
@end

@interface UILabel : UIView
- (NSString *)text;
- (void)setText:(NSString *)text;
@end

@interface UIGestureRecognizer : NSObject
- (id)initWithTarget:(id)target action:(SEL)action;
- (void)addTarget:(id)target action:(SEL)action;
- (NSInteger)state;
- (void)setCancelsTouchesInView:(BOOL)cancel;
@end

@interface UILongPressGestureRecognizer : UIGestureRecognizer
- (void)setMinimumPressDuration:(double)duration;
@end

@interface UIPasteboard : NSObject
+ (id)generalPasteboard;
- (void)setString:(NSString *)string;
@end

@interface UINotificationFeedbackGenerator : NSObject
- (void)notificationOccurred:(NSInteger)type;
@end

extern const unsigned int UIAccessibilityAnnouncementNotification;
extern void UIAccessibilityPostNotification(unsigned int notification, id argument);
