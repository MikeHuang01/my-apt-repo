iCleaner Pro — RootHide 主隐根统一存储 rh7（修复自定义规则消失）
版本：7.10.0+customrules.4.rh7；包标识：com.sini.icleanerpro
仅用于 Dopamine RootHide，依赖 rootless-compat >= 0.9，最低 iOS 15。
请在现有 RootHide 环境直接升级，不要再次 RootHidePatcher 转换。
rh3、rh4、rh5、rh6 安装包、源码和交付目录不覆盖，仍可保留作回退参考。
rh7 在 rh6 基础上修复两处：已确认失效的 mobile 偏好链接归档后不再阻止空偏好
存储启用；偏好启用后会强制重新导入自定义规则，避免迁移前的读取把一次性导入
状态置为完成，导致“自定义文件夹”里的固定规则和动态发现规则为空。

【样本说明】
上传的 iCleanerRootHide.zip 含旧数据与备份，状态为 rh1、success=false，
记录旧 var/mobile/Library 路径；没有偏好状态或实际偏好文件。
它不能证明 rh4 是否加载，也不能证明旧偏好项由谁重建。
本地回放使用这份真实旧状态；第二个 iCleaner 目录只用其 Data 的受控子集
构造，并非从手机读取的真实第二目录。回放通过不等于真机迁移已完成。
此前偏好 ZIP 仅含指向 /rootfs/var/root/Library/Preferences/
com.ivanobilenchi.icleaner.plist 的69字节链接，没有实际设置键值。
不需要重复上传同一个链接；实际设置由设备运行时读取。

【新位置，随机主隐根不写死】
主隐根通过官方 jbroot("/") 动态取得，通常是：
/var/containers/Bundle/Application/.jbroot-随机值/
也可能显示等价的 /private/var 前缀。
全部新文件位于主隐根的 Library/iCleanerRootHide/，不经由其 var 次隐根链接：
Data/                       唯一活动数据目录：日志、主题、现有许可证缓存
Preferences/com.ivanobilenchi.icleaner.plist  新偏好文件
Backups/                     所有合并输入的完整快照及退休原目录
Preferences-legacy/          原 plist、链接与首次运行快照的备份/退休副本
preferences-migration-status.plist           本次偏好迁移状态
storage-migration-status.plist               本次合并状态（标记 rh7）

【两个旧目录如何合一】
1. 旧 jbroot/var/mobile/Library/iCleaner、同级 iCleanerRootHide，以及真实
   系统 /var/mobile/Library/iCleaner，仅作为输入；新活动存储不经由 var。
2. 每个存在的来源先完整复制到 Backups/snapshot[-N] 并逐项校验。
   仅导入缺失文件；先在 Backups/import.pending[-N] 暂存、验证后原子激活。
   中断留下的暂存不当作活动文件，也不覆盖或清理既有备份。
3. 同名不同内容按固定优先级保留活动值，不根据时间戳猜测最新：
   已有主隐根 Data > 隐藏 iCleaner > 系统旧 iCleaner > 旧隐藏状态 Data。
   另一份完整内容留在来源快照；文件/目录类型冲突也不强行覆盖。
4. 旧状态中如有 Preferences/com.ivanobilenchi.icleaner.plist，独有配置
   导入新 Preferences；已有主隐根配置优先，旧冲突配置仍完整归档。
   其他旧备份、状态文件保留在快照/退休目录，不冒充当前状态。
5. 所有来源校验通过、Data 可写后，才逐个原子移动至 Backups/retired[-N]。
   旧路径不留链接。若复制、读取、链接/特殊文件检查失败，保留原目录，
   本进程不启用新 Data；重开后可重试，不要求手动删目录。
6. 如仅退休移动失败，保留该原目录但继续使用已经验证的新 Data，避免
   回退到已移动的其他旧路径。此时 success=false、legacyDirectoriesRemaining>0，
   不能声称已完成合一。跨卷等导致 rename 失败也按此处理，不复制后删源。
7. 在 iCleaner 进程内，已确认的旧路径目录创建和字符串读写转发到统一目录；
   不改许可证逻辑或缓存内容。其他进程、未知直接 POSIX 写入不在全局控制内。

【偏好处理方式】
1. rh6 起针对已确认的旧方法直接处理：主程序 `-[ICAppDelegate symlinkPreferenceFile]`
   被改成立即返回，不再执行创建链接的代码；同时在 NSFileManager 符号链接接口
   对该 mobile 同名 plist 做精确路径拦截。两处都不依赖偏好迁移是否成功。
   主程序只改该方法入口的4字节 ARM64 `RET` 指令，并重算对应代码签名页哈希；
   其他指令、偏好方法、程序段、加载项及 entitlements 不变。活动程序和包内
   AutoPatches 镜像均打补丁。未知哈希/偏移会拒绝构建。
2. 安装早期先装路径拦截和旧方法禁用；随后才延迟到原程序完成
   NSUserDefaults 方法交换、注册默认值后迁移，
   不提前调用尚未交换的 IC_synchronize，避免递归或破坏原生初始化。
   应用启动完成通知仍作独立初始化重试。
3. 首次读取并同步 iCleaner 自己的持久化偏好域，以及 root/mobile 下的
   同名普通 plist；兼容普通文件、实际链接及目标不存在但运行时域仍可读。
   不把全局/Apple/注册默认值混入持久化配置。
4. 保存主隐根快照和配置，逐项比较回读，验证成功后才接管偏好读写，
   再备份、原子退休内容一致且未被保留链接引用的旧同名普通文件。
   有效或未知目标链接及其已识别的目标保留，不为了清空旧路径而破坏它们。
5. 保留原 standardUserDefaults 对象和原生类别方法；常用类型读取、设置、
   删除、注册默认值、持久化域替换均只针对该对象及 iCleaner 自有域转发。
   保留 ICUserDefaultsWillSynchronizeNotification，原生对象仍可保存设置；
   发出 NSUserDefaultsDidChangeNotification。其他实例、域和进程不重定位。
6. 每次设置立即原子保存、回读验证；加锁合并已提交配置。写入失败保留
   待保存改动并让 synchronize 返回失败，可在权限/文件恢复后重试。
   后续启动以主隐根现有配置为准，不再同步已停用的旧偏好域。
7. 偏好迁移成功后持久化设置写入主隐根；同步不调用旧 CFPreferences 写入接口，
   避免本进程再次创建旧 plist。迁移失败时保留原偏好机制，但旧链接创建仍被禁用。
8. 对 mobile 旧路径发现指向已知 root 偏好 plist 的失效链接时，先把链接本身
   备份到 Preferences-legacy，再核对目标仍失效后 unlink。不会读取、复制或删除
   链接目标内容；如果目标存在、检查结果不确定或备份失败，则保留原链接并记错。
   其他有效或未知目标链接在偏好迁移退休阶段也不会被移走。即使偏好迁移失败，
   仍会拦截 iCleaner 自身的链接创建。
9. 如果旧项仅为已确认失效并成功归档的 mobile 链接，且运行时没有可读持久化设置，
   则创建空的活动偏好文件并启用新存储。这不是把旧设置伪造成成功迁移；固定规则和
   动态发现规则会在偏好激活后重新生成。若链接归档失败、仍有未处理链接、存在
   不可读文件或配置冲突，则继续保留原项并失败。
10. 偏好激活后会强制重置规则导入的一次性完成标记，并重新读取/生成规则，确保
    5 条固定规则和动态发现规则写入新的 `Preferences/`，而不是迁移前访问的旧域。
    即使更早的设置 getter 已触发过一次规则刷新，也不会阻止新存储导入。
11. 读取失败、两份真实配置冲突、目录/目的文件被链接替换等情况均保留
   原项。后续启动已有主隐根配置时不让旧的不同配置覆盖它，旧冲突文件
   会保留并在 legacyItemsRemaining 计数；不要手动覆盖或删除。

【范围与保留行为】
日志、主题和原许可证缓存继续迁入主隐根 Data；仅转发 iCleaner 自有旧目录
的创建与字符串读写；失败回退旧位置。保留复制/比较/备份/原子退休策略。
不修改许可证逻辑或缓存内容。唯一原主程序差异是上述 `symlinkPreferenceFile`
立即返回补丁；包内既有附加组件二进制字节不变。
不移动整个 Library，不动其他应用的 plist，不改变清理目标或测试恢复备份。
手机日志、许可证缓存和实际私人设置不装入通用 deb 或源码 ZIP。

【安装与设备验收：尚未替你在手机上执行】
1. 先备份重要数据，完全退出 iCleaner，用当前 RootHide 包管理器直接安装 rh7。
   安装仅准备主目录；首次启动才运行合并，不要先手动删除两个旧目录。
   从 rh6 升级时也不要删除主隐根 Preferences/ 或 Preferences-legacy/；rh7 会复用
   已有设置，并在自定义规则缺失时补入固定规则和本次扫描到的规则。
2. 打开 iCleaner。主隐根 Library/iCleanerRootHide/storage-migration-status.plist
   应为 version=2026.11.18.rh7、primaryDataActive=true、success=true、
   legacyDirectoriesRemaining=0、failureReason 为空。两个旧隐藏目录应不再存在。
   mergeConflictsArchived>0 表示有冲突被保留在 Backups，不表示内容丢弃。
3. 偏好状态单独查看 preferences-migration-status.plist，应为 rh7、
   `legacyLinkCreationBlocked=true`。迁移成功时还应 `active=true`、
   `lastSaveVerified=true`。旧项全部处理后 `failureReason` 为空、`legacyItemsRemaining=0`；
   若有有效/未知链接保留，计数非零并显示保留原因，不表示配置写入失败。
   清理旧失效链接后 `danglingMobileLinksArchived` 会增加；原链接留在
   `Preferences-legacy/` 供核对。若失败，状态会给出失败原因。
4. 打开“自定义文件夹”核对：应能看到 `/var/db/uuidtext`、diagnostics 的
   Persist/Signpost/Special 及 `/var/mobile/Library/Caches` 五条固定规则；此前
   动态发现过的缓存/Inbox 规则会重新扫描后加入。若列表仍为空，先不要反复改设置，
   提供新主隐根的 preferences-migration-status.plist、custom-rules-status.plist
   和 storage-migration-status.plist 供核对。
5. 检查原设置是否保留，修改一个容易恢复的界面/清理选项，正常退出重开，
   确认修改保留；首次只分析，不直接执行陌生清理规则。
6. 多次启动后核对两个旧数据目录及系统 mobile 同名偏好项是否重现。
7. 若旧项仍在或出现新目录：不要删，提供当前主隐根的两份状态文件和安装
   版本。状态无设置键值，但含设备路径，分享前可打码。无状态时再核对实际
   加载组件/安装指纹及闪退 .ips（若有）；不需要再次发送相同偏好链接 ZIP。

【验证边界】
完成规则、页脚、数据存储及偏好设置主机测试，含真实 Objective-C 方法钩子、
链接/普通文件、双目录合并、次隐根输入、冲突归档、导入中断、失败重试、
通知、初始化顺序和独立进程重启读取；新增“仅失效链接归档后启用空偏好存储”
及“偏好激活后强制重新导入规则”的回归测试。并静态确认唯一主程序入口补丁、重算
代码签名页哈希，检查活动二进制与包内镜像的加载项和 entitlements 未变。
另有上传旧状态的私有本地回放。
完成 iOS 交叉编译、Clang 静态分析、Mach-O 签名、隔离 dpkg 解包及源码恢复。
尚未连接 iPhone，不能保证 iOS Foundation/RootHide 实现与主机模拟完全一致。
系统偏好守护进程、其他进程的既有缓存或写入不受此进程内修复全局控制。
不承诺所有越狱痕迹消失，亦不承诺零 bug。此次未操作用户手机。

【回退】
退出软件，先备份整个主隐根 Library/iCleanerRootHide，再安装已知可用旧包。
旧包不认识新偏好位置；应从主隐根 Preferences 导出最新配置，并与
Preferences-legacy 的原始备份核对，确认无冲突后再恢复旧环境需要的配置。
旧数据输入及其冲突版本可按 storage 状态的 mergeRecords 在 Backups 中核对。
不要直接用旧备份覆盖新配置，以免丢失 rh6/rh7 期间修改；降级本身不会自动还原
已迁移数据，也不应先清空新目录。
