#!/usr/bin/env python3
"""Build and validate the 1.1.37 private-count diagnostic upgrade."""
import argparse
import hashlib
from pathlib import Path

import build_diagnostic_deb as package
import validate_relinked_deb as validator

BASELINE_SHA256 = 'd2e5d5774e5cdb45aaa370a2199a3919a47d9d2105bcf05d221c2c6d8f0cf0f6'
OLD_VERSION = '1.1.36'
NEW_VERSION = '1.1.37'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('baseline', type=Path)
    parser.add_argument('dylib', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    baseline = args.baseline.read_bytes()
    result = package.build(baseline, args.dylib.read_bytes(), baseline_sha=BASELINE_SHA256,
                           old_version=OLD_VERSION, new_version=NEW_VERSION,
                           embedded_version=NEW_VERSION)
    validator.validate(result, baseline, NEW_VERSION)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('xb') as stream:
        stream.write(result)
    print(f'{args.output}: {len(result)} bytes SHA256 {hashlib.sha256(result).hexdigest()}')


if __name__ == '__main__':
    try:
        main()
    except (AssertionError, ValueError, OSError, KeyError) as error:
        raise SystemExit(f'build failed: {error}')
