#!/usr/bin/env python3
"""Classify a recent QXAS diagnostic enable operation in a local log export."""
import argparse
import re
from pathlib import Path

SWITCH = re.compile(r'QXAS diagnostic package loaded (\d+\.\d+\.\d+); QXAS main switch changed: (on|off)\b')
ENGINE = re.compile(r'QXAS engine applyScriptMode returned=([01])\b')
ENTER = 'QXAS task wrapper enter '
EXIT = re.compile(r'QXAS task wrapper exit status=(-?\d+)\b')
READY = 'QXAS script preparation succeeded; entering task core'
PREP_ERROR = 'QXAS script preparation failed at '
MIRROR = 'QXAS mirror conflict: preserved existing Documents/Scripts/qxas-controller.js; using validated engine source'
CANDIDATE_ZERO = '已启用智能切节点：候选 0 个'
PATH_COUNT = re.compile(r'QXAS engine candidatePaths result class=(\S+) count=(-?\d+)')
TAG_COUNT = re.compile(r'QXAS engine collectNodeTags result class=(\S+) count=(-?\d+)')
CORE_ERROR = re.compile(r'QXAS task config transformation failed \(status (-?\d+)\)')
WRITE_ERRORS = ('QXAS engine backupData failed ', 'QXAS engine writeConfData failed ')


def classify(text, version='1.1.36'):
    """Return (classification, relevant line numbers). Report no private log content."""
    events = []
    for number, line in enumerate(text.splitlines(), 1):
        switch = SWITCH.search(line)
        if switch:
            events = [('switch', switch.groups(), number)]
            continue
        if not events:
            continue
        if match := PATH_COUNT.search(line):
            events.append(('candidate_paths', int(match[2]), number))
            continue
        if match := TAG_COUNT.search(line):
            events.append(('candidate_tags', int(match[2]), number))
            continue
        for name, marker in (('enter', ENTER), ('ready', READY), ('prep_error', PREP_ERROR), ('mirror', MIRROR),
                             ('backup_error', WRITE_ERRORS[0]), ('write_error', WRITE_ERRORS[1]),
                             ('no_candidates', CANDIDATE_ZERO)):
            if marker in line:
                events.append((name, None, number))
                break
        else:
            for name, pattern in (('exit', EXIT), ('core_error', CORE_ERROR), ('engine', ENGINE)):
                if match := pattern.search(line):
                    events.append((name, int(match[1]), number))
                    break

    if not events:
        return 'no_switch_marker', []
    relevant = [number for _, _, number in events]
    actual_version, direction = events[0][1]
    if version != actual_version:
        return 'wrong_version', relevant
    if direction != 'on':
        return 'last_switch_is_off', relevant

    names = [name for name, _, _ in events[1:]]
    if len(set(names)) != len(names):
        return 'ambiguous', relevant
    data = {name: value for name, value, _ in events[1:]}
    if 'mirror' in data:
        if actual_version not in ('1.1.36', '1.1.37') or 'enter' not in names or 'prep_error' in data:
            return 'ambiguous', relevant
        if 'ready' not in names:
            return 'insufficient', relevant
        if names.index('mirror') < names.index('enter') or names.index('mirror') > names.index('ready'):
            return 'ambiguous', relevant
        names.remove('mirror')  # Informational; the subsequent Engine result decides.
    if 'engine' in data and names[-1] != 'engine':
        return 'ambiguous', relevant
    if 'candidate_paths' in data or 'candidate_tags' in data:
        if actual_version != '1.1.37' or 'engine' not in data or data['engine'] != 1:
            return 'ambiguous', relevant
        paths = data.get('candidate_paths')
        tags = data.get('candidate_tags')
        if paths is None or tags is None or paths < 0 or tags < 0:
            return 'insufficient_candidate_counts', relevant
        if paths == 0 and tags == 0:
            return 'candidate_path_list_empty', relevant
        if paths > 0 and tags == 0:
            return 'candidate_tag_extraction_empty', relevant
        if tags > 0 and 'no_candidates' in data:
            return 'contradictory_candidate_counts', relevant
        if tags > 0:
            return 'candidates_collected_task_unverified', relevant
        return 'insufficient_candidate_counts', relevant
    if 'no_candidates' in data:
        if actual_version != '1.1.36' or 'engine' not in data or data['engine'] != 1:
            return 'ambiguous', relevant
        if names.index('no_candidates') < names.index('enter'):
            return 'ambiguous', relevant
        return 'engine_returned_success_no_candidates_task_unverified', relevant
    # Valid prefixes are useful when the export ends before the Engine result.
    if names == ['engine'] and data['engine'] == 0:
        return 'engine_failed_before_wrapper_or_log_missing', relevant
    if not names or names[0] != 'enter':
        return 'insufficient', relevant
    if names[1:] in (['prep_error'], ['prep_error', 'exit'], ['prep_error', 'exit', 'engine']):
        return ('prepare_failed' if data.get('exit', -1) == -1 and data.get('engine', 0) == 0
                else 'ambiguous'), relevant
    if names[1:] in (['ready', 'core_error'], ['ready', 'core_error', 'exit'],
                     ['ready', 'core_error', 'exit', 'engine']):
        status = data['core_error']
        return ('core_failed' if status < 0 and data.get('exit', status) == status and
                data.get('engine', 0) == 0 else 'ambiguous'), relevant
    if names[1:] == ['exit', 'engine'] and data['exit'] == -1 and data['engine'] == 0:
        return 'wrapper_guard_failed_or_log_missing', relevant
    if names[:3] == ['enter', 'ready', 'exit'] and data['exit'] == 0:
        tail = names[3:]
        if tail == ['engine']:
            return ('engine_returned_success_task_unverified' if data['engine'] == 1
                    else 'engine_failed_after_core'), relevant
        if tail in (['backup_error'], ['backup_error', 'engine'], ['write_error'], ['write_error', 'engine']):
            return (tail[0] if data.get('engine', 0) == 0 else 'ambiguous'), relevant
    return 'insufficient', relevant


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('log', type=Path, help='UTF-8 text export of the in-app log')
    parser.add_argument('--version', choices=('1.1.35', '1.1.36', '1.1.37'), default='1.1.37')
    args = parser.parse_args()
    try:
        verdict, lines = classify(args.log.read_text(encoding='utf-8-sig'), args.version)
    except (OSError, UnicodeError) as error:
        parser.exit(2, f'cannot read UTF-8 log: {error}\n')
    print(verdict)
    if lines:
        print('Relevant lines:', ', '.join(map(str, lines)))


if __name__ == '__main__':
    main()
