#!/usr/bin/env python3
"""Build the 1.1.38 no-space controller task-path fix."""
import argparse
import hashlib
from pathlib import Path
import build_diagnostic_deb as package
import validate_relinked_deb as validator

BASELINE_SHA256 = 'dad456ee7d95f77c30c0b7738d05cc5dbc9c656cc2504055c93f91bf3ddc52f3'
OLD_VERSION = '1.1.37'
NEW_VERSION = '1.1.38'

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('baseline', type=Path)
    parser.add_argument('dylib', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    baseline = args.baseline.read_bytes()
    result = package.build(baseline, args.dylib.read_bytes(), baseline_sha=BASELINE_SHA256,
                           old_version=OLD_VERSION, new_version=NEW_VERSION,
                           embedded_version=NEW_VERSION)
    validator.validate(result, baseline, NEW_VERSION)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('xb') as stream:
        stream.write(result)
    print(f'{args.output}: {len(result)} bytes SHA256 {hashlib.sha256(result).hexdigest()}')

if __name__ == '__main__':
    try:
        main()
    except (AssertionError, ValueError, OSError, KeyError) as error:
        raise SystemExit(f'build failed: {error}')
