# QXAS 1.1.36 交接：保留冲突镜像

## 真机证据和修正

1.1.35 的 11-27 14:25:55–14:25:58 日志确认完整路径校验通过，但既有镜像导致 `inspect existing destination`（errno 17 / EEXIST）；wrapper 在准备阶段返回 -1，核心未执行，Engine 返回 0。只能证明镜像内容与源不同且 ownership stamp 不匹配，不能判断是谁创建或修改。

1.1.36 的 11-27 17:20:49–17:20:51 日志确认新版本加载。wrapper 保留镜像后完成准备和核心调用：status=0、changed=1、output_length=10493；Engine 返回 1，配置长度从 10290 增到 10493。这证明此前的主开关脚本转换失败已越过且配置有增长，但不能仅由此确认任务可解析或运行。同一轮启用流程报告候选 0 个，当前没有日志证明定时任务已触发；较早节点收集也是 0 个。该段同时显示订阅拉取成功 1 个，但没有可确认最终标签列表的摘要，因此候选为何为空仍未知。

1.1.36 只将镜像冲突改为非致命结果：保留已有的 `Documents/Scripts/qxas-controller.js`，将引擎新生成且校验过的源文件路径交给核心。其他源校验和 I/O 错误仍会中止；核心格式、配置备份、写入与还原不变。

## 产物与验证

- [DEB](output/QXAS_1.1.36_mirrorconflict_iphoneos-arm64e.deb)：188318 字节，SHA-256 `d2e5d5774e5cdb45aaa370a2199a3919a47d9d2105bcf05d221c2c6d8f0cf0f6`。
- [ZIP](output/QXAS_1.1.36_mirrorconflict_test.zip)：187767 字节，SHA-256 `91278ab23a5b7da97ed5bb1fc0df2a75cf8dcddc092b6f139daee0fca4f7aab8`，内含相同 DEB。
- C 路径与并发回归、Python 集成检查、恢复版控制器 JS 七个模拟场景、双架构构建与每切片 62 个签名页检查通过；arm64e 旧对象 ABI 编译警告仍在。后续真机日志已确认 1.1.36 写入配置成功，候选为 0；任务运行和关闭还原仍待验证。

## 进度和验收

截至 11-27 17:20:51，主开关配置改写路径按里程碑计 4/5（约 80%）：真机确认 1.1.35 的 EEXIST、确认 1.1.36 越过冲突、核心 status=0 且 changed=1、Engine 返回 1、配置长度增加。剩余的一项端到端功能验收仍很关键：查明候选为 0 的原因，确认任务实际运行，以及开关关闭后配置能还原。本范围不含菜单页脚排版。

1. 覆盖安装 1.1.36 并完全退出重开 Quantumult X。保留现有脚本，不手动删除或改名；从关闭状态只打开一次主开关，不点“立即应用”。
2. 回传从 `QXAS diagnostic package loaded 1.1.36` 到 `QXAS engine applyScriptMode returned=…` 的同次日志，没有结束行就发到末尾。若镜像仍冲突，应先出现 `QXAS mirror conflict: preserved existing`，再出现 `QXAS script preparation succeeded; entering task core`。
3. 本次启用流程显示候选为 0，且没有任务触发日志。请检查 QXAS 节点/候选筛选设置与最终标签列表是否为空或规则未命中；只提供应用内候选筛选摘要，不要发配置正文。确认候选非空后，再确认周期任务实际触发，最后独立测试关闭和配置还原。不要为绕过镜像冲突删改既有脚本。

[离线判读工具](triage_switch_log.py) 默认检查 1.1.36，旧版可传 `--version 1.1.35`。23 个合成场景均通过；已分析用户 1.1.36 日志为 `engine_returned_success_no_candidates_task_unverified`。候选为 0 和 Engine 成功分开记录，均不宣称任务实际执行。

没有新故障时，完整设备验收预计 10–20 分钟，自开始安装计。若核心、配置写入或任务解析仍报错，按新日志重新估时。
