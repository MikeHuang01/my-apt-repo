#!/bin/bash
set -euo pipefail
# Cross-link the retained baseline objects; no source recovery is performed.
root=$(cd "$(dirname "$0")" && pwd)
obj=/mnt/e/QXAS-recovery-2026-11-25/qxas-build/obj
bin=/home/codexbuild/theos/toolchain/linux/iphone/bin
sdk=/home/codexbuild/theos/sdks/iPhoneOS16.5.sdk
printf "%s  %s
" d206b1da1d78455c9200d9f700f6bb0a47f6b1da7aec1947e2207d0b98cd6d20 "$obj/QXASUI.o" | sha256sum --status -c -
work=$(mktemp -d /tmp/qxas-native.XXXXXX)
# Preserve successful output for the packager; clean only this run's failed output.
trap 'status=$?; if (( status != 0 )) && [[ "$work" == /tmp/qxas-native.?????? && -d "$work" && ! -L "$work" ]]; then rm -rf -- "$work" || :; fi' EXIT
python3 - "$obj/QXASEngine.o" "$work/QXASEngine.o" <<'PY'
from pathlib import Path
import sys
image = Path(sys.argv[1]).read_bytes()
replacements = {
    b'_qxas_apply_task\0': b'_qxas_local_task\0',
    # Redirect only QXASEngine's undefined call; the retained core qxas_apply
    # remains the implementation reached by the transparent trace wrapper.
    b'_qxas_apply\0': b'_qxas_trace\0',
}
for old, new in replacements.items():
    assert len(old) == len(new) and image.count(old) == 1, (old, image.count(old))
    image = image.replace(old, new)
# Keep the template length and CFString metadata intact. Only the retired-mode
# suggestion changes; pad outside the JS string so no whitespace is displayed.
old = "'QX 未提供脚本控制接口，请改用自动测速组模式'"
new = "'QX 未提供脚本控制接口，请检查 QX 版本'"
assert len(new) < len(old)
old, new = (s.encode('utf-16le') for s in (old, new.ljust(len(old))))
assert len(old) == len(new) and image.count(old) == 1
image = image.replace(old, new)
Path(sys.argv[2]).write_bytes(image)
PY
python3 "$root/generate_failover_header.py" "$obj/QXASEngine.o" "$root/src/qxas-failover-body.js" "$work/qxas_failover_generated.h"
python3 "$root/patch_menu_font.py" "$obj/QXASMain.o" "$work/QXASMain.o"
compile() {
    local source=$1 output=$2
    shift 2
    /usr/bin/clang -target "$arch-apple-ios15.0" -isysroot "$sdk" "$@" \
        -Wall -Wextra -Werror -c "$root/src/$source" -o "$work/$output.$arch.o"
}

for arch in arm64 arm64e; do
    compile qxas_failover.c failover -I"$work" -std=c11
    compile qxas_local_task.m wrapper -fobjc-arc -fblocks
    compile qxas_task_path.c path -std=c11
    compile qxas_task_check.c task-check -std=c11
    compile qxas_compact_ui.m compact-ui -fobjc-arc -fblocks
    compile qxas_log_window.c qxas_log_window -std=c11
    compile qxas_log_retention.m qxas_log_retention -fobjc-arc -fblocks
    compile qxas_switch_hook.m switch -fobjc-arc -fblocks
    compile qxas_engine_diagnostics.m engine-diagnostics -fobjc-arc -fblocks
    compile qxas_apply_diagnostics.m apply-diagnostics -fobjc-arc -fblocks

    extra=()
    # The retained objects use the legacy arm64 ABI; new arm64e code uses PAC.
    if [ "$arch" = arm64e ]; then extra=(-allow_sub_type_mismatches); fi
    "$bin/ld" -dylib -arch "$arch" "${extra[@]}" -platform_version ios 15.0 16.4 -syslibroot "$sdk" \
        -install_name '@loader_path/.jbroot/Library/MobileSubstrate/DynamicLibraries/QXAS.dylib' \
        "$obj/qxas_core.o" "$obj/qxas_sub.o" "$obj/QXASStore.o" "$work/QXASEngine.o" "$work/QXASMain.o" "$obj/QXASUI.o" \
        "$work/wrapper.$arch.o" "$work/path.$arch.o" "$work/task-check.$arch.o" "$work/failover.$arch.o" \
        "$work/compact-ui.$arch.o" "$work/qxas_log_window.$arch.o" "$work/qxas_log_retention.$arch.o" \
        "$work/switch.$arch.o" "$work/engine-diagnostics.$arch.o" "$work/apply-diagnostics.$arch.o" \
        -framework Foundation -framework CoreFoundation -lobjc -framework UIKit -framework CoreGraphics \
        -weak_framework Security -lSystem -o "$work/QXAS.$arch.dylib"
    "$bin/ldid" -S "$work/QXAS.$arch.dylib"
done
"$bin/lipo" -create "$work/QXAS.arm64.dylib" "$work/QXAS.arm64e.dylib" -output "$work/QXAS.dylib"
"$bin/lipo" -info "$work/QXAS.dylib"
printf 'BUILD_DIR=%s\n' "$work"
