#!/usr/bin/env python3
"""Build an upgrade DEB from the verified 1.1.29 diagnostic candidate."""
import argparse
import copy
import gzip
import hashlib
import io
import tarfile
from pathlib import Path

import build_candidate as base

BASELINE_SHA256 = 'a6e73a7d5b47626ec11cb501503c6a617b652ec178fc165e7882f699b022ea44'
OLD_VERSION = '1.1.29'
NEW_VERSION = '1.1.30'
DYLIB = 'Library/MobileSubstrate/DynamicLibraries/QXAS.dylib'
PLIST = 'Library/MobileSubstrate/DynamicLibraries/QXAS.plist'
base.NEW_VERSION = NEW_VERSION


def rebuild_tar(payload, rows=None, replacement=None):
    if rows is None:
        rows = base.tar_entries(payload)
    out = io.BytesIO()
    with tarfile.open(fileobj=out, mode='w', format=tarfile.USTAR_FORMAT) as archive:
        for member, value in rows:
            info = copy.copy(member)
            if value is not None and replacement is not None and base.name_of(member) == DYLIB:
                value = replacement
                info.size = len(value)
            archive.addfile(info, io.BytesIO(value) if value is not None else None)
    return gzip.compress(out.getvalue(), compresslevel=9, mtime=0)


def build(baseline, dylib):
    if hashlib.sha256(baseline).hexdigest() != BASELINE_SHA256:
        raise ValueError('input is not the verified 1.1.29 diagnostic candidate DEB')
    ar = base.unpack_ar(baseline)
    control = base.tar_entries(ar['control.tar.gz'])
    require_control = False
    control_rows = []
    for member, value in control:
        if member.isfile():
            if base.name_of(member) != 'control':
                raise ValueError('unexpected DEBIAN control file')
            old = f'Version: {OLD_VERSION}\n'.encode()
            if value.count(old) != 1:
                raise ValueError('baseline package version mismatch')
            value = value.replace(old, f'Version: {NEW_VERSION}\n'.encode())
            require_control = True
        control_rows.append((member, value))
    if not require_control:
        raise ValueError('DEBIAN/control not found')

    rows = base.tar_entries(ar['data.tar.gz'])
    files = sorted(base.name_of(m) for m, _ in rows if m.isfile())
    if files != sorted((DYLIB, PLIST)):
        raise ValueError(f'unexpected payload files: {files}')
    patched_dylib = base.patch_fat(dylib)
    out = dict(ar)
    out['control.tar.gz'] = rebuild_tar(ar['control.tar.gz'], control_rows)
    out['data.tar.gz'] = rebuild_tar(ar['data.tar.gz'], rows, patched_dylib)
    result = base.pack_ar(out)

    check = base.unpack_ar(result)
    check_control = base.tar_entries(check['control.tar.gz'])
    if not any(m.isfile() and base.name_of(m) == 'control' and f'Version: {NEW_VERSION}\n'.encode() in v for m, v in check_control):
        raise ValueError('control round-trip validation failed')
    check_rows = base.tar_entries(check['data.tar.gz'])
    actual = next(v for m, v in check_rows if m.isfile() and base.name_of(m) == DYLIB)
    if actual != patched_dylib:
        raise ValueError('dylib round-trip validation failed')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('baseline', type=Path)
    parser.add_argument('dylib', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    result = build(args.baseline.read_bytes(), args.dylib.read_bytes())
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('xb') as stream:
        stream.write(result)
    print(f'{args.output}: {len(result)} bytes SHA256 {hashlib.sha256(result).hexdigest()}')


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, tarfile.TarError, KeyError) as error:
        raise SystemExit(f'build failed: {error}')
