#!/usr/bin/env python3
"""Build the 1.1.43 failover-only candidate."""
import argparse
import hashlib
from pathlib import Path
import build_diagnostic_deb as package
import validate_relinked_deb as validator

BASELINE_SHA256 = '042217a2f80adbacec238ba3ee243bb4e7252ce7d4a68c3468c31891af3896d7'
OLD_VERSION = '1.1.42'
NEW_VERSION = '1.1.43'

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('baseline', type=Path)
    parser.add_argument('dylib', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    baseline = args.baseline.read_bytes()
    result = package.build(baseline, args.dylib.read_bytes(), baseline_sha=BASELINE_SHA256,
                           old_version=OLD_VERSION, new_version=NEW_VERSION,
                           embedded_version=NEW_VERSION)
    validator.validate(result, baseline, NEW_VERSION)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('xb') as stream:
        stream.write(result)
    print(f'{args.output}: {len(result)} bytes SHA256 {hashlib.sha256(result).hexdigest()}')

if __name__ == '__main__':
    try:
        main()
    except (AssertionError, ValueError, OSError, KeyError) as error:
        raise SystemExit(f'build failed: {error}')
