#!/usr/bin/env python3
"""Build the 1.1.32 path-fix upgrade from the verified 1.1.31 diagnostic DEB."""
import argparse
import hashlib
from pathlib import Path

import build_diagnostic_deb as diagnostic

BASELINE_SHA256 = 'a933a96f25580dcfed609a4a684d3917386c92d0bc7114b888a2a82bfc291a1f'
OLD_VERSION = '1.1.31'
NEW_VERSION = '1.1.32'


def build(baseline, dylib):
    if hashlib.sha256(baseline).hexdigest() != BASELINE_SHA256:
        raise ValueError('input is not the verified 1.1.31 diagnostic DEB')
    saved = (diagnostic.BASELINE_SHA256, diagnostic.OLD_VERSION, diagnostic.NEW_VERSION)
    diagnostic.BASELINE_SHA256 = BASELINE_SHA256
    diagnostic.OLD_VERSION = OLD_VERSION
    diagnostic.NEW_VERSION = NEW_VERSION
    try:
        return diagnostic.build(baseline, dylib)
    finally:
        diagnostic.BASELINE_SHA256, diagnostic.OLD_VERSION, diagnostic.NEW_VERSION = saved


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('baseline', type=Path)
    parser.add_argument('dylib', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    result = build(args.baseline.read_bytes(), args.dylib.read_bytes())
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('xb') as stream:
        stream.write(result)
    print(f'{args.output}: {len(result)} bytes SHA256 {hashlib.sha256(result).hexdigest()}')


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, KeyError) as error:
        raise SystemExit(f'build failed: {error}')
