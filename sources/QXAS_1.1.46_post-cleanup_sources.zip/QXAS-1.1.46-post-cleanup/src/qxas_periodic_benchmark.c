#include "qxas_periodic_benchmark.h"
#include <errno.h>
#include <stdlib.h>
#include <string.h>

unsigned char *qxas_add_periodic_benchmark(const unsigned char *data, size_t *length, size_t limit) {
    // Only the healthy branch is extended; leave failure recovery unchanged.
    static const char anchor[] = "          return null;\n        }\n        var pool = CANDIDATES.filter";
    static const char code[] =
        "          if (!hasPrefs) return null;\n"
        "          var bmNow = Date.now(), bmLast = Number(pg('qxas_benchmark_last') || 0);\n"
        "          if (bmLast > 0 && bmNow >= bmLast && bmNow - bmLast < 900000) return null;\n"
        "          var bmTags = CANDIDATES.filter(function (t, i, a) { return typeof t === 'string' && t && t !== current && a.indexOf(t) === i; });\n"
        "          if (!bmTags.length) return null;\n"
        "          var bmFirst = Math.floor(Number(pg('qxas_benchmark_offset') || 0));\n"
        "          if (!isFinite(bmFirst) || bmFirst < 0 || bmFirst >= bmTags.length) bmFirst = 0;\n"
        "          var bmBatch = [], bmCount = Math.min(6, bmTags.length);\n"
        "          for (var bi = 0; bi < bmCount; bi++) bmBatch.push(bmTags[(bmFirst + bi) % bmTags.length]);\n"
        "          ps('qxas_benchmark_last', String(bmNow));\n"
        "          if (pg('qxas_benchmark_last') !== String(bmNow)) return null;\n"
        "          ps('qxas_benchmark_offset', String((bmFirst + bmCount) % bmTags.length));\n"
        "          return Promise.resolve().then(function () { return api('url_latency_benchmark', bmBatch); }).catch(function () { return null; });\n"
        "        }\n        var pool = CANDIDATES.filter";
    size_t n = *length, old = sizeof anchor - 1, add = sizeof code - 1;
    if (n > limit || n == (size_t)-1) { errno = EFBIG; return NULL; }
    if (memchr(data,0,n)) { errno = EINVAL; return NULL; }
    char *text = malloc(n+1);
    if (!text) return NULL;
    memcpy(text,data,n); text[n]=0;
    char *pos = strstr(text,anchor);
    if (!pos || strstr(pos+old,anchor)) { free(text); errno=EINVAL; return NULL; }
    if (add > limit-(n-old) || n-old+add == (size_t)-1) { free(text); errno=EFBIG; return NULL; }
    size_t off=(size_t)(pos-text), final=n-old+add;
    unsigned char *out=malloc(final+1);
    if (!out) { free(text); errno=ENOMEM; return NULL; }
    memcpy(out,text,off); memcpy(out+off,code,add); memcpy(out+off+add,pos+old,n-off-old+1);
    free(text); *length=final; return out;
}
