#include "qxas_runtime_trace.h"
#include <errno.h>
#include <stdlib.h>
#include <string.h>

// Match the Engine-generated script, not the recovered working copy. Each
// anchor must be unique. A mismatch leaves the published file untouched.
static const struct { const char *anchor; const char *replacement; } edits[] = {
    {"var finished = false;", "var finished = false; var qxRun = Date.now(); function qxTrace(s) { try { console.log('QXAS-TRACE 1.1.40 run=' + qxRun + ' ' + s); } catch (_) {} }"},
    {"function () { finish(); }", "function () { qxTrace('watchdog'); finish(); }"},
    {"finished = true; clearTimeout", "finished = true; qxTrace('done'); clearTimeout"},
    {"function run() {", "function run() { qxTrace('start');"},
    {"if (content !== undefined) msg.content = content;", "if (content !== undefined) msg.content = content; qxTrace('api=' + action);"},
    {"if (avg(p1, current) !== null) {", "if (avg(p1, current) !== null) { qxTrace('current=healthy');"},
    {"var pool = CANDIDATES.filter", "qxTrace('current=timeout'); var pool = CANDIDATES.filter"},
    {"if (last && Date.now() - last < COOLDOWN) return null;", "if (last && Date.now() - last < COOLDOWN) { qxTrace('cooldown'); return null; }"},
    {"if (leaf(s2) !== pick) return;", "if (leaf(s2) !== pick) { qxTrace('switch=not-confirmed'); return; } qxTrace('switch=confirmed');"},
    {"var s = String(e);", "var s = String(e); var known = /^Error: (no-api|no-proxy|no-candidates|no-healthy|api-[a-z_]+)$/.exec(s); qxTrace('error=' + (known ? known[1] : 'unexpected'));"},
};

unsigned char *qxas_trace_script(const unsigned char *data, size_t *length, size_t limit) {
    size_t n = *length;
    if (n > limit || n == (size_t)-1) { errno = EFBIG; return NULL; }
    if (memchr(data, 0, n)) { errno = EINVAL; return NULL; }
    char *text = malloc(n + 1);
    if (!text) return NULL;
    memcpy(text, data, n);
    text[n] = 0;
    for (size_t i = 0; i < sizeof edits / sizeof *edits; ++i) {
        size_t old = strlen(edits[i].anchor), add = strlen(edits[i].replacement);
        char *pos = strstr(text, edits[i].anchor);
        if (!pos || strstr(pos + old, edits[i].anchor)) { free(text); errno = EINVAL; return NULL; }
        if (add > limit - (n - old) || n - old + add == (size_t)-1) { free(text); errno = EFBIG; return NULL; }
        size_t len = n - old + add, off = (size_t)(pos - text);
        char *next = malloc(len + 1);
        if (!next) { free(text); errno = ENOMEM; return NULL; }
        memcpy(next, text, off);
        memcpy(next + off, edits[i].replacement, add);
        memcpy(next + off + add, pos + old, n - off - old + 1);
        free(text);
        text = next;
        n = len;
    }
    *length = n;
    return (unsigned char *)text;
}
