#pragma once
#include <stddef.h>
unsigned char *qxas_add_periodic_benchmark(const unsigned char *data, size_t *length, size_t limit);
