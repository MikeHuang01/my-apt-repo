#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import "qxas_app_log.h"

@interface QXASEngine : NSObject
- (BOOL)backupData:(id)data forPath:(NSString *)path error:(NSError *__autoreleasing *)error;
- (BOOL)writeConfData:(id)data toPath:(NSString *)path error:(NSError *__autoreleasing *)error;
- (BOOL)applyNow:(NSError *__autoreleasing *)error;
- (BOOL)applyScriptMode:(NSError *__autoreleasing *)error;
- (BOOL)restoreNow:(NSError *__autoreleasing *)error;
@end

@implementation QXASEngine (QXASWriteDiagnostics)
+ (void)load {
    SEL pairs[][2] = {
        {@selector(backupData:forPath:error:), @selector(qxas_diag_backupData:forPath:error:)},
        {@selector(writeConfData:toPath:error:), @selector(qxas_diag_writeConfData:toPath:error:)},
        {@selector(applyNow:), @selector(qxas_diag_applyNow:)},
        {@selector(applyScriptMode:), @selector(qxas_diag_applyScriptMode:)},
        {@selector(restoreNow:), @selector(qxas_diag_restoreNow:)}
    };
    for (NSUInteger i=0; i<sizeof pairs/sizeof *pairs; ++i) {
        Method original=class_getInstanceMethod(self,pairs[i][0]);
        Method diagnostic=class_getInstanceMethod(self,pairs[i][1]);
        if (original && diagnostic) method_exchangeImplementations(original, diagnostic);
    }
}
- (BOOL)qxas_diag_backupData:(id)data forPath:(NSString *)path error:(NSError *__autoreleasing *)error {
    BOOL ok = [self qxas_diag_backupData:data forPath:path error:error];
    if (!ok) NSLog(@"QXAS engine backupData failed");
    return ok;
}
- (BOOL)qxas_diag_writeConfData:(id)data toPath:(NSString *)path error:(NSError *__autoreleasing *)error {
    BOOL ok = [self qxas_diag_writeConfData:data toPath:path error:error];
    if (!ok) NSLog(@"QXAS engine writeConfData failed");
    return ok;
}
- (BOOL)qxas_diag_applyNow:(NSError *__autoreleasing *)error {
    return [self applyScriptMode:error];
}
- (BOOL)qxas_diag_applyScriptMode:(NSError *__autoreleasing *)error {
    BOOL ok = [self qxas_diag_applyScriptMode:error];
    if (ok) QXASAppLog(@"任务已写入配置。请到 QX「请求列表」确认 QXAS-Controller 已加载。");
    return ok;
}
- (BOOL)qxas_diag_restoreNow:(NSError *__autoreleasing *)error {
    BOOL ok = [self qxas_diag_restoreNow:error];
    if (!ok) QXASAppLog(@"关闭后未能确认配置已还原，请查看上方错误。");
    return ok;
}
@end
