#pragma once
#include <stddef.h>
enum qxas_script_preparation {
    QXAS_SCRIPT_ERROR = -1,
    QXAS_SCRIPT_MIRRORED = 0,
};
// Copy the validated Engine source into Documents/Scripts; return its task filename.
#define QXAS_TASK_SCRIPT "qxas-controller-managed.js"
int qxas_prepare_local_script(const char *home, const char *source,
                              char *task_source, size_t task_source_size);
#ifdef QXAS_RUNTIME_TRACE
int qxas_prepare_traced_script_with_error(const char *home, const char *source,
                                          char *task_source, size_t task_source_size,
                                          const char **failed_step, int *error_number);
#endif
int qxas_prepare_stable_script_with_error(const char *home, const char *source,
                                         char *task_source, size_t task_source_size,
                                         const char **failed_step, int *error_number);
int qxas_prepare_local_script_with_error(const char *home, const char *source,
                                         char *task_source, size_t task_source_size,
                                         const char **failed_step, int *error_number);
