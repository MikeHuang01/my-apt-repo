#import <Foundation/Foundation.h>
#include "qxas_task_path.h"
#include "qxas_task_check.h"
#include <stdlib.h>
#import "qxas_app_log.h"
#include <stddef.h>
#include <errno.h>
#include <limits.h>
extern int qxas_apply_task(const char *, size_t, const char *, char **, size_t *, int *);

// The engine still writes and checks its original private controller first.
// Its original backup and config-write gates run after this function returns.
int qxas_local_task(const char *config, size_t length, const char *source,
                    char **output, size_t *output_length, int *changed) {
    int entry_errno = errno;
    errno = entry_errno;
    if (output) *output = NULL;
    if (output_length) *output_length = 0;
    if (changed) *changed = 0;
    if (!config || !output) {
        errno = EINVAL;
        return -1;
    }
    @autoreleasepool {
        const char *failed_step = NULL;
        int error_number = 0;
        char task_source[PATH_MAX];
        int preparation = qxas_prepare_stable_script_with_error(
            [NSHomeDirectory() fileSystemRepresentation], source, task_source, sizeof task_source,
            &failed_step, &error_number);
        if (preparation == QXAS_SCRIPT_ERROR) {
            int result_errno = error_number;
            QXASAppLog([NSString stringWithFormat:@"无法准备控制器脚本：%s（错误 %d）",
                                       failed_step ?: "unknown step", error_number]);
            errno = result_errno;
            return -1;
        }
        size_t scratch = 0;
        size_t *actual_length = output_length ? output_length : &scratch;
        errno = entry_errno;
        int result = qxas_apply_task(config, length, task_source, output, actual_length, changed);
        int result_errno = errno;
        if (result == 0 && !qxas_has_single_task(*output, *actual_length)) {
            free(*output);
            *output = NULL;
            *actual_length = 0;
            if (changed) *changed = 0;
            QXASAppLog(@"未写入配置：QXAS-Controller 任务缺失、重复或格式不正确。");
            errno = EINVAL;
            return -1;
        }
        if (result < 0) NSLog(@"QXAS task transformation status=%d", result);
        errno = result_errno;
        return result;
    }
}
