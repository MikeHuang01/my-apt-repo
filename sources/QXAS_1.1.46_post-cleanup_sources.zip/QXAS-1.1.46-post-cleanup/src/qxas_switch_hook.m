#import <UIKit/UIKit.h>
#import <objc/message.h>
#import <objc/runtime.h>

@interface QXASSettingsController : UITableViewController
@end

@interface QXASSettingsController (QXASAutomaticLifecycle)
- (void)qxas_switchHook_mainSwitchChanged:(UISwitch *)sender;
@end

@implementation QXASSettingsController (QXASAutomaticLifecycle)

+ (void)load {
    Method original = class_getInstanceMethod(self, sel_registerName("mainSwitchChanged:"));
    Method hook = class_getInstanceMethod(self, @selector(qxas_switchHook_mainSwitchChanged:));
    if (original && hook) method_exchangeImplementations(original, hook);
}

- (void)qxas_switchHook_mainSwitchChanged:(UISwitch *)sender {
    BOOL enabled = sender.isOn;
    NSLog(@"QXAS diagnostic package loaded 1.1.46; QXAS main switch changed: %@", enabled ? @"on" : @"off");
    ((void (*)(id, SEL, id))objc_msgSend)(self,
        @selector(qxas_switchHook_mainSwitchChanged:), sender);
}

@end
