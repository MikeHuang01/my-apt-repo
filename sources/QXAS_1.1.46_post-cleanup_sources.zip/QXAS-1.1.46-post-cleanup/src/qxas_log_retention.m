#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import "qxas_app_log.h"
#include "qxas_log_window.h"
#include <stdarg.h>

@interface QXASStore (QXASLogPath)
- (NSString *)logPath;
@end

static void trimLog(QXASStore *store, BOOL force) {
    static NSTimeInterval last;
    NSString *path = [store logPath];
    if (!path.length) return;
    NSDictionary *attrs = [NSFileManager.defaultManager attributesOfItemAtPath:path error:NULL];
    if (![attrs[NSFileType] isEqual:NSFileTypeRegular]) return;
    unsigned long long size = [attrs fileSize];
    NSTimeInterval now = NSDate.date.timeIntervalSince1970;
    if (!force && size <= QXAS_LOG_BYTES && now >= last && now-last < 60) return;
    NSFileHandle *handle = [NSFileHandle fileHandleForReadingAtPath:path];
    if (!handle) return;
    NSMutableData *bytes = nil;
    @try {
        // Logs are append-only. Do not allocate an unbounded legacy log.
        if (size > 2 * QXAS_LOG_BYTES) [handle seekToFileOffset:size - 2 * QXAS_LOG_BYTES];
        bytes = [[handle readDataOfLength:2 * QXAS_LOG_BYTES] mutableCopy];
    } @catch (__unused NSException *e) {
    } @finally {
        [handle closeFile];
    }
    if (!bytes) return;
    size_t n = qxas_log_window(bytes.mutableBytes, bytes.length, (time_t)now, QXAS_LOG_BYTES);
    if (n != size) {
        bytes.length = n;
        if (![bytes writeToFile:path options:NSDataWritingAtomic error:NULL]) return;
    }
    last = now;
}

@implementation QXASStore (QXASLogRetention)
+ (void)load {
    SEL pairs[][2] = {
        {@selector(log:), @selector(qxas_window_log:)},
        {sel_registerName("trimLogIfNeeded"), @selector(qxas_window_trim)},
        {sel_registerName("logText"), @selector(qxas_window_text)},
        {sel_registerName("clearLog"), @selector(qxas_window_clear)}
    };
    for (NSUInteger i = 0; i < sizeof pairs / sizeof *pairs; i++) {
        if (!class_getInstanceMethod(self,pairs[i][0]) || !class_getInstanceMethod(self,pairs[i][1])) return;
    }
    for (NSUInteger i = 0; i < sizeof pairs / sizeof *pairs; i++) {
        method_exchangeImplementations(class_getInstanceMethod(self,pairs[i][0]),class_getInstanceMethod(self,pairs[i][1]));
    }
}
- (void)qxas_window_log:(NSString *)format, ... {
    if (!format) return;
    va_list ap;
    va_start(ap, format);
    NSString *message = [[NSString alloc] initWithFormat:format arguments:ap];
    va_end(ap);
    @synchronized(self) { [self qxas_window_log:@"%@", message]; }
}
- (void)qxas_window_trim { @synchronized(self) { trimLog(self, NO); } }
- (NSString *)qxas_window_text { @synchronized(self) { trimLog(self, YES); return [self qxas_window_text]; } }
- (void)qxas_window_clear { @synchronized(self) { [self qxas_window_clear]; } }
@end
