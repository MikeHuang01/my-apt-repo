#include "qxas_failover.h"
#include "qxas_failover_generated.h"
#include <errno.h>
#include <stdlib.h>
#include <string.h>

unsigned char *qxas_stable_failover(const unsigned char *data, size_t *length, size_t limit) {
    size_t end = *length;
    if (end > limit) { errno = EFBIG; return NULL; }
    if (!end || memchr(data, 0, end)) { errno = EINVAL; return NULL; }
    while (end && (data[end-1] == '\n' || data[end-1] == '\r')) --end;
    if (end <= sizeof old_suffix || memcmp(data+end-sizeof old_suffix, old_suffix, sizeof old_suffix)) {
        errno = EINVAL; return NULL;
    }
    size_t prefix = end - sizeof old_suffix;
    if (sizeof new_suffix > limit-prefix) { errno = EFBIG; return NULL; }
    unsigned char *out = malloc(prefix+sizeof new_suffix);
    if (!out) { errno = ENOMEM; return NULL; }
    memcpy(out,data,prefix);
    memcpy(out+prefix,new_suffix,sizeof new_suffix);
    *length = prefix+sizeof new_suffix;
    return out;
}
