#include "qxas_task_check.h"
#include "qxas_task_path.h"
#include <string.h>

static int equal(const char *p, size_t n, const char *expected) {
    return strlen(expected) == n && !memcmp(p, expected, n);
}
static void trim(const char **p, const char **end) {
    while (*p < *end && (**p == ' ' || **p == '\t')) ++*p;
    while (*end > *p && ((*end)[-1] == ' ' || (*end)[-1] == '\t' || (*end)[-1] == '\r')) --*end;
}
int qxas_has_single_task(const char *data, size_t length) {
    static const char expected[] = "* * * * * " QXAS_TASK_SCRIPT ", tag=QXAS-Controller, enabled=true";
    if (!data || !length || memchr(data, 0, length)) return 0;
    const char *p = data, *limit = data + length;
    if (length >= 3 && !memcmp(p, "\xef\xbb\xbf", 3)) p += 3;
    int local = 0, count = 0;
    while (p < limit) {
        const char *end = memchr(p, '\n', (size_t)(limit-p));
        if (!end) end = limit;
        const char *next = end < limit ? end + 1 : end;
        trim(&p, &end);
        if (p < end && *p == '[') local = equal(p, (size_t)(end-p), "[task_local]");
        else if (local && p < end && *p != '#' && *p != ';') {
            if (equal(p, (size_t)(end-p), expected)) {
                if (++count > 1) return 0;
                p = next;
                continue;
            }
            const char *token = memchr(p, ',', (size_t)(end-p));
            while (token && token < end) {
                const char *left = token+1;
                token = memchr(left, ',', (size_t)(end-left));
                const char *right = token ? token : end;
                trim(&left, &right);
                if (equal(left, (size_t)(right-left), "tag=QXAS-Controller")) return 0;
            }
        }
        p = next;
    }
    return count == 1;
}
