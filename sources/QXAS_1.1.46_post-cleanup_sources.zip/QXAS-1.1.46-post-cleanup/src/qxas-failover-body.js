  // QXAS_STABLE_FAILOVER_1_1_44
  var COOLDOWN = 180000, RECENT = 1800000, BATCH = 5, MAX_BATCHES = 3;
  var started = Date.now(), finished = false;
  var killer = setTimeout(finish, 38000);
  function finish() { if (!finished) { finished = true; clearTimeout(killer); $done(); } }
  function pg(k) { try { return $prefs.valueForKey(k); } catch (_) { return null; } }
  function ps(k,v) { try { $prefs.setValueForKey(v,k); } catch (_) {} }
  function objectPref(k) { try { return JSON.parse(pg(k)); } catch (_) { return null; } }
  function notify(s) { try { if (typeof $notify === 'function') $notify('QX 自动优选', s); } catch (_) {} }
  function api(action, content) {
    if (finished || Date.now() - started >= 35000) return Promise.reject(new Error('budget'));
    var msg = {action:action};
    if (content !== undefined) msg.content = content;
    return Promise.resolve($configuration.sendMessage(msg)).then(function (r) {
      if (finished) throw new Error('budget');
      if (!r || r.error) throw new Error('api-' + action);
      return r.ret;
    });
  }
  // Stop waiting on a stalled native measurement; do not queue another after a timeout.
  function measure(tags) {
    return new Promise(function (resolve,reject) {
      var timer = setTimeout(function () { reject(new Error('probe-budget')); }, 6500);
      Promise.resolve().then(function () { return api('url_latency_benchmark',tags); }).then(function (r) {
        clearTimeout(timer); resolve(r);
      },function (err) { clearTimeout(timer); reject(err); });
    });
  }
  function chain(state) { return state && Array.isArray(state.proxy) && state.proxy.length ? state.proxy : null; }
  function leaf(path) { return path && path[path.length-1]; }
  function sample(result,tag) {
    var list = result && Object.prototype.hasOwnProperty.call(result,tag) && result[tag];
    if (!Array.isArray(list) || !list.length) return null;
    // Quantumult X reports TCP/HTTP separately; a valid TCP handshake alone is not health.
    if (list.length !== 1 && list.length !== 2) return null;
    var latency=list[list.length-1];
    if (typeof latency !== 'number' || !isFinite(latency)) return null;
    return latency < 0 ? {failed:true} : {latency:latency};
  }
  function regionOf(tag) {
    var regions = [['US','美国'],['JP','日本'],['HK','香港'],['TW','台湾','台灣'],['SG','新加坡'],['KR','韩国','韓國'],['UK','英国','英國'],['DE','德国','德國'],['FR','法国','法國'],['CA','加拿大'],['AU','澳大利亚','澳洲'],['RU','俄罗斯'],['IN','印度'],['TR','土耳其'],['BR','巴西'],['NL','荷兰'],['CH','瑞士'],['SE','瑞典'],['MY','马来西亚'],['TH','泰国'],['VN','越南'],['PH','菲律宾'],['ID','印尼'],['AE','迪拜'],['ZA','南非']];
    var upper = tag.toUpperCase();
    for (var i=0; i<regions.length; i++) {
      var row=regions[i];
      for (var j=1; j<row.length; j++) if (tag.indexOf(row[j]) >= 0) return row[0];
      if (new RegExp('(^|[^A-Z0-9])'+row[0]+'(?=$|[^A-Z])').test(upper)) return row[0];
    }
    return '';
  }
  function cooling() {
    var last = Number(pg('qxas_last_switch') || 0), age = Date.now()-last;
    return last > 0 && age >= 0 && age < COOLDOWN;
  }
  function history() {
    var data=objectPref('qxas_failover_history'), recent=Object.create(null), now=Date.now();
    if (!Array.isArray(data)) return recent;
    data.slice(0,32).forEach(function (pair) {
      if (Array.isArray(pair) && typeof pair[0] === 'string' && typeof pair[1] === 'number' && now >= pair[1] && now-pair[1] < RECENT) recent[pair[0]]=pair[1];
    });
    return recent;
  }
  function remember(recent, tag) {
    recent[tag]=Date.now();
    var rows=Object.keys(recent).sort(function (a,b) {return recent[b]-recent[a];}).slice(0,32);
    ps('qxas_failover_history',JSON.stringify(rows.map(function (t) {return [t,recent[t]];})));
  }
  function find(current, recent, cursor) {
    var region=regionOf(current), seen=Object.create(null), pool=[];
    CANDIDATES.forEach(function (tag) {
      if (typeof tag !== 'string' || !tag || tag === current || seen[tag]) return;
      seen[tag]=1;
      pool.push({tag:tag, order:pool.length, same:!!region && regionOf(tag) === region, recent:!!recent[tag]});
    });
    if (!pool.length) return Promise.reject(new Error('no-candidates'));
    pool.sort(function (a,b) {return b.same-a.same || b.recent-a.recent || a.order-b.order;});
    var offset=cursor && cursor.current === current && Number.isInteger(cursor.next) && cursor.next >= 0 && cursor.next < pool.length && Date.now() >= cursor.time && Date.now()-cursor.time < 600000 ? cursor.next : 0;
    var step=0;
    function next() {
      if (step >= Math.min(MAX_BATCHES*BATCH,pool.length) || Date.now()-started > 27500 || cooling()) return null;
      var count=Math.min(BATCH,pool.length-step), batch=[];
      for (var i=0;i<count;i++) batch.push(pool[(offset+step+i)%pool.length]);
      step+=count;
      return measure(batch.map(function (x) {return x.tag;})).then(function (results) {
        if (!results || typeof results !== 'object') return null;
        batch.forEach(function (x) { x.test=sample(results,x.tag); });
        if (batch.some(function (x) { return !!x.test; })) {
          ps('qxas_failover_cursor',JSON.stringify({current:current,next:(offset+step)%pool.length,time:Date.now()}));
        }
        var usable=batch.filter(function (x) { return x.test && !x.test.failed; });
        usable.sort(function (a,b) {return b.same-a.same || b.recent-a.recent || a.test.latency-b.test.latency || a.order-b.order;});
        return usable.length ? usable[0] : next();
      });
    }
    return next();
  }
  function run() {
    if (typeof $configuration === 'undefined' || !$configuration || typeof $configuration.sendMessage !== 'function') throw new Error('no-api');
    return api('get_policy_state').then(function (state) {
      var path=chain(state), current=leaf(path);
      if (typeof current !== 'string' || !current) throw new Error('no-proxy');
      var snapshot=JSON.stringify(path), cursor=objectPref('qxas_failover_cursor');
      function healthy() {
        if (cursor && cursor.current === current) ps('qxas_failover_cursor','null');
        if (!pg('qxas_informed')) { notify('控制器运行正常，当前节点可用：'+current); ps('qxas_informed','1'); }
        return null;
      }
      return measure([current]).then(function (r) {
        var first=sample(r,current);
        if (first && !first.failed) return healthy();
        if (!first || cooling()) return null;
        return measure([current]).then(function (r2) {
          var second=sample(r2,current);
          if (second && !second.failed) return healthy();
          if (!second || cooling()) return null;
          var recent=history();
          return Promise.resolve(find(current,recent,cursor)).then(function (pick) {
            if (!pick || cooling()) return null;
            return api('get_policy_state').then(function (check) {
              if (JSON.stringify(chain(check)) !== snapshot || cooling()) return null;
              return api('set_policy_state',{proxy:pick.tag}).then(function () {
                return api('get_policy_state').then(function (after) {
                  if (leaf(chain(after)) !== pick.tag) return;
                  ps('qxas_last_switch',String(Date.now()));
                  ps('qxas_failover_cursor','null'); remember(recent,pick.tag);
                  if (NOTIFY) notify('当前节点超时，已切换到 '+pick.tag+(pick.same?'（同地区优先）':''));
                });
              });
            });
          });
        });
      });
    });
  }
  Promise.resolve().then(run).catch(function (e) {
    if (finished) return;
    if (e.message === 'no-api') notify('QX 未提供脚本控制接口，请检查 QX 版本');
    else if (e.message === 'no-proxy') notify('QX 当前没有可用策略节点，未执行自动切换');
    else if (e.message === 'no-candidates') notify('QX 没有可测速的候选节点，请检查节点筛选设置');
  }).then(finish);
}());
