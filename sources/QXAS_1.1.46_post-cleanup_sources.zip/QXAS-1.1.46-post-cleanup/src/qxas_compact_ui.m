#import <UIKit/UIKit.h>
#import <objc/message.h>
#import <objc/runtime.h>
#import "qxas_app_log.h"

@interface QXASSettingsController : UITableViewController
- (void)showLog;
@end

// Map visible rows to the pinned QXASUI.o layout. Use the same mapping for
// display and selection so retained settings keep their original handlers.
static NSInteger originalRow(NSInteger section, NSInteger row) {
    static const NSInteger counts[] = {1, 5, 1, 1, 0};
    if (section < 0 || section >= (NSInteger)(sizeof counts / sizeof *counts) || row < 0 || row >= counts[section]) return NSNotFound;
    if (section == 2) return 2; // 查看日志
    if (section == 3) return 4; // 成功切换后通知
    return row;
}

@implementation QXASSettingsController (QXASCompactSettings)
+ (void)load {
    SEL pairs[][2] = {
        {@selector(tableView:numberOfRowsInSection:), @selector(qxas_compact_tableView:numberOfRowsInSection:)},
        {@selector(tableView:cellForRowAtIndexPath:), @selector(qxas_compact_tableView:cellForRowAtIndexPath:)},
        {@selector(tableView:didSelectRowAtIndexPath:), @selector(qxas_compact_tableView:didSelectRowAtIndexPath:)},
        {@selector(tableView:titleForHeaderInSection:), @selector(qxas_compact_tableView:titleForHeaderInSection:)},
        {@selector(tableView:titleForFooterInSection:), @selector(qxas_compact_tableView:titleForFooterInSection:)}
    };
    for (NSUInteger i = 0; i < sizeof pairs / sizeof *pairs; i++) {
        if (!class_getInstanceMethod(self, pairs[i][0]) || !class_getInstanceMethod(self, pairs[i][1])) return;
    }
    for (NSUInteger i = 0; i < sizeof pairs / sizeof *pairs; i++) {
        method_exchangeImplementations(class_getInstanceMethod(self, pairs[i][0]), class_getInstanceMethod(self, pairs[i][1]));
    }
}
- (NSInteger)qxas_compact_tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 2 || section == 3) return 1;
    if (section == 4) return 1; // Plain, non-interactive About text.
    return [self qxas_compact_tableView:tableView numberOfRowsInSection:section];
}
- (UITableViewCell *)qxas_compact_tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)path {
    if (path.section == 4 && path.row == 0) {
        UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
        UIListContentConfiguration *content = [UIListContentConfiguration cellConfiguration];
        content.text = @"插件版本  1.1.46\n作者  MikeHuang01\n越狱源  https://mikehuang01.github.io/my-apt-repo/v3/";
        content.textProperties.transform = UIListContentTextTransformNone;
        content.textProperties.numberOfLines = 0;
        content.textProperties.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
        content.textProperties.color = UIColor.secondaryLabelColor;
        content.directionalLayoutMargins = NSDirectionalEdgeInsetsMake(4, 20, 12, 20);
        cell.contentConfiguration = content;
        cell.backgroundConfiguration = [UIBackgroundConfiguration clearConfiguration];
        cell.backgroundColor = UIColor.clearColor;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    NSInteger row = originalRow(path.section, path.row);
    if (row == NSNotFound) return [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    NSIndexPath *legacy = row == path.row ? path : [NSIndexPath indexPathForRow:row inSection:path.section];
    return [self qxas_compact_tableView:tableView cellForRowAtIndexPath:legacy];
}
- (void)qxas_compact_tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)path {
    NSInteger row = originalRow(path.section, path.row);
    if (row == NSNotFound) return;
    if (path.section == 2) {
        [tableView deselectRowAtIndexPath:path animated:YES];
        if (path.row == 0) [self showLog];
    } else if (path.section == 3) {
        [tableView deselectRowAtIndexPath:path animated:YES];
    } else {
        [self qxas_compact_tableView:tableView didSelectRowAtIndexPath:path];
    }
}
- (NSString *)qxas_compact_tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if (section == 3) return @"通知";
    if (section == 4) return @"关于";
    return [self qxas_compact_tableView:tableView titleForHeaderInSection:section];
}
- (NSString *)qxas_compact_tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    if (section == 0) return @"开启后由 QX 定时检查；关闭后还原插件改写的配置。进度与错误可在查看日志中确认。";
    if (section == 2) return @"怎么用\n\n1. 先断开 QX 的 VPN，再打开上面的「自动优选」。等日志显示「任务已写入配置」。\n\n2. 打开QX的VPN连接，然后在QX请求列表确认QXAS-Controller出现。没有出现就后台划掉QX重新打开再看一次。\n\n智能优选规则\n\n• 每分钟检查当前节点。只要能测通，再慢也不换。\n• 当前节点连续两次测不通，才分批找可用节点。优先同地区、近期切换成功的节点，条件相同再选延迟较低的。\n• 成功切换后，3 分钟内不再切换。测速期间如果发现你手动换了节点，本轮就不替你换。\n\n不用时关掉「自动优选」，等日志显示配置已还原。日志最多保留 3 小时、256 KiB。";
    if (section == 3) return @"仅控制成功切换提示；QX VPN 和计划任务需保持开启。";
    return [self qxas_compact_tableView:tableView titleForFooterInSection:section];
}
@end

// A saved preference from a previous release must not re-enable the legacy mode.
static BOOL qxasSmartOnly(id object, SEL selector) {
    (void)object; (void)selector;
    return NO;
}

@implementation QXASStore (QXASSmartOnly)
+ (void)load {
    Method getter = class_getInstanceMethod(self, sel_registerName("useLatencyGroup"));
    if (getter) method_setImplementation(getter, (IMP)qxasSmartOnly);
}
@end

static UIFont *titleFont(UIButton *button) {
    NSAttributedString *title = button.titleLabel.attributedText;
    UIFont *font = title.length ? [title attribute:NSFontAttributeName atIndex:0 effectiveRange:NULL] : nil;
    return font ?: button.titleLabel.font;
}

static void matchFooterFont(UIView *footer) {
    NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithObject:footer];
    UIButton *plugin = nil, *namedPlugin = nil, *settings = nil, *toolbar = nil;
    for (NSUInteger i = 0; i < queue.count && i < 256; ++i) {
        UIView *view = queue[i];
        if (view.hidden || view.alpha <= 0.01) continue;
        [queue addObjectsFromArray:view.subviews];
        if (![view isKindOfClass:UIButton.class]) continue;
        UIButton *button = (UIButton *)view;
        for (id target in button.allTargets) {
            if ([[button actionsForTarget:target forControlEvent:UIControlEventTouchUpInside] containsObject:@"qxas_openPanel:"]) {
                plugin = button;
                break;
            }
        }
        NSString *title = button.currentTitle ?: button.titleLabel.text ?: button.configuration.title ?: button.configuration.attributedTitle.string;
        title = [title stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
        if ([title isEqualToString:@"QX 自动优选"]) namedPlugin = button;
        if ([title isEqualToString:@"其他设置"] || [title isEqualToString:@"其他設定"] || [title isEqualToString:@"Other Settings"]) settings = button;
        if ([title isEqualToString:@"面板 & 工具栏"] || [title isEqualToString:@"面板 & 工具列"] || [title isEqualToString:@"面板工具栏"] || [title isEqualToString:@"面板工具列"] || [title isEqualToString:@"工具栏"] || [title isEqualToString:@"Toolbar"]) toolbar = button;
    }
    plugin = plugin ?: namedPlugin;
    UIFont *font = settings != plugin ? titleFont(settings) : nil;
    if (!font && toolbar != plugin) font = titleFont(toolbar);
    if (!plugin || !font) return;
    UIButtonConfiguration *configuration = plugin.configuration;
    if (configuration) {
        static char fontKey, transformerKey;
        UIFont *previous = objc_getAssociatedObject(plugin, &fontKey);
        id transformer = objc_getAssociatedObject(plugin, &transformerKey);
        if (![previous isEqual:font] || transformer != configuration.titleTextAttributesTransformer) {
            UIConfigurationTextAttributesTransformer prior = configuration.titleTextAttributesTransformer;
            // Avoid stacking our own transformer when Dynamic Type changes.
            if (transformer && prior == transformer) prior = nil;
            configuration.titleTextAttributesTransformer = ^NSDictionary *(NSDictionary *incoming) {
                NSMutableDictionary *attrs = [(prior ? prior(incoming) : incoming) mutableCopy];
                attrs[NSFontAttributeName] = font;
                return attrs;
            };
            objc_setAssociatedObject(plugin, &fontKey, font, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            objc_setAssociatedObject(plugin, &transformerKey, configuration.titleTextAttributesTransformer, OBJC_ASSOCIATION_COPY_NONATOMIC);
            plugin.configuration = configuration;
        }
    } else {
        NSAttributedString *original = [plugin attributedTitleForState:UIControlStateNormal];
        if (original.length && ![titleFont(plugin) isEqual:font]) {
            NSMutableAttributedString *title = [original mutableCopy];
            [title addAttribute:NSFontAttributeName value:font range:NSMakeRange(0, title.length)];
            [plugin setAttributedTitle:title forState:UIControlStateNormal];
        }
    }
    if (![plugin.titleLabel.font isEqual:font]) plugin.titleLabel.font = font;
}

@interface QXASFooterTypography : NSObject
@end
@implementation QXASFooterTypography
+ (void)load {
    dispatch_async(dispatch_get_main_queue(), ^{
        Class cls = NSClassFromString(@"QTXMenuViewCollectionFooterView");
        SEL sel = @selector(layoutSubviews);
        Method method = cls ? class_getInstanceMethod(cls, sel) : NULL;
        if (!method) return;
        Class parent = class_getSuperclass(cls);
        IMP inheritedHook = imp_implementationWithBlock(^(UIView *view) {
            struct objc_super call = {view, parent};
            ((void (*)(struct objc_super *, SEL))objc_msgSendSuper)(&call, sel);
            matchFooterFont(view);
        });
        if (class_addMethod(cls, sel, inheritedHook, method_getTypeEncoding(method))) return;
        imp_removeBlock(inheritedHook);
        IMP prior = method_getImplementation(method);
        IMP hook = imp_implementationWithBlock(^(UIView *view) {
            ((void (*)(id, SEL))prior)(view, sel);
            matchFooterFont(view);
        });
        method_setImplementation(method, hook);
    });
}
@end
