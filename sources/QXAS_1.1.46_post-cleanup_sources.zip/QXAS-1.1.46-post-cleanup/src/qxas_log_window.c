#include "qxas_log_window.h"
#include <string.h>

static int digits(const char *s, int n) {
    int value = 0;
    for (int i = 0; i < n; ++i) {
        if (s[i] < '0' || s[i] > '9') return -1;
        value = value * 10 + s[i] - '0';
    }
    return value;
}

static int stamp(const char *line, size_t len, const struct tm *local,
                 time_t now, time_t *value) {
    if (len < 16 || line[0] != '[') return 0;
    int offset = len >= 21 && line[5] == '-' && line[20] == ']' ? 5 : 0;
    const char *s = line + 1 + offset;
    if (s[2] != '-' || s[5] != ' ' || s[8] != ':' || s[11] != ':' || s[14] != ']') return 0;
    int mon = digits(s,2), day = digits(s+3,2), h = digits(s+6,2), m = digits(s+9,2), sec = digits(s+12,2);
    if (mon < 1 || mon > 12 || day < 1 || day > 31 || h < 0 || h > 23 || m < 0 || m > 59 || sec < 0 || sec > 59) return 0;
    struct tm date = *local;
    if (offset) {
        int year = digits(line+1,4);
        if (year < 1900) return 0;
        date.tm_year = year-1900;
    }
    date.tm_mon = mon-1; date.tm_mday = day; date.tm_hour = h; date.tm_min = m; date.tm_sec = sec; date.tm_isdst = -1;
    struct tm before = date;
    time_t t = mktime(&date);
    if (!offset && difftime(t, now) > 86400) { date = before; --date.tm_year; t = mktime(&date); }
    if (t == (time_t)-1 || date.tm_mon != before.tm_mon || date.tm_mday != before.tm_mday) return 0;
    *value = t;
    return 1;
}

size_t qxas_log_window(char *data, size_t length, time_t now, size_t cap) {
    if (!length) return 0;
    const struct tm *clock = localtime(&now);
    if (!clock) return 0;
    // mktime can reuse time conversion state; keep an independent snapshot.
    const struct tm local = *clock;
    size_t read = 0, start = 0, out = 0;
    int keep = 0;
    while (read < length) {
        size_t end = read;
        while (end < length && data[end] != '\n') ++end;
        if (end < length) ++end;
        time_t timestamp;
        if (stamp(data+read,end-read,&local,now,&timestamp)) {
            if (keep) {
                if (out != start) memmove(data+out,data+start,read-start);
                out += read-start;
            }
            start = read;
            double age = difftime(now, timestamp);
            keep = age <= QXAS_LOG_AGE && age >= -300;
        }
        read = end;
    }
    if (keep) {
        if (out != start) memmove(data+out,data+start,length-start);
        out += length-start;
    }
    if (out <= cap) return out;
    size_t min = out-cap;
    if (min && data[min-1] != '\n') { while (min < out && data[min++] != '\n') {} }
    while (min < out) {
        time_t timestamp;
        if (stamp(data+min,out-min,&local,now,&timestamp)) break;
        while (min < out && data[min++] != '\n') {}
    }
    memmove(data,data+min,out-min);
    return out-min;
}
