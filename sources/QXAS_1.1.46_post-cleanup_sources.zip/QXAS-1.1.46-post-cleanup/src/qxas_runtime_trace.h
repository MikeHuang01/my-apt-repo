#pragma once
#include <stddef.h>
// Return malloc-owned diagnostic script bytes, or NULL with errno set.
unsigned char *qxas_trace_script(const unsigned char *data, size_t *length, size_t limit);
