#import <Foundation/Foundation.h>
#include <errno.h>
#include <stddef.h>

// QXASEngine calls this wrapper after the retained object is relinked so the
// original qxas_apply implementation remains the only implementation invoked.
extern int qxas_apply(const void *input, size_t length, const void *options,
                      char **output, size_t *output_length, int *changed);

int qxas_trace(const void *input, size_t length, const void *options,
               char **output, size_t *output_length, int *changed) {
    int status = qxas_apply(input, length, options, output, output_length, changed);
    if (status < 0) {
        int result_errno = errno;
        NSLog(@"QXAS compatibility transformation failed: %d", status);
        errno = result_errno;
    }
    return status;
}
