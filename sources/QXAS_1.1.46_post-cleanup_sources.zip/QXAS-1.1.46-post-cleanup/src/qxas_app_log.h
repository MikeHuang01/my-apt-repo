#import <Foundation/Foundation.h>

// The in-app Run Log is persisted by QXASStore, not by NSLog.
@interface QXASStore : NSObject
+ (instancetype)shared;
- (void)log:(NSString *)format, ...;
@end

static inline void QXASAppLog(NSString *message) {
    NSLog(@"%@", message);
    @try {
        [[QXASStore shared] log:@"%@", message];
    } @catch (NSException *exception) {
        NSLog(@"QXAS app log bridge failed: %@", exception);
    }
}
