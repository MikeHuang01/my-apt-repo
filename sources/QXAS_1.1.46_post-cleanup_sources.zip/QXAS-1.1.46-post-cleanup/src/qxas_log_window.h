#pragma once
#include <stddef.h>
#include <time.h>
#define QXAS_LOG_BYTES (256u * 1024u)
#define QXAS_LOG_AGE (3 * 60 * 60)
size_t qxas_log_window(char *data, size_t length, time_t now, size_t cap);
