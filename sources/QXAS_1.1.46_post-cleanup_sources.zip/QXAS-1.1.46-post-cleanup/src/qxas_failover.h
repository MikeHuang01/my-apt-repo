#pragma once
#include <stddef.h>
unsigned char *qxas_stable_failover(const unsigned char *data, size_t *length, size_t limit);
