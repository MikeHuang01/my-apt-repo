#define _GNU_SOURCE
#include "qxas_task_path.h"
#include "qxas_failover.h"
#ifdef QXAS_RUNTIME_TRACE
#include "qxas_runtime_trace.h"
#endif
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/xattr.h>
#include <stdint.h>
#include <unistd.h>

#define ENGINE_SCRIPT "qxas-controller.js"
#define MAX_SCRIPT (4 * 1024 * 1024)

static int directory(int parent, const char *name, int create) {
    if (create && mkdirat(parent, name, 0755) && errno != EEXIST) return -1;
    return openat(parent, name, O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
}

static int open_script(int dir, const char *name) {
    return openat(dir, name, O_RDONLY | O_NOFOLLOW | O_CLOEXEC | O_NONBLOCK);
}

static unsigned char *read_script(int fd, size_t *length, struct stat *st) {
    if (fstat(fd, st)) return NULL;
    if (!S_ISREG(st->st_mode) || st->st_size == 0) { errno = EINVAL; return NULL; }
    if (st->st_size < 0 || st->st_size > MAX_SCRIPT) { errno = EFBIG; return NULL; }
    *length = (size_t)st->st_size;
    unsigned char *data = malloc(*length);
    if (!data) return NULL;
    size_t n = 0;
    while (n < *length) {
        ssize_t got = read(fd, data + n, *length - n);
        if (got < 0 && errno == EINTR) continue;
        if (got == 0) errno = EIO;
        if (got <= 0) goto failed;
        n += (size_t)got;
    }
    unsigned char extra;
    ssize_t got;
    do { got = read(fd, &extra, 1); } while (got < 0 && errno == EINTR);
    if (got == 0) return data;
    if (got > 0) errno = EIO;
failed:;
    int saved_errno = errno;
    free(data);
    errno = saved_errno;
    return NULL;
}

// Only matching ownership stamps permit refreshing a nonidentical mirror.
#ifdef __APPLE__
#define OWNER_ATTRIBUTE "com.qxas.generated"
#define GET_OWNER(fd, value, size) fgetxattr(fd, OWNER_ATTRIBUTE, value, size, 0, 0)
#define SET_OWNER(fd, value, size) fsetxattr(fd, OWNER_ATTRIBUTE, value, size, 0, 0)
#else
#define OWNER_ATTRIBUTE "user.com.qxas.generated"
#define GET_OWNER(fd, value, size) fgetxattr(fd, OWNER_ATTRIBUTE, value, size)
#define SET_OWNER(fd, value, size) fsetxattr(fd, OWNER_ATTRIBUTE, value, size, 0)
#endif

static void ownership_stamp(const unsigned char *data, size_t length, char stamp[48]) {
    uint64_t checksum = UINT64_C(14695981039346656037);
    for (size_t i = 0; i < length; ++i) {
        checksum ^= data[i];
        checksum *= UINT64_C(1099511628211);
    }
    snprintf(stamp, 48, "QXAS1:%zu:%016llx", length, (unsigned long long)checksum);
}

static int managed_file(int fd, const unsigned char *data, size_t length) {
    char expected[48] = {0}, actual[48] = {0};
    ownership_stamp(data, length, expected);
    ssize_t n = GET_OWNER(fd, actual, sizeof actual);
    return n == (ssize_t)strlen(expected) && !memcmp(actual, expected, (size_t)n);
}

static int same_time(struct timespec a, struct timespec b) {
    return a.tv_sec == b.tv_sec && a.tv_nsec == b.tv_nsec;
}

static int same_file(const struct stat *a, const struct stat *b) {
    return a->st_dev == b->st_dev && a->st_ino == b->st_ino && a->st_size == b->st_size
#ifdef __APPLE__
        && same_time(a->st_mtimespec, b->st_mtimespec) && same_time(a->st_ctimespec, b->st_ctimespec);
#else
        && same_time(a->st_mtim, b->st_mtim) && same_time(a->st_ctim, b->st_ctim);
#endif
}

static int prepare_script(int mode, const char *home, const char *source,
                                        char *task_source, size_t task_source_size,
                                        const char **failed_step, int *error_number) {
    char expected[PATH_MAX], temp[96] = {0};
    const char *step = "validate arguments";
    if (failed_step) *failed_step = NULL;
    if (error_number) *error_number = 0;
    if (task_source && task_source_size) task_source[0] = '\0';
    int root = -1, library = -1, support = -1, state = -1, scripts = -1;
    int documents = -1, dest = -1, fd = -1, from = -1, existing = -1, verify = -1;
    int result = -1, saved_errno = 0;
    struct stat source_stat, existing_stat, current;
    unsigned char *data = NULL, *check = NULL;
    size_t length = 0, check_length = 0;
    if (!home || home[0] != '/' || !source || !task_source || task_source_size == 0) { errno = EINVAL; goto done; }
    step = "resolve app container path";
    char canonical_home[PATH_MAX];
    if (!realpath(home, canonical_home)) goto done;
    step = "validate generated source file";
    int len = snprintf(expected, sizeof expected, "%s/Library/Application Support/QXAS/Scripts/%s",
                       canonical_home, ENGINE_SCRIPT);
    if (len < 0 || (size_t)len >= sizeof expected) { errno = ENAMETOOLONG; goto done; }
    if (strcmp(source, expected)) { errno = EINVAL; goto done; }
    step = "open app container directories";
    root = open(canonical_home, O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
    if (root < 0) goto done;
    library = directory(root, "Library", 0);
    if (library < 0) goto done;
    support = directory(library, "Application Support", 0);
    if (support < 0) goto done;
    state = directory(support, "QXAS", 0);
    if (state < 0) goto done;
    scripts = directory(state, "Scripts", 0);
    if (scripts < 0) goto done;
    step = "read generated source script";
    from = open_script(scripts, ENGINE_SCRIPT);
    if (from < 0) goto done;
    data = read_script(from, &length, &source_stat);
    if (!data) goto done;
    if (mode == 2) {
        step = "prepare stable failover controller";
        unsigned char *script = qxas_stable_failover(data, &length, MAX_SCRIPT);
        if (!script) goto done;
        free(data);
        data = script;
    }
#ifdef QXAS_RUNTIME_TRACE
    if (mode == 1) {
        step = "instrument engine controller";
        unsigned char *traced = qxas_trace_script(data, &length, MAX_SCRIPT);
        if (!traced) goto done;
        free(data);
        data = traced;
    }
#endif
    step = "open Documents task destination";
    documents = directory(root, "Documents", 1);
    if (documents < 0) goto done;
    if (sizeof QXAS_TASK_SCRIPT > task_source_size) { errno = ENAMETOOLONG; goto done; }
    dest = directory(documents, "Scripts", 1);
    if (dest < 0) goto done;
    step = "inspect existing destination";
    existing = open_script(dest, QXAS_TASK_SCRIPT);
    if (existing >= 0) {
        check = read_script(existing, &check_length, &existing_stat);
        if (!check) goto done;
        if (fstatat(dest, QXAS_TASK_SCRIPT, &current, AT_SYMLINK_NOFOLLOW)) goto done;
        if (!same_file(&existing_stat, &current)) { errno = EAGAIN; goto done; }
        if (length == check_length && !memcmp(data, check, length)) {
            memcpy(task_source, QXAS_TASK_SCRIPT, sizeof QXAS_TASK_SCRIPT);
            result = QXAS_SCRIPT_MIRRORED;
            goto done;
        }
        if (!managed_file(existing, check, check_length)) { errno = EEXIST; goto done; }
        free(check); check = NULL;
    } else if (errno != ENOENT) goto done;
    step = "create temporary destination script";
    for (unsigned i = 0; i < 32; ++i) {
        snprintf(temp, sizeof temp, ".qxas-controller.%ld.%u.tmp", (long)getpid(), i);
        fd = openat(dest, temp, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC, 0600);
        if (fd >= 0) break;
        temp[0] = 0;
        if (errno != EEXIST) goto done;
    }
    if (fd < 0) goto done;
    step = "write and stamp temporary script";
    size_t written = 0;
    while (written < length) {
        ssize_t n = write(fd, data + written, length - written);
        if (n < 0 && errno == EINTR) continue;
        if (n == 0) errno = EIO;
        if (n <= 0) goto done;
        written += (size_t)n;
    }
    char stamp[48] = {0};
    ownership_stamp(data, length, stamp);
    if (SET_OWNER(fd, stamp, strlen(stamp))) goto done;
    if (fsync(fd)) goto done;
    if (close(fd)) { fd = -1; goto done; }
    fd = -1;
    if (existing < 0) {
        // Atomic no-clobber publish: never replace a file created after inspection.
        step = "publish new destination script";
        if (linkat(dest, temp, dest, QXAS_TASK_SCRIPT, 0)) goto done;
    } else {
        // A descriptor ties the stamp to the bytes we checked. Recheck the path
        // just before rename; POSIX rename itself does not compare the old inode.
        step = "recheck managed destination script";
        if (fstatat(dest, QXAS_TASK_SCRIPT, &current, AT_SYMLINK_NOFOLLOW)) goto done;
        if (!same_file(&existing_stat, &current)) { errno = EAGAIN; goto done; }
        step = "replace managed destination script";
        if (renameat(dest, temp, dest, QXAS_TASK_SCRIPT)) goto done;
        temp[0] = 0;
    }
    step = "verify published destination script";
    verify = open_script(dest, QXAS_TASK_SCRIPT);
    if (verify < 0) goto done;
    check = read_script(verify, &check_length, &current);
    if (!check) goto done;
    if (check_length != length || memcmp(check, data, length)) { errno = EIO; goto done; }
    memcpy(task_source, QXAS_TASK_SCRIPT, sizeof QXAS_TASK_SCRIPT);
    result = QXAS_SCRIPT_MIRRORED;
done:
    if (result != 0) {
        saved_errno = errno;
        if (failed_step) *failed_step = step;
        if (error_number) *error_number = saved_errno;
    }
    if (fd >= 0) close(fd);
    if (temp[0] && dest >= 0) unlinkat(dest, temp, 0);
    free(data); free(check);
    int fds[] = {verify, existing, from, dest, documents, scripts, state, support, library, root};
    for (unsigned i = 0; i < sizeof fds / sizeof *fds; ++i) if (fds[i] >= 0) close(fds[i]);
    if (result != 0) errno = saved_errno;
    return result;
}


#ifdef QXAS_RUNTIME_TRACE
int qxas_prepare_traced_script_with_error(const char *home, const char *source,
                                          char *task_source, size_t task_source_size,
                                          const char **failed_step, int *error_number) {
    return prepare_script(1, home, source, task_source, task_source_size, failed_step, error_number);
}
#endif

int qxas_prepare_local_script_with_error(const char *home, const char *source,
                                         char *task_source, size_t task_source_size,
                                         const char **failed_step, int *error_number) {
    return prepare_script(0, home, source, task_source, task_source_size, failed_step, error_number);
}

int qxas_prepare_stable_script_with_error(const char *home, const char *source,
                                         char *task_source, size_t task_source_size,
                                         const char **failed_step, int *error_number) {
    return prepare_script(2, home, source, task_source, task_source_size, failed_step, error_number);
}

int qxas_prepare_local_script(const char *home, const char *source,
                              char *task_source, size_t task_source_size) {
    return qxas_prepare_local_script_with_error(home, source, task_source, task_source_size, NULL, NULL);
}
