#pragma once
#include <stddef.h>
int qxas_has_single_task(const char *data, size_t length);
