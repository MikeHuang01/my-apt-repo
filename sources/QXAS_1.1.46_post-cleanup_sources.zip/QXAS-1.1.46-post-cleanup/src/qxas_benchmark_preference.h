#pragma once
#define QXASBenchmarkPreference @"QXASPeriodicBenchmarkEnabled"
