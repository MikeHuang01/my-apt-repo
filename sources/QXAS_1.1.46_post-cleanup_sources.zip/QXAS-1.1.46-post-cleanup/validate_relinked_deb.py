#!/usr/bin/env python3
"""Validate package contents and every Mach-O CodeDirectory code slot."""
import hashlib
import struct
import sys
from pathlib import Path
import build_candidate as base


def validate(package, baseline, expected_version='1.1.30'):
    ar = base.unpack_ar(package)
    old_ar = base.unpack_ar(baseline)
    rows = {base.name_of(m): (m, v) for m, v in base.tar_entries(ar['data.tar.gz'])}
    old = {base.name_of(m): (m, v) for m, v in base.tar_entries(old_ar['data.tar.gz'])}
    assert rows.keys() == old.keys(), 'payload entries changed'
    for name, (m, value) in rows.items():
        original, old_value = old[name]
        assert (m.mode, m.uid, m.gid, m.uname, m.gname, m.type) == (original.mode, original.uid, original.gid, original.uname, original.gname, original.type)
        if name != base.DYLIB:
            assert value == old_value, name
    control = base.tar_entries(ar['control.tar.gz'])
    assert [base.name_of(m) for m, v in control if m.isfile()] == ['control'], 'unexpected maintenance script'
    text = next(v for m, v in control if m.isfile()).decode()
    for field in ('Package: com.mikehuang01.qxas2', f'Version: {expected_version}', 'Architecture: iphoneos-arm64e', 'Depends: firmware (>= 15.0)'):
        assert field in text, field
    fat = rows[base.DYLIB][1]
    assert struct.unpack_from('>II', fat) == (0xcafebabe, 2)
    reports = []
    for i, arch in enumerate(('arm64', 'arm64e')):
        cpu, subtype, offset, size, align = struct.unpack_from('>IIIII', fat, 8 + 20*i)
        assert cpu == 0x100000c and (subtype & 0xffffff) == (0 if i == 0 else 2)
        image = fat[offset:offset+size]
        assert struct.unpack_from('<II', image, 4) == (cpu, subtype)
        sections, signature = base.read_macho(image)
        slots = base.code_slots(image, signature)
        for at, lo, hi in slots:
            assert image[at:at+32] == hashlib.sha256(image[lo:hi]).digest(), (arch, lo)
        assert b'@loader_path/.jbroot/Library/MobileSubstrate/DynamicLibraries/QXAS.dylib' in image
        assert b'qxas-controller.js' in image
        assert b'_qxas_local_task' in image and b'_qxas_prepare_local_script' in image
        assert b'com.qxas.generated' in image
        assert b'QXASAutomaticLifecycle' in image
        assert b'QXASWriteDiagnostics' in image
        assert f'QXAS diagnostic package loaded {expected_version}'.encode() in image
        if expected_version in ('1.1.35', '1.1.36', '1.1.37', '1.1.38', '1.1.39', '1.1.40', '1.1.41', '1.1.42', '1.1.43', '1.1.44', '1.1.45', '1.1.46'):
            lo, hi = sections[b'__ustring']
            version_count = 5 if expected_version in ('1.1.42', '1.1.43', '1.1.44', '1.1.45', '1.1.46') else 4
            assert image[lo:hi].count(expected_version.encode('utf-16le')) == version_count, 'UI/log version mismatch'
            if version_count == 5:
                assert image[lo:hi].count((('' if expected_version == '1.1.46' else '关于\n') + f'插件版本  {expected_version}').encode('utf-16le')) == 1
            assert '1.1.25'.encode('utf-16le') not in image[lo:hi], 'stale UI/log version'
            if expected_version not in ('1.1.45', '1.1.46'):
                assert b'QXAS script preparation succeeded; entering task core' in image
        if expected_version in ('1.1.36', '1.1.37'):
            assert b'QXAS mirror conflict: preserved existing' in image
        if expected_version == '1.1.38':
            assert b'QXAS task source normalized to Documents/QXAS-Scripts/' in image
            assert b'QXAS mirror conflict: preserved existing' not in image
        if expected_version in ('1.1.37', '1.1.38', '1.1.39', '1.1.40', '1.1.41', '1.1.42', '1.1.43', '1.1.44'):
            assert b'QXAS engine candidatePaths result class=' in image
            assert b'QXAS engine collectNodeTags result class=' in image
        if expected_version in ('1.1.42', '1.1.43', '1.1.44', '1.1.45', '1.1.46'):
            assert b'QXASLogRetention' in image and b'setTitleTextAttributesTransformer:' in image
        if expected_version in ('1.1.45', '1.1.46'):
            assert b'_qxas_has_single_task' in image
            for label in ('任务已写入配置。', '怎么用', '越狱源  https://mikehuang01.github.io/my-apt-repo/v3/'):
                assert label.encode('utf-16le') in image, label
        if expected_version == '1.1.46':
            for label in ('打开QX的VPN连接，然后在QX请求列表确认QXAS-Controller出现。没有出现就后台划掉QX重新打开再看一次。',
                          '智能优选规则', '作者  MikeHuang01', '越狱源  https://mikehuang01.github.io/my-apt-repo/v3/'):
                assert label.encode('utf-16le') in image, label
            assert '3. 列表没看到任务？'.encode('utf-16le') not in image
        if expected_version in ('1.1.44', '1.1.45', '1.1.46'):
            assert b'QXAS_STABLE_FAILOVER_1_1_44' in image
            assert b'_qxas_prepare_stable_script_with_error' in image
        if expected_version in ('1.1.43', '1.1.44', '1.1.45', '1.1.46'):
            for marker in (b'QXASPeriodicBenchmarkEnabled', b'qxas_benchmark_last',
                           b'_qxas_add_periodic_benchmark', b'qxas_benchmarkChanged:'):
                assert marker not in image, marker
        if expected_version == '1.1.42':
            assert b'QXASPeriodicBenchmarkEnabled' in image
            assert b'qxas_benchmark_last' in image and b'setTitleTextAttributesTransformer:' in image
        if expected_version in ('1.1.41', '1.1.42', '1.1.43', '1.1.44', '1.1.45', '1.1.46'):
            assert b'QXASCompactSettings' in image and b'QXASSmartOnly' in image
            assert b'QXASFooterTypography' in image
            assert b'QXAS-TRACE 1.1.40' not in image
            assert '请改用自动测速组模式'.encode('utf-16le') not in image
            assert b'qxas-task-probe.js' not in image
        if expected_version == '1.1.40':
            assert b'QXAS-TRACE 1.1.40 run=' in image
            assert b'_qxas_prepare_traced_script_with_error' in image
        if expected_version in ('1.1.39', '1.1.40', '1.1.41', '1.1.42', '1.1.43', '1.1.44', '1.1.45', '1.1.46'):
            if expected_version not in ('1.1.45', '1.1.46'):
                assert b'QXAS local task reference=%s (Documents/Scripts)' in image
            assert b'qxas-controller-managed.js' in image
            assert b'%s/Documents/QXAS-Scripts/%s' not in image
        assert b'QXASStore' in image
        assert b'qxas.log' in image, 'missing user-visible app log path'
        assert b'log:' in image
        assert b'QXAS engine backupData failed' in image
        assert b'QXAS engine writeConfData failed' in image
        verbose = (b'QXAS engine confPath observed', b'QXAS engine readConfData path=',
                   b'QXAS qxas_apply enter', b'QXAS qxas_apply exit',
                   b'QXAS task wrapper enter', b'QXAS task wrapper exit')
        assert all((marker in image) == (expected_version not in ('1.1.45', '1.1.46')) for marker in verbose)
        assert b'qxas_switchHook_mainSwitchChanged:' in image
        assert b'backupData:forPath:error:' in image
        assert b'writeConfData:toPath:error:' in image
        assert b'mainSwitchChanged:' in image
        assert b'QXAS main switch changed: %@' in image
        lo, hi = sections[b'__text']
        # PAC must be actual instructions in __text, not just an architecture label.
        if arch == 'arm64e':
            assert bytes.fromhex('7f2303d5') in image[lo:hi], 'missing pacibsp'
            assert bytes.fromhex('ff0f5fd6') in image[lo:hi], 'missing retab'
        reports.append(f'{arch}: {size} bytes, {len(slots)} code slots valid')
    print(text.strip())
    print('\n'.join(reports))
    print('Payload metadata preserved; no maintenance scripts; SHA256', hashlib.sha256(package).hexdigest())


if __name__ == '__main__':
    version = sys.argv[3] if len(sys.argv) > 3 else '1.1.30'
    validate(Path(sys.argv[1]).read_bytes(), Path(sys.argv[2]).read_bytes(), version)
