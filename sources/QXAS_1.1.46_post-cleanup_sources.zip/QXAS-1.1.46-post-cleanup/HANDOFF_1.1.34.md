# QXAS 1.1.34 Handoff（历史记录）

> **已由 [1.1.35 交接](HANDOFF_1.1.35.md) 更正并取代。** 本文把 `scriptsDirectoryWithError:` 的中间返回值误认作核心第三参数；核心实际接收引擎追加 `qxas-controller.js` 后的完整文件路径。1.1.34 会在本地准备阶段拒绝该真实入参，不再推荐安装验证。下文仅保留当时判断和构建记录。

## 1. Mission

继续处理 QXAS（`com.mikehuang01.qxas2`）主开关启用后出现“脚本模式失败：配置改写返回 -1”的问题。当前已构建 1.1.34 脚本任务目录修正/诊断测试包；最终目标是通过目标设备上一次真实开关操作产生的新日志，确认修复是否有效并区分剩余故障层。**本地通过不等于设备已修复。**

目标平台：Dopamine RootHide / ElleKit，iOS 15+；DEB 声明架构为 `iphoneos-arm64e`，payload 中的动态库含 arm64 和 arm64e 两个切片。

## 2. Status

### ✅ 已完成

- 反汇编已确认 `-[QXASEngine applyScriptMode:]` 调用 task core 时传入的第三参数是引擎生成的 scripts 目录 UTF-8 字符串，而非脚本文件 basename。
- 修改 `qxas_local_task`，调用前仍执行本地脚本准备，但将原始 `source` 目录透传给 `qxas_apply_task`。
- 修改路径辅助函数：要求规范化的 app-container 下 `Library/Application Support/QXAS/Scripts` 为 source；从该目录安全读取 `qxas-controller.js` 并准备 `Documents/Scripts` 目标脚本。拒绝符号链接和非本插件拥有的已存在文件；插件创建的目标文件通过 xattr ownership stamp 识别，避免覆盖用户编辑。
- 保持 switch hook 原回调恰好转发一次，不额外重复 apply/restore；日志加上 1.1.34 包标记。
- arm64、arm64e 原生构建成功；1.1.34 DEB 打包及校验通过；ZIP 内 DEB 已解压并比对 SHA-256。
- 本地测试通过：严格 C path 测试、switch hook / Engine / apply 诊断测试；DEB validator 验证每切片 62 个 code slots、包身份/架构/依赖、payload 元数据不变、无维护脚本。
- 已更新项目说明文件，并保留 1.1.33 及之前候选包历史记录。

### 产物

- 压缩包：`D:\文档\Deepseek\QX\analysis\QXAS-reverse\output\QXAS_1.1.34_taskdir_test.zip` — 186,629 bytes；SHA-256 `1b443f2ce90ea87cbfe80073efd7ec2a4bdb685b68f90e4309b53c5051a4a22d`。
- 原始 DEB：`D:\文档\Deepseek\QX\analysis\QXAS-reverse\output\QXAS_1.1.34_taskdir_iphoneos-arm64e.deb` — 187,154 bytes；SHA-256 `18600518dd038c81f5b91f87b606371d520be3093ab3b95b86e536d54ed31813`。
- 1.1.33 打包基线：`D:\文档\Deepseek\QX\analysis\QXAS-reverse\output\QXAS_1.1.33_app-log_iphoneos-arm64e.deb`；SHA-256 `35b58c12b7a9812e6cfbfd4be937833d3fb895a9baf2a5cb1f8fa8d324057d78`。

### 进行中 / 当前阻塞点

- **设备侧验证待完成**：没有新证据确认 1.1.34 已安装或已触发开关。旧设备截图/日志仍是 1.1.25，不能用于验证新包。
- Node.js 在 Windows 宿主和 WSL 中都不可用，故 `tests/controller.test.js` 没有运行；其余本次相关 C/Python 测试运行通过。
- arm64e 链接器报告旧保留对象 ABI 不兼容警告；构建使用既定 `-allow_sub_type_mismatches`，结构/签名检查不能替代设备运行验证。

### 下一步第一件事

请用户在目标设备覆盖安装 1.1.34，清除 QXAS 应用内旧日志，**只切换主开关一次**，再提供同一次操作的新日志。先确认日志出现 `QXAS diagnostic package loaded 1.1.34`，然后检查 task wrapper、脚本准备、core transformation、Engine 返回/Error。未取得这组日志前不要宣称已修复，也不要建议继续改 core。

建议查看顺序：
1. 有无 1.1.34 marker，确认实际加载的是新包。
2. `QXAS task wrapper enter` 的 config/source/output 槽和值；确认是否出现 `QXAS script preparation failed at ...`。
3. `QXAS task config transformation failed (status ...)` 与 wrapper exit。
4. 同次操作的 Engine `readConfData` / `applyScriptMode` / NSError / apply 结果。
5. 若 core 仍为 -1 且 config/output 非空，再核对加载 dylib 版本、symbol rebinding 与 ABI；本地静态结论提示这些条件与 core 的已知 -1 guard 不一致，但要以设备日志和实际二进制为准。

## 3. Decisions

- **契约按 Engine 调用点修正，而非继续传 basename。**已恢复/检查的 Engine task 调用点将 scriptsDirectory 字符串作为第三参数传入。之前 wrapper 将 `qxas-controller.js` 固定传给 core、helper 又期待完整文件路径，与 Engine 实际 source-directory contract 不一致。
- **保留原行为边界。**switch hook 只转发原 handler 一次；路径准备失败即返回，不自行触发重复 apply/restore。原 Engine 仍负责其备份与配置写入闸门。
- **保守处理既有目标文件。**仅可替换带有当前生成内容 ownership stamp 的目标文件；不同内容的用户文件、软链接等拒绝覆盖。
- **增量升级包。**1.1.34 从 SHA-256 锁定的 1.1.33 DEB 升级，只改动态库及 control 版本；保留 payload 元数据，禁止覆盖已有输出，不增维护脚本。
- **不把本地静态检查当设备结果。**发行候选可供测试，但没有设备新日志就不认定修复。

## 4. Context：环境、关键路径及源码

### 环境 / 构建依赖

- Windows 工作目录：`D:\文档\Deepseek\QX`。
- WSL 工作目录映射：`/mnt/d/文档/Deepseek/QX`。
- `build_native.sh` 依赖以下外部保留对象和工具链：`/mnt/e/QXAS-recovery-2026-11-25/qxas-build/obj`；Theos clang/linker/ldid/lipo 位于 `/home/codexbuild/theos/toolchain/linux/iphone/bin`；SDK 位于 `/home/codexbuild/theos/sdks/iPhoneOS16.5.sdk`。
- 原生构建输出临时目录是每次运行动态创建的 `/tmp/qxas-native.*`。上次路径是 `/tmp/qxas-native.XYlVoM`，新会话应重新运行构建并使用当次 `BUILD_DIR=...`，不要假设该临时目录仍存在。
- 构建目标：arm64 + arm64e，minimum iOS 15.0；保留对象为旧 ABI，arm64e 链接会出现兼容警告。

### 关键文件（绝对路径）

| 作用 | 路径 |
|---|---|
| wrapper/task core 入口 | `D:\文档\Deepseek\QX\analysis\QXAS-reverse\src\qxas_local_task.m` |
| 本地源脚本/目标脚本安全准备 | `D:\文档\Deepseek\QX\analysis\QXAS-reverse\src\qxas_task_path.c` |
| source contract 声明 | `D:\文档\Deepseek\QX\analysis\QXAS-reverse\src\qxas_task_path.h` |
| switch hook 和版本 marker | `D:\文档\Deepseek\QX\analysis\QXAS-reverse\src\qxas_switch_hook.m` |
| Engine 诊断 hook | `D:\文档\Deepseek\QX\analysis\QXAS-reverse\src\qxas_engine_diagnostics.m` |
| core apply 透明诊断 hook | `D:\文档\Deepseek\QX\analysis\QXAS-reverse\src\qxas_apply_diagnostics.m` |
| 原生双架构构建 | `D:\文档\Deepseek\QX\analysis\QXAS-reverse\build_native.sh` |
| 1.1.34 DEB 构建器 | `D:\文档\Deepseek\QX\analysis\QXAS-reverse\build_taskdir_deb.py` |
| 包结构 / CodeDirectory 校验 | `D:\文档\Deepseek\QX\analysis\QXAS-reverse\validate_relinked_deb.py` |
| C task path 回归 | `D:\文档\Deepseek\QX\analysis\QXAS-reverse\tests\test_task_path.c` |
| task/apply 参数诊断回归 | `D:\文档\Deepseek\QX\analysis\QXAS-reverse\tests\test_qxas_apply_diagnostics.py` |
| 当前构建/测试说明 | `D:\文档\Deepseek\QX\analysis\QXAS-reverse\README.md` |

### 关键源码片段

`src/qxas_local_task.m`：准备步骤接收 Engine 原始 source，并将其原样传给 core：

```objc
if (qxas_prepare_local_script_with_error([NSHomeDirectory() fileSystemRepresentation], source,
                                         &failed_step, &error_number)) {
    /* 记录阶段和 errno，然后返回 -1 */
    return -1;
}
// Engine 提供 scriptsDirectoryWithError: 的 UTF-8 路径；core 参数是目录，不是 basename。
int result = qxas_apply_task(config, length, source, output, output_length, changed);
```

`src/qxas_task_path.c`：先规范化容器根目录，再强制 source 等于预期生成脚本目录：

```c
if (!realpath(home, canonical_home)) goto done;
int len = snprintf(expected, sizeof expected,
    "%s/Library/Application Support/QXAS/Scripts", canonical_home);
if (len < 0 || (size_t)len >= sizeof expected || strcmp(source, expected)) {
    errno = EINVAL;
    goto done;
}
```

其后从已打开的 source directory 使用 `openat(..., O_NOFOLLOW)` 读取 `qxas-controller.js`，并安全创建/更新 `Documents/Scripts/qxas-controller.js`。

`src/qxas_switch_hook.m`：记录开关状态并将原 handler 精确转发一次，未在 hook 中二次 apply/restore：

```objc
BOOL enabled = sender.isOn;
((void (*)(id, SEL, id))objc_msgSend)(self,
    @selector(qxas_switchHook_mainSwitchChanged:), sender);
QXASAppLog([NSString stringWithFormat:
    @"QXAS diagnostic package loaded 1.1.34; QXAS main switch changed: %@",
    enabled ? @"on" : @"off"]);
```

以上是关键片段，完整源码以表内绝对路径文件为准。

### 复现构建 / 验证命令

在 WSL 中：

```bash
cd /mnt/d/文档/Deepseek/QX/analysis/QXAS-reverse
bash build_native.sh
# 记下构建打印的 BUILD_DIR=/tmp/qxas-native.XXXXXX，然后将该路径替换到下一命令
python3 build_taskdir_deb.py \
  output/QXAS_1.1.33_app-log_iphoneos-arm64e.deb \
  /tmp/qxas-native.XXXXXX/QXAS.dylib \
  output/QXAS_1.1.34_taskdir_iphoneos-arm64e.deb
python3 validate_relinked_deb.py \
  output/QXAS_1.1.34_taskdir_iphoneos-arm64e.deb \
  output/QXAS_1.1.33_app-log_iphoneos-arm64e.deb 1.1.34
cc -std=c11 -Wall -Wextra -Werror \
  src/qxas_task_path.c tests/test_task_path.c -o /tmp/qxas-task-path-test
/tmp/qxas-task-path-test
python3 tests/test_switch_hook.py
python3 tests/test_engine_diagnostics.py
python3 tests/test_qxas_apply_diagnostics.py
```

本次实际结果：C task path、3 个 Python 集成测试、双架构构建、1.1.34 DEB 验证通过；controller JS 测试未运行（缺 Node.js）。重新执行会创建不同的 `/tmp/qxas-native.*` 路径。不要重用已存在的 DEB 输出路径，因为构建器采用独占创建以避免覆盖。

## 5. Risks / Unknowns

- **最重要未知：设备是否加载并运行 1.1.34，以及开关是否实际恢复正常。**尚无 1.1.34 同操作日志，不能断言修复成功。
- 反汇编和 source-contract 判断是定位依据；最终仍需设备日志确认调用参数、加载版本、hook/rebinding 与 Engine 结果。
- arm64e 文件存在基于旧对象的 ABI 兼容警告。构建器实际签名、校验双 slice 的 code slots/PAC 标记，但不证明 iOS / RootHide 运行时加载和功能兼容。
- controller JavaScript regression 未运行，Node.js 缺失；之后若获得可信、隔离的 Node 环境，再执行 `tests/controller.test.js`。这组测试仍只是本地模板测试，不代表设备内置脚本的设备行为。
- 历史 1.1.25 日志不能作为 1.1.34 证据；勿把既往截图/日志与新包装载状态混为一谈。
- 1.1.34 DEB 从已核验的 1.1.33 基线生成，包内 payload 元数据保留，但设备安装和覆盖升级本身尚未验证。
