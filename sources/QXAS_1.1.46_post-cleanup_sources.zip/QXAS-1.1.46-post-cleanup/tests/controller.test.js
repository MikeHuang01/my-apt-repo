'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const templateSource = fs.readFileSync(path.join(__dirname, '../src/qxas-controller.js'), 'utf8');
function makeTemplate(candidates) {
  return templateSource.replace('__TAGS__', JSON.stringify(candidates)).replace('__NOTIFY__', 'true');
}
async function execute({current='Current JP',currentHealthy=true,benchmark={},prefs={},now=1000000,candidates=['🇯🇵 JP-A','🇯🇵 JP-B','US-A']}={}) {
  const calls=[],notifications=[],prefWrites=[]; let selected=current;
  const config={sendMessage(message){calls.push(message);switch(message.action){
    case 'get_policy_state':return Promise.resolve({ret:{proxy:[selected]}});
    case 'url_latency_benchmark':{const data=message.content.length===1&&message.content[0]===current&&currentHealthy?{[current]:[20]}:benchmark;return Promise.resolve({ret:data});}
    case 'set_policy_state':selected=message.content.proxy;return Promise.resolve({ret:true});
    default:return Promise.reject(new Error('unexpected '+message.action));
  }}};
  const context={Promise,Math,Number,String,Date:{now:()=>now},isFinite,Error,$configuration:config,
    $prefs:{valueForKey:k=>prefs[k],setValueForKey:(v,k)=>prefWrites.push([k,v])},
    $notify:(title,text)=>notifications.push([title,text]),$done:()=>{},setTimeout:()=>1,clearTimeout:()=>{}};
  vm.runInNewContext(makeTemplate(candidates),context);
  for(let i=0;i<30;i++){await Promise.resolve();await new Promise(resolve=>setImmediate(resolve));}
  return {calls,notifications,prefWrites,selected};
}
(async()=>{
  const healthy=await execute();assert.equal(healthy.selected,'Current JP');assert.equal(healthy.calls.filter(x=>x.action==='url_latency_benchmark').length,1);assert.equal(healthy.prefWrites[0][0],'qxas_informed');
  const failed=await execute({currentHealthy:false,benchmark:{'🇯🇵 JP-A':[80,100],'🇯🇵 JP-B':[20,30],'US-A':[1,2]}});assert.equal(failed.selected,'🇯🇵 JP-B');assert.equal(failed.calls.filter(x=>x.action==='url_latency_benchmark').length,3);assert.ok(failed.notifications.some(x=>x[1].includes('同地区优先')));
  const fallback=await execute({currentHealthy:false,current:'Unknown',benchmark:{'🇯🇵 JP-A':[80],'US-A':[10]}});assert.equal(fallback.selected,'US-A');
  const cooldown=await execute({currentHealthy:false,prefs:{qxas_last_switch:'950000'},benchmark:{'🇯🇵 JP-A':[10]}});assert.equal(cooldown.selected,'Current JP');assert.equal(cooldown.calls.filter(x=>x.action==='set_policy_state').length,0);
  const noCandidates=await execute({currentHealthy:false,candidates:[]});assert.equal(noCandidates.selected,'Current JP');assert.ok(noCandidates.notifications.some(x=>x[1].includes('候选节点')));
  const noHealthy=await execute({currentHealthy:false,benchmark:{'🇯🇵 JP-A':[-1]}});assert.equal(noHealthy.selected,'Current JP');assert.ok(noHealthy.notifications.some(x=>x[1].includes('未测得有效延迟')));
  const noProxy=await execute({current:null});assert.ok(noProxy.notifications.some(x=>x[1].includes('没有可用策略节点')));
  console.log('controller tests: 7 scenarios passed');
})().catch(e=>{console.error(e);process.exitCode=1;});
