#define _POSIX_C_SOURCE 200809L
#include "../src/qxas_log_window.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void check(const char *input, const char *expected, time_t now, size_t cap) {
    char buffer[1024];
    size_t len = strlen(input);
    assert(len < sizeof buffer);
    memcpy(buffer,input,len);
    size_t n = qxas_log_window(buffer,len,now,cap);
    assert(n == strlen(expected) && !memcmp(buffer,expected,n));
}

int main(void) {
    assert(setenv("TZ", "UTC0", 1) == 0);
    tzset();
    struct tm t = {.tm_year=127,.tm_mon=0,.tm_mday=1,.tm_hour=1,.tm_isdst=-1};
    time_t now=mktime(&t);
    const char *input="orphan\n[12-31 21:59:59] expired\ncontinuation\n[12-31 22:00:00] boundary\n保留\n[01-01 00:59:00] recent\n continuation\n";
    const char *latest="[01-01 00:59:00] recent\n continuation\n";
    check(input, strstr(input,"[12-31 22:00:00]"),now,1024);
    check(input, latest,now,strlen(latest));
    check(input, latest,now,strlen(latest)+6);
    check(input,"",now,strlen(latest)-1);
    check("[2025-01-01 00:59:00] old\n[2027-01-01 01:00:00] fresh\n", "[2027-01-01 01:00:00] fresh\n",now,1024);
    check("[01-01 01:06:00] future\n","",now,1024);
    check("[01-01 01:00:00] no newline","[01-01 01:00:00] no newline",now,1024);
    puts("log window tests passed");
}
