#include "../src/qxas_task_check.h"
#include <assert.h>
#include <string.h>
#include <stdio.h>
#define SECTION "[task_local]\n"
#define TASK "* * * * * qxas-controller-managed.js, tag=QXAS-Controller, enabled=true"
static int has(const char *s) { return qxas_has_single_task(s, strlen(s)); }
int main(void) {
    assert(has(SECTION TASK));
    assert(has("\xef\xbb\xbf[task_local]\r\n \t" TASK " \r\n[general]\r\n"));
    assert(has(SECTION ";" TASK "\n#" TASK "\n" TASK "\n* * * * * other.js, tag=Other, enabled=true\n"));
    assert(!has("[general]\n" TASK));
    assert(!has(SECTION "#" TASK));
    assert(!has(SECTION TASK "\n" TASK));
    assert(!has(SECTION TASK "\n[general]\n" SECTION TASK));
    assert(!has(SECTION "* * * * * qxas-controller-managed.js, tag=QXAS-Controller, enabled=false"));
    assert(!has(SECTION "* * * * * /old/script.js, tag=QXAS-Controller, enabled=true"));
    assert(!qxas_has_single_task(SECTION TASK "\0extra", sizeof(SECTION TASK "\0extra") - 1));
    assert(!qxas_has_single_task(NULL, 0));
    puts("task entry checks passed");
}
