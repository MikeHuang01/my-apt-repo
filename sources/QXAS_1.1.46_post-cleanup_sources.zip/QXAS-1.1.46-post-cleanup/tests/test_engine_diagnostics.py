#!/usr/bin/env python3
from pathlib import Path
root = Path(__file__).resolve().parents[1]
hook = (root / 'src/qxas_engine_diagnostics.m').read_text()
for sel in ('backupData:forPath:error:', 'writeConfData:toPath:error:', 'applyNow:', 'applyScriptMode:', 'restoreNow:'):
    assert f'@selector({sel})' in hook
assert 'return [self applyScriptMode:error];' in hook
assert hook.count('[self qxas_diag_applyScriptMode:error]') == 1
assert hook.count('[self qxas_diag_restoreNow:error]') == 1
assert '任务已写入配置。' in hook and '请求列表' in hook
assert 'confPath observed' not in hook and 'collectNodeTags result' not in hook
print('engine lifecycle checks passed')
