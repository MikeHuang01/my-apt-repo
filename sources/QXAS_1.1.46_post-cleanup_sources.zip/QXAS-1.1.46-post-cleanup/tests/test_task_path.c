#define _GNU_SOURCE
#include "../src/qxas_task_path.h"
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

static void put(const char *path, const char *value) {
    int fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0600);
    assert(fd >= 0);
    size_t n = strlen(value), at = 0;
    while (at < n) { ssize_t w = write(fd, value + at, n - at); assert(w > 0); at += (size_t)w; }
    assert(close(fd) == 0);
}

#ifdef QXAS_TEST_WRAP_FSYNC
static const char *race_path;
int __real_fsync(int fd);
int __wrap_fsync(int fd) {
    if (race_path) {
        put(race_path, "user edit during copy\n");
        race_path = NULL;
    }
    return __real_fsync(fd);
}
#endif

static void read_equals(const char *path, const char *want) {
    char buf[128] = {0};
    int fd = open(path, O_RDONLY);
    assert(fd >= 0);
    ssize_t n = read(fd, buf, sizeof buf - 1);
    assert(n == (ssize_t)strlen(want));
    assert(memcmp(buf, want, (size_t)n) == 0);
    close(fd);
}

static void prepare_ok(const char *home, const char *source, char *task_source, size_t size) {
    assert(qxas_prepare_local_script(home, source, task_source, size) == QXAS_SCRIPT_MIRRORED);
    assert(strcmp(task_source, "qxas-controller-managed.js") == 0);
    char line[256];
    assert(snprintf(line, sizeof line, "* * * * * %s, tag=QXAS-Controller, enabled=true", task_source) > 0);
    assert(strcmp(line, "* * * * * qxas-controller-managed.js, tag=QXAS-Controller, enabled=true") == 0);
}

int main(void) {
    char home[] = "/tmp/qxas-home.XXXXXX";
    assert(mkdtemp(home));
    char state[1024], source[1200], docs[1024], legacy_dir[1200], legacy[1600];
    char dest[1600], target[1200], task_source[1400], command[4096];
    snprintf(state, sizeof state, "%s/Library/Application Support/QXAS/Scripts", home);
    snprintf(source, sizeof source, "%s/qxas-controller.js", state);
    snprintf(docs, sizeof docs, "%s/Documents", home);
    snprintf(legacy_dir, sizeof legacy_dir, "%s/Scripts", docs);
    snprintf(legacy, sizeof legacy, "%s/qxas-controller.js", legacy_dir);
    snprintf(dest, sizeof dest, "%s/qxas-controller-managed.js", legacy_dir);
    snprintf(target, sizeof target, "%s/user-target.js", home);
    snprintf(command, sizeof command, "mkdir -p '%s' '%s'", state, legacy_dir);
    assert(system(command) == 0);
    put(source, "generated controller\n");
    put(legacy, "legacy user mirror\n");
    char too_small[8];
    const char *failed_step = NULL;
    int error_number = 0;
    assert(qxas_prepare_local_script_with_error(home, source, too_small, sizeof too_small,
                                                &failed_step, &error_number) == QXAS_SCRIPT_ERROR);
    assert(!strcmp(failed_step, "open Documents task destination"));
    assert(error_number == ENAMETOOLONG && errno == ENAMETOOLONG);
    assert(too_small[0] == 0 && access(dest, F_OK) == -1 && errno == ENOENT);

    prepare_ok(home, source, task_source, sizeof task_source);
    read_equals(dest, "generated controller\n");
    read_equals(legacy, "legacy user mirror\n");
    prepare_ok(home, source, task_source, sizeof task_source);
    put(source, "updated controller\n");
    prepare_ok(home, source, task_source, sizeof task_source);
    read_equals(dest, "updated controller\n");
    read_equals(legacy, "legacy user mirror\n");

    char alias[] = "/tmp/qxas-home-link.XXXXXX";
    int alias_fd = mkstemp(alias);
    assert(alias_fd >= 0 && close(alias_fd) == 0 && unlink(alias) == 0);
    assert(symlink(home, alias) == 0);
    prepare_ok(alias, source, task_source, sizeof task_source);
    assert(unlink(alias) == 0);

    put(dest, "user-owned task file\n");
    assert(qxas_prepare_local_script_with_error(home, source, task_source, sizeof task_source,
                                                &failed_step, &error_number) == QXAS_SCRIPT_ERROR);
    assert(!strcmp(failed_step, "inspect existing destination"));
    assert(error_number == EEXIST && errno == EEXIST);
    read_equals(dest, "user-owned task file\n");
    read_equals(legacy, "legacy user mirror\n");
    assert(unlink(dest) == 0);

    assert(qxas_prepare_local_script_with_error(home, state, task_source, sizeof task_source,
                                                &failed_step, &error_number) == QXAS_SCRIPT_ERROR);
    assert(!strcmp(failed_step, "validate generated source file"));
    assert(error_number == EINVAL);
    assert(qxas_prepare_local_script(home, "qxas-controller.js", task_source, sizeof task_source) == QXAS_SCRIPT_ERROR);
    assert(qxas_prepare_local_script(home, "/tmp/not-the-controller.js", task_source, sizeof task_source) == QXAS_SCRIPT_ERROR);

    put(source, "");
    assert(qxas_prepare_local_script_with_error(home, source, task_source, sizeof task_source,
                                                &failed_step, &error_number) == QXAS_SCRIPT_ERROR);
    assert(!strcmp(failed_step, "read generated source script") && error_number == EINVAL);
    assert(truncate(source, 4 * 1024 * 1024 + 1) == 0);
    assert(qxas_prepare_local_script_with_error(home, source, task_source, sizeof task_source,
                                                &failed_step, &error_number) == QXAS_SCRIPT_ERROR);
    assert(error_number == EFBIG);
    put(source, "source restored\n");

#ifdef QXAS_TEST_WRAP_FSYNC
    race_path = dest;
    assert(qxas_prepare_local_script_with_error(home, source, task_source, sizeof task_source,
                                                &failed_step, &error_number) == QXAS_SCRIPT_ERROR);
    assert(!race_path && error_number == EEXIST && errno == EEXIST);
    assert(!strcmp(failed_step, "publish new destination script"));
    read_equals(dest, "user edit during copy\n");
    assert(unlink(dest) == 0);
    prepare_ok(home, source, task_source, sizeof task_source);
    put(source, "next generated version\n");
    race_path = dest;
    assert(qxas_prepare_local_script_with_error(home, source, task_source, sizeof task_source,
                                                &failed_step, &error_number) == QXAS_SCRIPT_ERROR);
    assert(!race_path && error_number == EAGAIN && errno == EAGAIN);
    assert(!strcmp(failed_step, "recheck managed destination script"));
    read_equals(dest, "user edit during copy\n");
    assert(unlink(dest) == 0);
#endif

    put(target, "symlink target\n");
    assert(symlink(target, dest) == 0);
    assert(qxas_prepare_local_script(home, source, task_source, sizeof task_source) == QXAS_SCRIPT_ERROR);
    read_equals(target, "symlink target\n");
    assert(unlink(dest) == 0);
    assert(unlink(source) == 0);
    assert(qxas_prepare_local_script(home, source, task_source, sizeof task_source) == QXAS_SCRIPT_ERROR);
    assert(symlink(target, source) == 0);
    assert(qxas_prepare_local_script(home, source, task_source, sizeof task_source) == QXAS_SCRIPT_ERROR);
    read_equals(target, "symlink target\n");

    assert(unlink(source) == 0);
    assert(unlink(target) == 0);
    assert(unlink(legacy) == 0);
    assert(rmdir(legacy_dir) == 0);
    assert(rmdir(docs) == 0);
    assert(rmdir(state) == 0);
    snprintf(command, sizeof command, "%s/Library/Application Support/QXAS", home);
    assert(rmdir(command) == 0);
    snprintf(command, sizeof command, "%s/Library/Application Support", home);
    assert(rmdir(command) == 0);
    snprintf(command, sizeof command, "%s/Library", home);
    assert(rmdir(command) == 0);
    assert(rmdir(home) == 0);
    puts("task path tests passed");
    return 0;
}
