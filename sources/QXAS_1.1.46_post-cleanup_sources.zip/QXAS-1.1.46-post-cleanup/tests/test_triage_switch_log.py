#!/usr/bin/env python3
"""Synthetic log fixtures; these results are not device evidence."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from triage_switch_log import classify

on = 'QXAS diagnostic package loaded 1.1.35; QXAS main switch changed: on'
off = on[:-2] + 'off'
enter = 'QXAS task wrapper enter config=[non-null] length=100 source=[redacted]'
ready = 'QXAS script preparation succeeded; entering task core'
exit_ok = 'QXAS task wrapper exit status=0 errno=0'
end_ok = 'QXAS engine applyScriptMode returned=1 errorDomain=(none)'
end_err = 'QXAS engine applyScriptMode returned=0 errorDomain=QXAS'


def check(expected, *lines):
    result, locations = classify('\n'.join(lines), '1.1.35')
    assert result == expected, (result, expected)
    assert locations == sorted(set(locations))
    return locations


check('no_switch_marker', '1.1.25 设置入口已点击', end_ok)
check('wrong_version', on.replace('1.1.35', '1.1.34'), end_ok)
check('last_switch_is_off', on, enter, ready, exit_ok, end_ok, off)
assert check('insufficient', on, enter, ready, exit_ok, end_ok, on, enter) == [6, 7]
check('engine_failed_before_wrapper_or_log_missing', on, end_err)
check('insufficient', on, end_ok)
check('prepare_failed', on, enter, 'QXAS script preparation failed at read generated source script (errno 2)',
      'QXAS task wrapper exit status=-1 errno=2 stage=script-preparation', end_err)
check('core_failed', on, enter, ready, 'QXAS task config transformation failed (status -2)',
      'QXAS task wrapper exit status=-2 errno=0', end_err)
check('wrapper_guard_failed_or_log_missing', on, enter, 'QXAS task wrapper exit status=-1 errno=0', end_err)
check('backup_error', on, enter, ready, exit_ok, 'QXAS engine backupData failed path=[redacted]', end_err)
check('write_error', on, enter, ready, exit_ok, 'QXAS engine writeConfData failed path=[redacted]', end_err)
check('engine_failed_after_core', on, enter, ready, exit_ok, end_err)
check('ambiguous', on, enter, ready, exit_ok, end_ok, end_ok)
check('ambiguous', on, enter, ready, exit_ok, 'QXAS engine writeConfData failed path=[redacted]', end_ok)
check('engine_returned_success_task_unverified', on, enter, ready, exit_ok, end_ok)
from triage_switch_log import MIRROR
on36 = on.replace('1.1.35', '1.1.36')
on37 = on.replace('1.1.35', '1.1.37')
for expect, lines in (
    ('engine_returned_success_task_unverified', (enter, MIRROR, ready, exit_ok, end_ok)),
    ('engine_returned_success_task_unverified', (enter, ready, exit_ok, end_ok)),
    ('insufficient', (enter, MIRROR)),
    ('insufficient', (enter, MIRROR, end_ok)),
    ('ambiguous', (enter, ready, MIRROR, exit_ok, end_ok)),
    ('core_failed', (enter, MIRROR, ready, 'QXAS task config transformation failed (status -2)',
                     'QXAS task wrapper exit status=-2', end_err)),
):
    text = '\n'.join((on36, *lines))
    assert classify(text, '1.1.36') == (expect, list(range(1, len(lines) + 2)))
for expect, lines in (
    ('engine_returned_success_no_candidates_task_unverified', (enter, MIRROR, ready, exit_ok,
                     '已启用智能切节点：候选 0 个', end_ok)),
    ('ambiguous', (enter, MIRROR, ready, exit_ok, '已启用智能切节点：候选 0 个', end_err)),
):
    text = '\n'.join((on36, *lines))
    assert classify(text, '1.1.36') == (expect, list(range(1, len(lines) + 2)))
for counts, verdict in (((0, 0), 'candidate_path_list_empty'), ((4, 0), 'candidate_tag_extraction_empty'), ((4, 2), 'candidates_collected_task_unverified')):
    summary = (
        f'QXAS engine candidatePaths result class=__NSArrayI count={counts[0]}',
        f'QXAS engine collectNodeTags result class=__NSArrayI count={counts[1]}',
        exit_ok, end_ok)
    text = '\n'.join((on37, enter, *summary))
    assert classify(text, '1.1.37') == (verdict, list(range(1, len(summary) + 3)))
assert classify('\n'.join((on36, enter, MIRROR, ready, exit_ok, end_ok)), '1.1.37')[0] == 'wrong_version'
print('switch log triage tests: 26 synthetic scenarios passed')
