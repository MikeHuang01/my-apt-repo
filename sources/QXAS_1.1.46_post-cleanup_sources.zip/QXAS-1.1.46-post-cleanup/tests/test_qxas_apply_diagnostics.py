#!/usr/bin/env python3
from pathlib import Path
root = Path(__file__).resolve().parents[1]
apply_hook = (root / 'src/qxas_apply_diagnostics.m').read_text()
task_hook = (root / 'src/qxas_local_task.m').read_text()
assert apply_hook.count('qxas_apply(input, length, options, output, output_length, changed)') == 1
assert 'QXASAppLog(' not in apply_hook
assert 'qxas_prepare_stable_script_with_error(' in task_hook
call = 'qxas_apply_task(config, length, task_source, output, actual_length, changed)'
assert task_hook.count(call) == 1
assert task_hook.index(call) < task_hook.index('qxas_has_single_task(*output, *actual_length)')
assert 'free(*output);' in task_hook
assert 'task wrapper enter' not in task_hook and 'task wrapper exit' not in task_hook
print('task write gate integration checks passed')
