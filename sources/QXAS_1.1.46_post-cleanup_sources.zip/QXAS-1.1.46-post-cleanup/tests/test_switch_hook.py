#!/usr/bin/env python3
"""Guard the automatic switch lifecycle hook's source and link integration."""
from pathlib import Path

root = Path(__file__).resolve().parents[1]
hook = (root / 'src/qxas_switch_hook.m').read_text()
build = (root / 'build_native.sh').read_text()
assert 'method_exchangeImplementations(original, hook)' in hook
assert 'BOOL enabled = sender.isOn;' in hook
assert 'qxas_switchHook_mainSwitchChanged:), sender);' in hook
assert 'QXAS main switch changed: %@' in hook
assert hook.index('NSLog(') < hook.index('objc_msgSend')
assert 'QXASAppLog(' not in hook
assert '@selector(doApply)' not in hook and '@selector(doRestore)' not in hook
assert hook.count('objc_msgSend') == 1 and 'dispatch_async' not in hook
assert 'switch.$arch.o' in build
assert 'qxas_switch_hook.m' in build
print('switch hook integration tests passed')
