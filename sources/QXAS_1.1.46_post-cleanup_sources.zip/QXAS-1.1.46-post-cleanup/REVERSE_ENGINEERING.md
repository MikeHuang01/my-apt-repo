# QXAS 1.1.24 二进制逆向清单

源包：QXAS_1.1.24_iphoneos-arm64e.deb；SHA-256 `15d3ac1988a69b9158c2f7f605bb683be87cb6826b895b5b21a157f59f43dbdc`。本次输入是用户提供的本地文件。

## 可证实的模块

- `QXASEngine`：配置探测/选择/读取，节点标签收集，配置应用/还原，URL 同步拉取，备份、配置写入，脚本路径检查及脚本模式。编译目标符号明确保留 `backupData:forPath:error:`、`writeConfData:toPath:error:`、`applyNow:`、`restoreNow:`、`scriptsDirectoryWithError:`。
- `QXASStore`：状态目录、`settings.json`、`qxas.log`；对象元数据保留开关、间隔、延迟容差、通知、策略名、控制脚本路径等字段。
- `QXASMain`：原生设置页入口 `QXASEntry.install`、`qxas_openPanel:` 与 collection/layout/footer hook 的实现符号。
- `QXASUI`：设置页、日志控制器、面板容器、导航转场和设置操作方法。
- `QXASEngine.o` 的 UTF-16 常量区已按地址顺序恢复为 `src/qxas-controller.js`（96 行脚本文本，含区域名、通知文案和模板标记）；当前工作副本额外补充了无节点、无候选、无健康节点的可读通知，故与原二进制不再逐字节等价。

## 不能无损还原的部分

- C/Objective-C 函数体在 Mach-O 机器码中；目标文件无源码行号或 DWARF 调试信息。类名/选择子不等于源实现。
- 控制器脚本文本可从 UTF-16 常量区按偏移顺序恢复；字符串区本身保留完整可读逻辑。Objective-C 包装/插值代码、其余模块的 C/Objective-C 函数体仍只有机器码，需重写而不能无损反编译。
- 未把逆向猜测写回 1.1.24 DEB；原包保持不变。

## 验证现状

- DEB 文件大小 `188366` 字节，版本 `1.1.24`，arm64e；内含 `arm64` 与 `arm64e` 通用动态库。保存的动态库与 DEB payload 的 SHA-256 一致。
- 保留的 footer geometry 测试：29 项通过；恢复控制器的 Node `--check` 语法检查通过，7 个隔离行为场景通过。核心 C 测试仍因缺失 `tests/fixtures/real.conf` 失败 1 项（95 项通过）。
- 原核心测试源码和 fixture 均未找到，不能宣称核心 C 测试全通过。脚本行为测试覆盖：健康节点不切换、同地区最低延迟切换、跨地区兜底、冷却时间、无候选、无有效测速结果、无当前策略节点。
- 此目录是有证据支撑的逆向控制器源码与其他模块重写起点，不是已经完整重建、打包或设备验证的替代插件。
