# QXAS 1.1.37 交接：候选收集计数诊断

## 已知真机状态

1.1.36 主开关日志确认镜像冲突已被保留；脚本准备成功；核心 status=0、changed=1；Engine `applyScriptMode returned=1`；配置长度增加 203 字节。这证明主开关已成功生成并写入任务配置。同期启用流程报告候选 0 个；日志没有任务触发或节点切换证据，所以端到端自动切换仍未通过。

引擎实现有 `candidatePaths` 与 `collectNodeTags` 两步返回数组；现有 1.1.36 日志没有这两步计数，无法判断是找不到候选配置路径，还是从路径中解析不到标签。

## 1.1.37 改动及验证

新增透明计数 Hook：每个原方法只调用一次，记录结果类名和数量，并原样返回。诊断不输出节点名称、配置正文或订阅 URL；不改筛选、任务或脚本逻辑。C/Python 集成与 26 个合成日志场景、控制器 7 个模拟场景、严格 arm64/arm64e 构建、DEB 包内容和每个切片 62 个签名代码页检查通过。arm64e 保留对象 ABI 链接警告仍存在。双架构安装包内均核对到两个候选 Hook。

## 产物

- [DEB](output/QXAS_1.1.37_candidates_iphoneos-arm64e.deb)：189002 字节；SHA-256 `dad456ee7d95f77c30c0b7738d05cc5dbc9c656cc2504055c93f91bf3ddc52f3`。
- [ZIP](output/QXAS_1.1.37_candidates_test.zip)：188480 字节；SHA-256 `f87aa4bccbb76fad57b0126e981f23eec8c470aab201994f17c70978573078fe`；内含 DEB 与独立包逐字节一致。

## 你需要做的测试

1. 用包管理器覆盖安装 1.1.37，确认显示版本为 1.1.37；完全退出并重开 Quantumult X。保留现有脚本，不删除或改名。
2. 从关闭状态只打开一次 QXAS 主开关，不点“立即应用”。
3. 回传同一次操作日志，至少包括 `QXAS diagnostic package loaded 1.1.37`、`candidatePaths result class=… count=…`、`collectNodeTags result class=… count=…`、`已启用智能切节点…` 和 `applyScriptMode returned=…`。计数不包含节点名称。
4. 如果标签数大于零，再确认 QX 计划任务实际触发以及是否切换节点；最后另行关闭并确认还原。若候选计数仍为零，先据两项计数定位链路，再决定是否需要改筛选逻辑。

计数解释：`candidatePaths=0` 表示候选配置路径集合为空；`candidatePaths>0` 且 `collectNodeTags=0` 表示候选路径已找到、标签收集结果为空；两个计数均大于零表示标签收集阶段有输出，需查后续任务/脚本参数传递。数字只是阶段线索，不证明节点是否健康或脚本是否已执行。