#!/usr/bin/env python3
"""Generate a checked controller suffix replacement from the pinned Engine object."""
from hashlib import sha256
from pathlib import Path
import sys

engine, controller, output = map(Path, sys.argv[1:])
obj=engine.read_bytes()
assert sha256(obj).hexdigest() == '3ad859f552ecfe0ec96cfd55b9c32a8d8fae34d097ccb2abcc779aa6e26aed73'
start='  var COOLDOWN = 180000;'.encode('utf-16le')
end='}());'.encode('utf-16le')
assert obj.count(start)==1 and obj.count(end)==1
begin=obj.index(start)
old=obj[begin:obj.index(end,begin)+len(end)].decode('utf-16le')
old=old.replace('请改用自动测速组模式','请检查 QX 版本',1)
# The existing build pads outside the JS string with two spaces to preserve the CFString size.
msg_old="'QX 未提供脚本控制接口，请改用自动测速组模式'"
msg_new="'QX 未提供脚本控制接口，请检查 QX 版本'"
assert old.count(msg_new)==1
old=old.replace(msg_new,msg_new.ljust(len(msg_old)),1)
new=controller.read_text(encoding='utf-8')
assert new.startswith('  // QXAS_STABLE_FAILOVER_1_1_44\n') and new.endswith('}());\n')

def array(name,value):
    raw=value.encode('utf-8')
    groups=[', '.join(str(v) for v in raw[i:i+20]) for i in range(0,len(raw),20)]
    return 'static const unsigned char '+name+'[] = {\n    '+',\n    '.join(groups)+'\n};\n'

output.write_text(array('old_suffix',old)+array('new_suffix',new),encoding='ascii')
