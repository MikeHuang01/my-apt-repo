#!/usr/bin/env python3
"""Build the 1.1.44 stable failover candidate."""
import build_diagnostic_deb as package
import validate_relinked_deb as validator

BASELINE_SHA256 = '1150c49cb39e7ca0821eb860c60d9e9bcd1df54973a500ab9da4d0d9ce380b11'
OLD_VERSION = '1.1.43'
NEW_VERSION = '1.1.44'

def main():
    def build_package(baseline, dylib):
        result = package.build(baseline, dylib, baseline_sha=BASELINE_SHA256,
                               old_version=OLD_VERSION, new_version=NEW_VERSION,
                               embedded_version=NEW_VERSION)
        validator.validate(result, baseline, NEW_VERSION)
        return result

    package.package_cli(__doc__, build_package)

if __name__ == '__main__':
    try:
        main()
    except (AssertionError, ValueError, OSError, KeyError) as error:
        raise SystemExit(f'build failed: {error}')
