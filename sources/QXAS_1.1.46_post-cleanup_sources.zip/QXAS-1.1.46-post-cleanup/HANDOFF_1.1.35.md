# QXAS 1.1.35 交接：脚本文件路径

> 已收到 1.1.35 真机日志，确认完整源路径通过，镜像检查返回 EEXIST，核心未执行。本页下方未安装说明是交付时的历史状态；继续看 [1.1.36 交接](HANDOFF_1.1.36.md)。

## 当前结论

1.1.34 的路径守卫误把 Engine 的中间目录当成第三参数。用真实的完整路径替换旧回归的目录入参后，旧版本当场在第一次复制的断言失败；1.1.35 在同一场景通过。**这证明本地路径契约缺陷已修复，不证明历史 1.1.25 的设备问题由此造成，也不证明设备已恢复。**

## 可复核证据

- 保留的 arm64 `QXASEngine.o` SHA-256：`3ad859f552ecfe0ec96cfd55b9c32a8d8fae34d097ccb2abcc779aa6e26aed73`。`applyScriptMode:` 在 `0x5160` 调用 `scriptsDirectoryWithError:`，结果到 `x22`；`0x519c` 通过 `stringByAppendingPathComponent:` 追加 `qxas-controller.js`，`0x51a8` 将文件路径放回 `x22`。旧目录另在 `x20`。
- `0x53dc` 将完整文件路径从 `x22` 保存到 `x26`。`0x5698–0x56ac` 对其调用 `UTF8String`，结果进入 `x2`，在 `0x56c4` 传给 `_qxas_apply_task`。选择器由 `__objc_selrefs` 中的 `.367 / .38 / .301` 解析，文件名由 CFString `.449` 指向 `l_.str.448`（`__cstring` `0x5d76`）。Engine 通过 Store 的状态目录追加 `Scripts`，而 `Documents/Scripts` 是本地复制目标。
- 保留的 `qxas_core.o` SHA-256：`c10771a1ab92a01a400d8e74f75e2a7ac7a1e9f091df807f19be1e3ee8bb2ad9`。`0x29f8–0x2a0c` 的 `-1` 是空 config、空 output 槽或空脚本引用守卫。核心把第三参数作为 `* * * * * %s, tag=QXAS-Controller, enabled=true` 的引用字段，不自行追加文件名。本版不改变这一转换或 Engine 的备份、写入、还原闸门。

在最终 DEB（不是构建临时文件）的两份签名切片中另外核对了直接分支：arm64 在 `0x10a84`、arm64e 在 `0x108b4` 各有一处 `applyScriptMode:` → `_qxas_local_task`，且包装函数内各有一处对保留 `_qxas_apply_task` 的直接调用。这排除了这份安装包在静态链接时绕过 wrapper；不能排除设备加载了其他版本，或运行时发生 ABI/加载问题。

## 改动与限制

- [路径助手](src/qxas_task_path.c)按规范化容器下的固定脚本文件校验；按目录描述符访问并拒绝软链接。首次发布用 `linkat` 原子拒绝抢先创建的目标；刷新时，在同一描述符上检查内容和 xattr，再于重命名前复核 inode 与时间戳。普通 POSIX `renameat` 不提供“匹配旧 inode 才替换”的原子语义，最后一次复核与替换之间仍有极窄的竞态窗口。
- [任务包装](src/qxas_local_task.m)透传 Engine 文件路径并记录准备成功或阶段与 errno。[开关包装](src/qxas_switch_hook.m)先记录 1.1.35，再只转发一次原回调；保留对象中的旧应用内版本文案也更新为 1.1.35。标记出现只能证明新开关路径已运行，不能证明 Engine 成功。
- 本地验证：严格 C 编译及并发回归、3 项 Python 源码集成检查、恢复版控制器的 7 个 JavaScript 模拟场景，arm64 / arm64e 构建，62+62 个签名代码页、包身份及 payload 元数据/无维护脚本、ZIP 内 DEB 完全一致。arm64e 旧对象 ABI 警告仍在；以上不包含真机加载、任务解析或脚本运行。

## 产物

| 文件 | 字节 | SHA-256 |
|---|---:|---|
| [DEB](output/QXAS_1.1.35_scriptfile_iphoneos-arm64e.deb) | 188216 | `c04115052706fbae8a6cbfa4b7357cacb09430f320a66d7693a9f3f39bbb55c6` |
| [ZIP](output/QXAS_1.1.35_scriptfile_test.zip) | 187646 | `bc93e534bc1afe21bc305a09cb5874c33a3fa23b79c8282ccc3970ab2163d054` |

[1.1.34 基线包](output/QXAS_1.1.34_taskdir_iphoneos-arm64e.deb)原样保留。用 [原生构建脚本](build_native.sh) 构建双架构，然后把它打印的 `BUILD_DIR` 下的 `QXAS.dylib`、基线 DEB 和新输出路径传给 [1.1.35 构建器](build_scriptfile_deb.py)：参数顺序是基线、动态库、输出；不会覆盖旧产物。

## 下一步：只做一次真机开关验证

1. 用包管理器覆盖安装 1.1.35，完全退出并重新打开 Quantumult X。先保留已有运行日志作为历史；给此次验证记录当前时间，从关闭状态只打开主开关一次，不额外点“立即应用”。
2. 回传同次操作从 `QXAS diagnostic package loaded 1.1.35` 到 `QXAS engine applyScriptMode returned=…` 的运行日志。如有 `applyNow` 结果或 backup/write 失败行，也一并附上。可遮盖容器 UUID、指针值和私人路径，但保留路径尾部、是否为空、阶段、状态、errno 及 NSError domain/code。
3. 若无版本标记，先查是否加载了新 dylib；若有标记却无 wrapper 入口，查 Engine 更早的返回；若有 `script preparation failed`，以阶段和 errno 定位；若出现 `script preparation succeeded` 后核心失败，按 core 状态查，不继续猜路径；若 Engine 返回成功，再核对配置中生成了一条 QXAS 任务，以及任务实际可执行。需要测试关闭还原时，另做一次独立记录。

可用 [离线判读工具](triage_switch_log.py) 检查 UTF-8 日志：`python3 triage_switch_log.py <导出的日志>`。它只给出最新带标记开关的判读和相关行号，不输出日志正文，也不能验证日志时间、来源或任务实际执行。请仍只提供一次操作的日志，避免把手动应用等其他操作混入同一段。已用 15 个合成场景覆盖旧版本、重复记录、失败阶段及 Engine 成功但任务未验证等情况。

目前工作机没有发现可操作设备，未安装、未切换开关，也没有新设备日志可供判定。
