#!/usr/bin/env python3
"""Build the 1.1.31 diagnostic upgrade from verified 1.1.30."""
import argparse
import copy
import gzip
import hashlib
import io
import tarfile
from pathlib import Path

import build_candidate as base

BASELINE_SHA256 = '284de4dc3f0614ae1dc9b20d7d9014cf4e4d42f70595792b37f3647b74dd08ce'
OLD_VERSION = '1.1.30'
NEW_VERSION = '1.1.31'
DYLIB = 'Library/MobileSubstrate/DynamicLibraries/QXAS.dylib'


def rebuild_tar(payload, rows=None, replacement=None):
    if rows is None:
        rows = base.tar_entries(payload)
    out = io.BytesIO()
    with tarfile.open(fileobj=out, mode='w', format=tarfile.USTAR_FORMAT) as archive:
        for member, value in rows:
            info = copy.copy(member)
            if value is not None and replacement is not None and base.name_of(member) == DYLIB:
                value = replacement
                info.size = len(value)
            archive.addfile(info, io.BytesIO(value) if value is not None else None)
    return gzip.compress(out.getvalue(), compresslevel=9, mtime=0)


def build(baseline, dylib, *, baseline_sha=None, old_version=None,
          new_version=None, embedded_version=None):
    baseline_sha = BASELINE_SHA256 if baseline_sha is None else baseline_sha
    old_version = OLD_VERSION if old_version is None else old_version
    new_version = NEW_VERSION if new_version is None else new_version
    if hashlib.sha256(baseline).hexdigest() != baseline_sha:
        raise ValueError(f'input is not the verified {old_version} candidate DEB')
    ar = base.unpack_ar(baseline)
    control = base.tar_entries(ar['control.tar.gz'])
    control_rows = []
    found_control = False
    for member, value in control:
        if member.isfile():
            if base.name_of(member) != 'control':
                raise ValueError('unexpected DEBIAN control file')
            old = f'Version: {old_version}\n'.encode()
            if value.count(old) != 1:
                raise ValueError('baseline package version mismatch')
            value = value.replace(old, f'Version: {new_version}\n'.encode())
            found_control = True
        control_rows.append((member, value))
    if not found_control:
        raise ValueError('DEBIAN/control not found')

    rows = base.tar_entries(ar['data.tar.gz'])
    files = sorted(base.name_of(m) for m, _ in rows if m.isfile())
    if files != sorted((base.DYLIB, base.PLIST)):
        raise ValueError(f'unexpected payload files: {files}')
    patched_dylib = base.patch_fat(dylib, new_version=embedded_version)
    out = dict(ar)
    out['control.tar.gz'] = rebuild_tar(ar['control.tar.gz'], control_rows)
    out['data.tar.gz'] = rebuild_tar(ar['data.tar.gz'], rows, patched_dylib)
    result = base.pack_ar(out)

    check = base.unpack_ar(result)
    check_control = base.tar_entries(check['control.tar.gz'])
    if not any(m.isfile() and base.name_of(m) == 'control' and f'Version: {new_version}\n'.encode() in value for m, value in check_control):
        raise ValueError('control round-trip validation failed')
    check_rows = base.tar_entries(check['data.tar.gz'])
    actual = next(value for member, value in check_rows if member.isfile() and base.name_of(member) == DYLIB)
    if actual != patched_dylib:
        raise ValueError('dylib round-trip validation failed')
    return result


def package_cli(description, build_package):
    """Read inputs, run the version-specific builder and write a new output."""
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument('baseline', type=Path)
    parser.add_argument('dylib', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    result = build_package(args.baseline.read_bytes(), args.dylib.read_bytes())
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('xb') as stream:
        stream.write(result)
    print(f'{args.output}: {len(result)} bytes SHA256 {hashlib.sha256(result).hexdigest()}')


def main():
    package_cli(__doc__, build)

if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, tarfile.TarError, KeyError) as error:
        raise SystemExit(f'build failed: {error}')
