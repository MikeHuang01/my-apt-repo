# QXAS DEB 逆向修改工作区

- [1.1.46 精简审计、构建复验与回滚](CLEANUP_1.1.46.md)（原交付包未覆盖）。

## 1.1.46：使用说明收尾

- 调整第二步和关于区，补充智能优选规则，控制器和任务逻辑不变。[DEB](output/QXAS_1.1.46_final-ui_iphoneos-arm64e.deb) · [ZIP](output/QXAS_1.1.46_final-ui_test.zip) · [交接](HANDOFF_1.1.46.md)。

## 1.1.45：使用说明与任务检查

- 缩小入口、补充新手说明、精简运行日志，并校验生成的任务条目；原故障切换算法不变。[DEB](output/QXAS_1.1.45_guided_iphoneos-arm64e.deb) · [ZIP](output/QXAS_1.1.45_guided_test.zip) · [验收说明](HANDOFF_1.1.45.md)。

## 1.1.44：稳定优先故障恢复

- 测得通就不换；两次确认失败才分批测候选；冷却提前，切换前保护手动改选。[DEB](output/QXAS_1.1.44_stable-failover_iphoneos-arm64e.deb) · [ZIP](output/QXAS_1.1.44_stable-failover_test.zip) · [测试说明](HANDOFF_1.1.44.md)。

## 1.1.43：仅故障切换

- 删除额外「QX 自动测速」，保留原定时健康检查和超时切换。[DEB](output/QXAS_1.1.43_failover-only_iphoneos-arm64e.deb) · [ZIP](output/QXAS_1.1.43_failover-only_test.zip) · [GitHub 方案对照与验收](HANDOFF_1.1.43.md)。

## 1.1.42：界面、三小时日志与低频测速

- [DEB](output/QXAS_1.1.42_settings_iphoneos-arm64e.deb) · [ZIP](output/QXAS_1.1.42_settings_test.zip) · [验收与节能建议](HANDOFF_1.1.42.md)。默认智能切换行为未变，待真机确认。

## 1.1.41：仅智能切换，待真机验证

- 主开关是唯一启停入口；旧测速组模式及专用设置不再提供，菜单入口匹配相邻原生字体。保留已验证的 1.1.39 切换算法，不带运行插桩或探针。
- [DEB](output/QXAS_1.1.41_smartonly_iphoneos-arm64e.deb) · [ZIP](output/QXAS_1.1.41_smartonly_test.zip) · [智能切换说明与验收](HANDOFF_1.1.41.md)。

## 1.1.39：本地任务文件名候选

- 1.1.38 真机无语法报错、配置写入成功，但没有观察到超时节点切换。1.1.39 按原厂示例改用 Scripts 内的独立文件名，待确认任务执行与自动切换。
- [DEB](output/QXAS_1.1.39_localref_iphoneos-arm64e.deb) · [ZIP](output/QXAS_1.1.39_localref_test.zip) · [设备验收](HANDOFF_1.1.39.md)。

## 早期候选计数排查（历史）

- 1.1.36 真机已确认脚本配置成功写入，任务候选为 0；1.1.37 诊断包已完成本地构建和测试。下一步必须安装 1.1.37 获取路径数与标签数；在得到计数前，不推断或修改筛选规则。
- 详细操作及 SHA-256 见 [1.1.37 交接](HANDOFF_1.1.37.md)。

## 当前真机阻断及 1.1.38 修正候选

- 1.1.37 真机证明候选 43 个、任务配置改写成功，关闭后可还原；重新开启时报配置第 107 行语法错误，生成的绝对路径包含 `Application Support` 空格。
- 1.1.38 将校验后的脚本复制到 `Documents/QXAS-Scripts/qxas-controller.js`，核心 task 参数用该无空格路径；保留不覆盖旧 `Documents/Scripts` 用户文件。严格 C/Python 回归和双架构包签名页验证通过，待真机确认 QX 配置解析与脚本执行。
- [DEB](output/QXAS_1.1.38_spacefree-task_iphoneos-arm64e.deb) · [ZIP](output/QXAS_1.1.38_spacefree-task_test.zip) · [设备测试步骤](HANDOFF_1.1.38.md)。

## 1.1.38 无空格任务路径修正候选（推荐验证）

- 1.1.37 真机已证明候选 `collectNodeTags` 返回 43 项；开关关闭时备份还原成功。重新启用时报 QX 配置 line 107 语法错误，因为原样任务路径 `.../Application Support/...` 含空格。
- 1.1.38 将验证过的脚本镜像到容器 `Documents/QXAS-Scripts/qxas-controller.js`，把无空格的该路径交给核心；不覆盖用户旧镜像。待真机解析与运行验证。

## 1.1.37 候选计数诊断候选（历史）

- 在 1.1.36 基础上增加 `candidatePaths` / `collectNodeTags` 返回类型和数量日志，不记录节点名、配置正文或订阅 URL；两方法均只调用一次并原样返回。不改变筛选规则。
- [DEB](output/QXAS_1.1.37_candidates_iphoneos-arm64e.deb) · [ZIP](output/QXAS_1.1.37_candidates_test.zip) · [真机步骤](HANDOFF_1.1.37.md)。计数 Hook 每次调用引擎原方法一次，返回值不变，不输出节点名称；尚待真机计数和任务运行验证。

## 1.1.36 镜像冲突修正候选（历史版本）

- [DEB](output/QXAS_1.1.36_mirrorconflict_iphoneos-arm64e.deb) · [ZIP](output/QXAS_1.1.36_mirrorconflict_test.zip) · [真机验收](HANDOFF_1.1.36.md)。
- 真机日志确认 1.1.35 因既有镜像 EEXIST 中止；1.1.36 保留镜像后核心 status=0/changed=1、Engine 返回 1，配置长度增加 203 字节，越过了原始主开关改写失败。该轮另报候选 0 个；任务可执行性及关闭还原仍待设备验收。

## 1.1.35 脚本文件路径修正候选（历史记录）

- [DEB 安装包](output/QXAS_1.1.35_scriptfile_iphoneos-arm64e.deb) · [ZIP 压缩包](output/QXAS_1.1.35_scriptfile_test.zip) · [反汇编证据、构建与设备验收](HANDOFF_1.1.35.md)。
- 修正 1.1.34 的目录误判：Engine 传入的是 `…/Library/Application Support/QXAS/Scripts/qxas-controller.js` 完整文件路径。旧 helper 在此真实入参复现失败；新 helper 按文件路径验证并原样透传，不修改核心转换、开关原 handler 或备份闸门。
- 首次发布使用不覆盖现有目标的原子操作；更新已管理的脚本前复核目标文件，拒绝已修改的文件。准备失败保留相应阶段和 errno；应用内版本和开关标记统一为 1.1.35。
- 已通过本地 C 路径测试（含并发写入）、3 项 Python 源码集成检查、恢复版控制器的 7 个 JavaScript 模拟场景、双架构签名页与包身份检查、ZIP 内 DEB 内容比对。**1.1.35 后续已在真机加载并复现镜像冲突；arm64e 旧对象 ABI 警告仍在。**

## 1.1.34 脚本任务 source 目录修正测试包（历史记录，不建议安装）

- 安装包：[output/QXAS_1.1.34_taskdir_iphoneos-arm64e.deb](output/QXAS_1.1.34_taskdir_iphoneos-arm64e.deb)，187,154 字节；SHA-256 `18600518dd038c81f5b91f87b606371d520be3093ab3b95b86e536d54ed31813`。
- 压缩包：[output/QXAS_1.1.34_taskdir_test.zip](output/QXAS_1.1.34_taskdir_test.zip)，186,629 字节；SHA-256 `1b443f2ce90ea87cbfe80073efd7ec2a4bdb685b68f90e4309b53c5051a4a22d`。已解压并比对内部 DEB 的 SHA-256。
- 已确认缺陷：该版本错误地只接受 `…/Library/Application Support/QXAS/Scripts` 目录，但引擎传入的是其中控制器的完整路径。`Documents/Scripts` 是复制目标，并不是 wrapper 校验的 source。
- 本地验证通过：严格 C 路径测试、switch hook / Engine / apply 诊断集成测试；DEB 校验确认 arm64 与 arm64e 两个切片各有 62 个有效签名代码页、包内 payload 元数据未变且无维护脚本。arm64e 链接仍报告沿用旧对象的 ABI 兼容警告。
- JavaScript controller 测试未运行：此环境的 Windows 与 WSL 都没有 Node.js。设备运行验证也尚未完成。
- **本版不再作为设备验收目标。** 请按 [1.1.35 交接](HANDOFF_1.1.35.md) 操作；旧版截图和日志不能验证新候选。

## 1.1.33 应用内日志诊断测试包

- 安装包：[output/QXAS_1.1.33_app-log_iphoneos-arm64e.deb](output/QXAS_1.1.33_app-log_iphoneos-arm64e.deb)，187,164 字节；SHA-256 `35b58c12b7a9812e6cfbfd4be937833d3fb895a9baf2a5cb1f8fa8d324057d78`。同包 ID/架构/依赖，从 SHA-256 锁定的 1.1.32 覆盖升级；保持 payload 元数据及 plist，无维护脚本。
- 将主开关状态、脚本任务 wrapper 输入/返回状态、脚本准备阶段、Engine 读写 NSError 和 apply 结果同步写入 QXAS 应用内运行日志（由 `QXASStore` 持久化），不再只依赖 `NSLog`。反汇编核实 `QXASStore` 的日志路径位于 `Application Support/QXAS/qxas.log`，`log:` 经该路径追加持久化；集成测试断言 `QXASAppLog` 调用 `QXASStore`，DEB 校验器也检查包内 `qxas.log` 路径。成功触发开关后，日志应出现 `QXAS diagnostic package loaded 1.1.33`，可用于确认实际载入版本。
- 开关只转发原回调一次；未额外触发 apply/restore，也不记录配置正文。以原生 arm64 和 arm64e 编译、签名；DEB 校验确认每个切片 62 个 code slots、payload 不变、无维护脚本。
- **设备结果仍未知：**此包改善可见诊断，不等于已证明修复主开关。请覆盖安装后，在应用日志中清除旧记录，只打开主开关一次；把包含版本标记、`QXAS task wrapper enter/exit`、`task config transformation failed` 和 Engine 返回/错误的同一次新日志回传。先确认标记版本为 1.1.33；若仍失败，日志将用来判断 -1 到底来自 wrapper 输入、脚本准备还是核心转换。

## 1.1.32 canonical-path 修复测试包

- 修复 `qxas_task_path.c`：`QXASEngine` 会先对 `NSHomeDirectory` 做 `realpath`，wrapper 现在也规范化应用容器根目录后再校验 `qxas-controller.js` 源路径并打开目录；避免容器路径别名导致脚本准备阶段误报 `-1`。新增符号链接容器根目录回归测试。
- DEB：`output/QXAS_1.1.32_iphoneos-arm64e.deb`，185,042 字节，SHA-256 `f5c5b69ac935664874c09d5c1bb8ca523f9493045097f166d6a22e70e3dff98b`；从已验证的 1.1.31 诊断包覆盖升级生成，保留原 package id、payload 范围和 plist，无维护脚本。
- 本地通过：严格 C 路径测试、arm64/arm64e 重编译与签名、DEB 版本/payload/62 个代码页校验、switch hook/engine/apply 诊断集成测试。
- **设备验证仍未完成：**尚未在目标设备安装 1.1.32，也未取得同一次主开关操作的完整日志；因此本包是待设备验证的修复候选，不能据此宣称主开关故障已解决。
- **新增设备截图证据（2026-11-26 22:14，Asia/Shanghai）：**截图日志仍明确显示 `1.1.25 兼容入口`、`1.1.25 设置入口已点击`，随后为“控制器脚本已写入应用沙盒”和“脚本模式失败：配置改写返回 -1”。没有出现 1.1.31/1.1.32 的 task wrapper 或 engine 诊断行，因此这次仍不能作为 1.1.32 验证。

## 1.1.31 故障定位诊断候选

- 最新设备日志（1.1.30）明确报“脚本模式失败：配置改写返回 -1”，因此本次失败已确定发生在脚本模式任务转换，不是普通 `_qxas_apply` 分支；普通模式入口分析只供区分路径，不能用来解释这次错误。对脚本任务 `_qxas_apply_task` 仍需采集参数及内部失败位置。旧日志同时显示 46 个候选节点已收集、控制器脚本已写入应用沙盒，故任务准备不是日志显示的失败点；这还不能单独证明调用参数符合引擎要求。
- 二进制反汇编确认 `_qxas_apply_task` 的 -1 快速返回条件是 config 指针为空、task-name 指针为空/首字节为 NUL，或 output 槽为空；后续切分/分配/拼接失败返回 -2。诊断 wrapper 在进入核心前先检查 config/output，并向核心固定传入非空 `qxas-controller.js`。所以设备日志须区分 `QXAS script preparation failed at ...`（本地脚本预处理）、wrapper `exit status=-1 config=... output_slot=...`（wrapper 输入守卫）、与 `task config transformation failed (status -1)`（核心转换状态）；这些不是同一个失败点。
- 新增 `src/qxas_apply_diagnostics.m` wrapper：仅记录 input 指针/长度、opaque options 指针、输出槽及 core 实际状态/errno/output 长度；调用原 `qxas_apply` 恰好一次，并保留调用前后 errno。新引擎 hook 只观察原 `confPath` 返回值，不另行重复调用路径候选；记录 `readConfData:error:` 的 data/bytes/length/NSError，并区分 `applyNow:` 与 `applyScriptMode:`。脚本任务 wrapper 同时记录配置指针/长度、阶段和状态。日志不包含配置全文。
- DEB：`output/QXAS_1.1.31_iphoneos-arm64e.deb`，184,998 字节，SHA-256 `a933a96f25580dcfed609a4a684d3917386c92d0bc7114b888a2a82bfc291a1f`；由 SHA-256 锁定的 1.1.30 `284de4dc3f0614ae1dc9b20d7d9014cf4e4d42f70595792b37f3647b74dd08ce` 构建，版本排序为覆盖升级。保持原 package id、payload 范围与 plist；无维护脚本。
- 本地通过：开关/诊断/脚本任务集成测试；严格编译 C 路径回归；arm64 + arm64e 编译、链接和签名切片；DEB 版本、payload、62 个签名代码页/切片结构、诊断符号和脚本标记校验。arm64e 链接仍报告保留旧对象的 ABI 兼容警告；这不是设备运行测试。
- **限制：**1.1.31 是采证包，不是已证明的故障修复。尚未安装或进行开关-only/覆盖升级设备验证。当前可确认失败在脚本任务转换；设备测试时请只操作主开关一次，然后回传 `QXAS task wrapper enter`、`QXAS task config transformation failed`、`QXAS task wrapper exit`，以及同一时段引擎返回日志，便于把配置指针/长度与实际失败状态对应起来。不要用本地测试通过声称设备故障已解决。
- 新收到的设备日志仅更新到 11-26 19:26:11，最后显示“1.1.25 设置入口已点击”；其后没有主开关应用结果，也没有 1.1.31 的 `QXAS task wrapper` / engine 诊断行。因此它证明该次记录的运行版本仍是 1.1.25，不能验证 1.1.31 采证包。
- 对照 Engine 的 task 调用点 (arm64 `applyScriptMode:` @ `0x56c4`) 和 core `_qxas_apply_task`：前者将 `[NSData bytes]`、`length`、第三参数及三个输出槽传入；selector reference `.301` 经 `__objc_selrefs` 重定位到 `UTF8String`，确认第三参数是 C 字符串而非 NSString 对象。wrapper 调用签名与 Engine 的六个参数顺序一致。core 仅在配置指针、task-name 指针/首字节或 output 槽为 NULL/空时返回 -1，内部切分/构造失败归 -2。wrapper 在 config/output 输入守卫通过后调用 core，并固定传入非空任务名。因此若同一轮日志显示 `task config transformation failed (status -1)` 且 `enter` 的 config/output 均非空，这与当前 core -1 快速返回条件矛盾，应优先核对实际加载版本、符号重绑定和 ABI；若出现脚本预处理失败行，则属于独立路径问题。
## 1.1.30 开关重复触发修正版

- 反汇编保留的原版 QXASUI.o 并映射 selector 重定位后，确认原始 `mainSwitchChanged:` 开启分支已经调用 `applyAsync`，关闭分支也已有异步还原处理。旧 hook 在转发原回调后又调用 `doApply` / `doRestore`，造成重复执行；1.1.30 移除这第二次调用，只记录开关状态并转发原回调。
- 保留 1.1.29 的引擎 NSError 诊断和手动“立即应用”/“一键还原”入口。1.1.30 DEB：`output/QXAS_1.1.30_iphoneos-arm64e.deb`，181,788 字节，SHA-256 `284de4dc3f0614ae1dc9b20d7d9014cf4e4d42f70595792b37f3647b74dd08ce`；相对 1.1.29 的 SHA-256 锁定覆盖升级。
- arm64/arm64e 各 62 个签名代码页、包结构及版本排序检查通过；开关 hook 与引擎诊断集成测试、严格编译的 C 路径测试均通过。`controller.test.js` 的 7 个场景是对本地恢复模板的模拟，不是 DEB 内脚本或设备测试。
- **范围边界：**DEB payload 只含 `QXAS.dylib` 与 plist；不修改 QXAS 内置的 QXASEngine/controller 模板。1.1.30 修复的是 switch hook 重复触发并保留诊断日志；脚本模式是否还存在独立引擎故障，需设备侧 NSError 证据判断。未安装，设备侧开关流程和实际 NSError 仍待验证。

## 1.1.29 开关失败诊断候选（已知重复触发，不要安装）

- 在 1.1.28 的诊断基础上新增 QXASEngine 的 `backupData:forPath:error:` 与 `writeConfData:toPath:error:` 失败日志，包含路径、NSError domain/code/description。
- 反汇编确认当时 hook 会在原有开启流程之外再次调用 `doApply`，因此该包不应用于设备测试。已保留该未安装产物作诊断记录，由 1.1.30 修正。原手动入口未移除。DEB：`output/QXAS_1.1.29_iphoneos-arm64e.deb`，182,212 字节，SHA-256 `a6e73a7d5b47626ec11cb501503c6a617b652ec178fc165e7882f699b022ea44`。

## 1.1.28 开关诊断候选（前版）

- 开关变更、脚本准备阶段/errno 和配置变换失败状态会写入日志；不包含引擎 NSError。
- `output/QXAS_1.1.28_iphoneos-arm64e.deb`：180,798 字节，SHA-256 `f99d745cf0a6fd10200d5beab8aea52a29f8ad2ce21c921d6dadf0c9bd507a63`；以 1.1.27 为升级基线，保持未安装。
- 保留原有“立即应用”和“一键还原”入口，作为人工恢复路径；在单开关流程通过设备验证前不移除。
- 以 SHA-256 锁定的 1.1.27 DEB 为覆盖升级基线：`output/QXAS_1.1.28_iphoneos-arm64e.deb`，180,798 字节，SHA-256 `f99d745cf0a6fd10200d5beab8aea52a29f8ad2ce21c921d6dadf0c9bd507a63`。本机结构及 62 个签名代码页/切片校验通过；未安装，尚无设备运行验证。

## 1.1.27 开关自动启停候选（前版）

- 当时误判原回调不处理自动启停；现在确认原版 `mainSwitchChanged:` 已执行 `applyAsync` 和异步还原。1.1.27 新增 hook 又触发一次 `doApply` / `doRestore`，造成重复执行；此候选保留作历史记录，不应用于验证。
- 新增 `src/qxas_switch_hook.m`，构建时分别编译到 arm64 / arm64e。未移除手动“立即应用”“一键还原”入口，仍可用于手动重试或恢复。
- 关闭时若无可用备份，原还原流程会报告失败；需要首次启用成功创建备份后，关闭才可还原此前状态。
- 此次复用原立即应用路径，因此截图中的“配置改写失败”仍需看插件日志才能定位具体文件操作；截图本身只有通用提示。
- DEB：`output/QXAS_1.1.27_iphoneos-arm64e.deb`，179,724 字节，SHA-256 `6769bb7cff394836795fac0bd445fe45b7b55020ecdbbabcb37324ca6e4496ac`。本地包校验及 1.1.26 版本排序通过；签名代码页均通过。兼容说明与设备验证边界见下方 1.1.26 记录。

## 1.1.26 脚本模式修复候选（前版）

- [安装包](output/QXAS_1.1.26_iphoneos-arm64e.deb)：178,602 字节；SHA-256 `382f0e6ce41d1b7ac406f5a1d85ca41c6d9fb2e45f4a15949c3e7fac659d8138`。
- 同包 ID、安装路径、架构字段及依赖；1.1.26 的版本排序高于 1.1.24 / 1.1.25，可交给原包管理器执行覆盖升级。没有加入维护脚本或数据迁移。
- 引擎任务调用改经包装函数：先同步生成控制器到应用 Documents/Scripts，再让原任务函数使用纯文件名 qxas-controller.js，避免任务行出现 Application Support 的空格路径。
- 复制失败返回错误，原引擎失败分支停止配置写入；原备份及关闭撤回代码继续沿用。插件创建的脚本带扩展属性校验标记，可随设置更新；不相符的现有文件、符号链接及缺失源脚本均拒绝操作。
- [构建流程](build_native.sh)沿用原二进制对象，新增包装和复制实现；arm64 / arm64e 分别编译、链接和签名，未通过修改架构头伪造切片。arm64e 新增代码含 pacibsp / retab，部署目标 iOS 15.0，保留 RootHide install name。
- **兼容边界：**原对象为旧通用 arm64 ABI，原包 arm64e 切片也不含 PAC；新 arm64e 链接使用 allow_sub_type_mismatches，链接器仍报旧对象 ABI 警告。结构检查、PAC 指令及代码页哈希通过不能替代设备运行验证。此包尚未在 iOS / RootHide / QX 上验证加载、解析、执行及关闭撤回。
- 本地 C 回归通过：初次复制、重复复制、设置更新后的刷新、用户修改保护、意外源路径、目标符号链接、源缺失、源符号链接。严格编译启用 Wall / Wextra / Werror。
- [包校验器](validate_relinked_deb.py)验证了双切片的 124 个签名代码页、架构、PAC 指令、包身份及版本、原 payload 权限与属主、plist 不变、无维护脚本。dpkg-deb 可读取，版本排序检查通过；原有功能符号无缺失。
- [DEB 构建器](build_relinked_deb.py)接受 SHA-256 锁定的 1.1.29 诊断候选 DEB、构建出的通用 dylib 和新输出路径；生成 1.1.30 并拒绝覆盖已有输出。
- 构建中曾产生的仅修改架构头的中间包已隔离为非安装包扩展名，不属于交付结果。原 1.1.24 和旧 1.1.25 均保留。

后文为旧 1.1.25 记录，不代表已修复脚本路径。

## 1.1.25 覆盖升级候选包

- `output/QXAS_1.1.25_iphoneos-arm64e.deb`：188,368 字节；SHA-256 `e2a29e626ab639e22ffe35c7254c9900324b4136daf77077cb66951c1679808a`。
- 同包 ID `com.mikehuang01.qxas2`、同安装路径和依赖，版本从 `1.1.24` 提升到 `1.1.25`；不包含维护脚本或数据迁移。
- 仅修改 9 条备份/脚本路径文案及版本字样。两个切片的 `__TEXT,__text` 和加载配置与原版逐字节一致；已更新并复核签名代码页哈希，`ldid` 可读取双切片签名。逆向工作区的 JavaScript 试验改动未打入此包。
- 使用 `python3 build_candidate.py <原始 1.1.24 DEB> <新输出路径>` 重建。已通过本地包结构和版本顺序验证，尚未在设备上覆盖安装。


本目录以本地 DEB 和编译残留为依据，只保存可核验的重建内容；不等于原始源码，也没有直接用于打包。

- `src/qxas-controller.js`：已从 `QXASEngine.o` 的 UTF-16 常量区按偏移顺序恢复控制器模板，保留 `__TAGS__`、`__NOTIFY__` 占位符；随后只扩展了缺节点/无候选/无健康节点的错误通知。
- `src/qxas-controller.recovered.js`：原样恢复快照；SHA-256 `716503b27f1005b1ecfb9f5634c54ee940183ff74441b074fd693d5c5684e358`。
- `tests/controller.test.js`：对工作副本的本地隔离行为测试，覆盖正常路径及失败通知。
- `REVERSE_ENGINEERING.md`：其余 Objective-C 模块符号、恢复边界和构建限制。

原 DEB 与恢复构建产物只读保存在 `E:\QXAS-recovery-2026-11-25`；没有覆盖或重打包原包。
