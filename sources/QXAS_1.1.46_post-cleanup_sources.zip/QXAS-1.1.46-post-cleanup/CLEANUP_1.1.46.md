# QXAS 1.1.46 精简与复验

## 扫描清单

| 类别 | 发现 | 处理 |
|---|---|---|
| 可清理 | 5 个项目内 Python 字节码缓存 | 只删除逐一核对过的缓存，释放 44,302 字节 |
| 可清理 | 近期三个打包入口重复解析参数、读写文件、打印结果 | 抽取共用入口，保留各个脚本名、参数、基线哈希、版本校验及拒绝覆盖行为 |
| 可清理 | 原生构建命令重复，失败可能留下本次临时目录 | 收敛编译参数；仅失败时清理本次创建的临时目录，成功仍输出原有 BUILD_DIR |
| 可优化 | 日志裁剪重复转换当前时间并复制未移动记录；规范任务行仍扫描逗号字段 | 每次裁剪只转换一次当前时间，对已经位于目标位置的记录不搬移；任务校验增加精确匹配快路径 |
| 待核实 | 历史诊断源、旧测速源、探针、恢复片段、旧动态库以及历史包 | 当前发布不使用的部分可能仍服务历史重建或回滚；保留，不擅删 |
| 风险 | 链接依赖和签名、保留对象的 ABI、真机任务登记 | 不改变工具链、架构、签名步骤、依赖、权限和配置；旧对象的 arm64e ABI 警告仍在 |

## 变更范围

1. 构建层：[原生构建器](build_native.sh) 和 [公共打包逻辑](build_diagnostic_deb.py)、[1.1.44 入口](build_stable_deb.py)、[1.1.45 入口](build_ui_deb.py)、[1.1.46 入口](build_final_ui_deb.py)。相同输入实际复验 1.1.46 打包前后字节一致，三个入口的帮助输出一致。
2. 运行层：[日志裁剪](src/qxas_log_window.c) 和 [任务校验](src/qxas_task_check.c)。保留日志三小时 / 256 KiB 及任务格式限制；不改界面、故障切换、任务周期、脚本路径、冷却或还原流程。
3. 缓存层：只删除可再生的 Python 缓存。不新增第三方依赖；没有足够证据移除现有原生框架或者历史文件。

## 验证结果

- 严格 C 路径与并发、任务条目、日志裁剪、Python 集成（含 26 个日志场景）及 7 个历史控制器模拟通过。当前发布的实际嵌入控制器另外按字节与 1.1.46 原包核对，未改变。
- 差分比较 3,150 个日志样例与 4,000 个任务样例，修改前后结果一致；日志样例覆盖跨年、夏令时与容量边界。
- WSL 日志裁剪微基准：约 213.5 KB / 3,500 条保留记录，中位数从 1.333 ms 降至 0.857 ms（约少 36% 耗时）；不是 iOS 真机、整机内存或电量测试。
- 双架构构建及每切片 71 个签名代码页验证通过。控制归档逐字节一致，安装路径、文件元数据和非动态库负载由原校验器验证。动态库仍为 603,168 字节；DEB 从 212,410 到 212,440 字节，未缩小。
- [原始 1.1.46 安装包](output/QXAS_1.1.46_final-ui_iphoneos-arm64e.deb) 未覆盖；[同版本验证包](output/QXAS_1.1.46_cleanup-validation_iphoneos-arm64e.deb) 只供本地验收，同版本不建议作常规升级。尚未在 iOS 真机验收。

## 复验命令（WSL，项目目录）

```bash
export PYTHONDONTWRITEBYTECODE=1
bash -n build_native.sh
bash build_native.sh
build_dir=/tmp/qxas-native.XXXXXX  # 换成实际 BUILD_DIR
python3 build_final_ui_deb.py output/QXAS_1.1.45_guided_iphoneos-arm64e.deb \
  "$build_dir/QXAS.dylib" /tmp/QXAS_1.1.46-recheck.deb
python3 validate_relinked_deb.py /tmp/QXAS_1.1.46-recheck.deb \
  output/QXAS_1.1.45_guided_iphoneos-arm64e.deb 1.1.46
for test in tests/test_*.py; do python3 "$test" || exit; done
test_dir=$(mktemp -d /tmp/qxas-tests.XXXXXX)
cc -std=c11 -Wall -Wextra -Werror -I"$build_dir" -DQXAS_TEST_WRAP_FSYNC \
  -Wl,--wrap=fsync src/qxas_task_path.c src/qxas_failover.c tests/test_task_path.c -o "$test_dir/path"
cc -std=c11 -Wall -Wextra -Werror src/qxas_task_check.c tests/test_task_check.c -o "$test_dir/task"
cc -std=c11 -Wall -Wextra -Werror src/qxas_log_window.c tests/test_log_window.c -o "$test_dir/log"
"$test_dir/path" && "$test_dir/task" && "$test_dir/log"
node tests/controller.test.js  # 需有 Node 环境
```

输出路径必须未存在。工具链与 SDK 仍使用原项目配置。

## 真机验证与回滚

- 如需真机复验，先备份 QX 配置并关闭自动优选，确认还原，避免带旧任务切包。开启后确认配置仅一条 QXAS 任务，并核对 QX 请求列表；打开 VPN 和计划任务检查可用节点不乱切、故障时能切、关闭会还原。检查日志时窗和关于区显示。不要清空共享 Scripts。
- 设备回滚用[原始 1.1.46 包](output/QXAS_1.1.46_final-ui_iphoneos-arm64e.deb)；若包管理器不允许覆盖同版本，先确认还原，再按包管理器流程卸载验证包并装回原包。
- 源码回滚：[修改前源码快照](output/QXAS_1.1.46_pre-cleanup_sources.zip) 内含本轮全部被修改的原始源码/构建文件。先解压到空目录核对，再按需恢复指定文件；缓存不需要恢复。
