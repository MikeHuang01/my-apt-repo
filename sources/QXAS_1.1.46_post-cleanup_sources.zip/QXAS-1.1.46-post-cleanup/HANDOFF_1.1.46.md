# QXAS 1.1.46：使用说明收尾

- 「怎么用」保留第一条；第二条按用户原文更新，移除旧第三条。下方补充现有智能优选规则：每分钟检查，能测通不切，两次失败才分批测速，优先同地区及近期切换成功的节点，成功切换后三分钟冷却，检测到手动改选则不覆盖。
- 「关于」标题与透明正文分开，正文显式禁用大小写转换，原样显示 MikeHuang01 和 https://mikehuang01.github.io/my-apt-repo/v3/。
- 不变更任务生成、故障切换和还原逻辑。逐切片比对证明包内控制器、计划格式、脚本文件名与 1.1.45 一致。严格 C/Python 回归、双架构构建和各 71 个签名页均通过；尚无 1.1.46 真机结果。

- [DEB](output/QXAS_1.1.46_final-ui_iphoneos-arm64e.deb) SHA-256：dc7baad1db0aa486f3d5844dbfeb73f7eb179e8a2183576e3b6998c076954ef4
- [ZIP](output/QXAS_1.1.46_final-ui_test.zip) SHA-256：5bc2c50df7dc4a4f55759240ad53e305ebe12f27cd3e4e476a64000bf91579cf；内含相同 DEB。
