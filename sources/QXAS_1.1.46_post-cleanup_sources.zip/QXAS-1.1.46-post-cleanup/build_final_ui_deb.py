#!/usr/bin/env python3
"""Build the 1.1.46 instructions and case-preserving About candidate."""
import build_diagnostic_deb as package
import validate_relinked_deb as validator

BASELINE_SHA256 = '21e2dcd892a2c26c675915b8b860ebd42c233dbe7a7150507a17752c2aa25df5'
OLD_VERSION = '1.1.45'
NEW_VERSION = '1.1.46'

def main():
    def build_package(baseline, dylib):
        result = package.build(baseline, dylib, baseline_sha=BASELINE_SHA256,
                               old_version=OLD_VERSION, new_version=NEW_VERSION,
                               embedded_version=NEW_VERSION)
        validator.validate(result, baseline, NEW_VERSION)
        return result

    package.package_cli(__doc__, build_package)

if __name__ == '__main__':
    try:
        main()
    except (AssertionError, ValueError, OSError, KeyError) as error:
        raise SystemExit(f'build failed: {error}')
