# QXAS 1.1.43：仅故障切换

## 本版改动

- 移除「QX 自动测速」开关、定时轮测脚本生成分支和链接对象；不再读取旧轮测偏好。保留字体、关于、通知以及三小时/256 KiB 日志保留。
- 保留 QXAS-Controller 的每分钟当前节点检查、故障时的候选测速、同地区优先及切换冷却。健康时不测候选；未加入延迟阈值，也未改成全局最低延迟优先。两个切片内置故障切换模板和任务格式与 1.1.42 一致。

## 参考方案

- [Quantumult X 官方示例](https://github.com/crossutility/Quantumult-X/blob/master/sample.conf)：公开任务事件包括网络变更和手动交互，未见节点超时或超阈值的脚本事件。原生 available 策略在有流量使用且缺有效策略结果时发起检测，选首个可用节点；url-latency-benchmark 可按延迟选择，alive-checking=false 避免空闲也持续探测，但仍按策略活跃状态和检测间隔工作，不等于每次超时立即通知 QXAS。原生策略组会改变流量所用策略，不在本版恢复。
- [mihomo URL Test](https://github.com/MetaCubeX/Meta-Docs/blob/main/docs/config/proxy-groups/url-test.md) 与 [Fallback](https://github.com/MetaCubeX/Meta-Docs/blob/main/docs/config/proxy-groups/fallback.md)：可借鉴 lazy、检测间隔和 tolerance；Fallback 按顺序找可用项，不保证最小延迟。
- 后续如果继续 QXAS 脚本路线，建议先把冷却检查放到候选测速之前。若要按延迟触发，应使用本轮有效延迟，设置连续两次超限与最小改善幅度，避免抖动。如果候选只分批或抽样，最低延迟只能保证在已测批次内；严格的全局最低需要测全体候选。

## 验证与升级

严格 C 路径及并发、日志保留、Python 集成检查和双架构包校验通过。两个切片各 67 个签名代码页。包内确认没有额外轮测符号或旧偏好读取标记；ZIP 内 DEB 与独立文件一致。1.1.43 尚未真机验证。

旧版若启用了额外轮测并已生成脚本：先关闭旧版自动优选并确认配置还原；安装 1.1.43、完全退出重开 QX 后重新打开自动优选，使管理脚本重新生成。无需删除共享 Scripts。使用关闭后的配置备份；不要直接编辑插件管理脚本。QX VPN、计划任务总开关和 QXAS-Controller 必须启用，故障切换才可计划运行。

- [DEB](output/QXAS_1.1.43_failover-only_iphoneos-arm64e.deb) SHA-256：1150c49cb39e7ca0821eb860c60d9e9bcd1df54973a500ab9da4d0d9ce380b11。
- [ZIP](output/QXAS_1.1.43_failover-only_test.zip) SHA-256：9b52527ca657713a8763dfb67755c15bc4185bf1b8c697fd18ec1b299e3a5550。
