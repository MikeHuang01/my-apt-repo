#!/usr/bin/env python3
"""Lower the entry's fallback base font from 17 to 15 points."""
from hashlib import sha256
from pathlib import Path
import sys

source, target = map(Path, sys.argv[1:])
image = bytearray(source.read_bytes())
if sha256(image).hexdigest() != 'caca10fe4b3dadc2cdd5523f26ca383a315cca642498732936cf91361d483be3':
    raise SystemExit('unexpected QXASMain.o; refusing font patch')
start = 1928 + 0x66a4
if image[start:start+4] != bytes.fromhex('0030661e'):
    raise SystemExit('unexpected font instruction')
image[start:start+4] = bytes.fromhex('00d0651e')
target.write_bytes(image)
