#!/usr/bin/env python3
"""Build the 1.1.33 app-visible diagnostics upgrade from verified 1.1.32."""
import argparse
import hashlib
from pathlib import Path

import build_pathfix_deb as previous

BASELINE_SHA256 = 'f5c5b69ac935664874c09d5c1bb8ca523f9493045097f166d6a22e70e3dff98b'
OLD_VERSION = '1.1.32'
NEW_VERSION = '1.1.33'


def build(baseline, dylib):
    if hashlib.sha256(baseline).hexdigest() != BASELINE_SHA256:
        raise ValueError('input is not the verified 1.1.32 candidate DEB')
    saved = (previous.BASELINE_SHA256, previous.OLD_VERSION, previous.NEW_VERSION)
    previous.BASELINE_SHA256 = BASELINE_SHA256
    previous.OLD_VERSION = OLD_VERSION
    previous.NEW_VERSION = NEW_VERSION
    try:
        return previous.build(baseline, dylib)
    finally:
        previous.BASELINE_SHA256, previous.OLD_VERSION, previous.NEW_VERSION = saved


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('baseline', type=Path)
    parser.add_argument('dylib', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    result = build(args.baseline.read_bytes(), args.dylib.read_bytes())
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('xb') as stream:
        stream.write(result)
    print(f'{args.output}: {len(result)} bytes SHA256 {hashlib.sha256(result).hexdigest()}')


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, KeyError) as error:
        raise SystemExit(f'build failed: {error}')
