# QXAS 1.1.38 交接：无空格任务路径

## 新真机证据及结论

用户提供的 `文本(8).txt` 和截图表明，1.1.37 的 `collectNodeTags` 返回 43 个候选；`applyScriptMode returned=1`，核心状态为 0、`changed=1`。关闭开关后日志明确显示“已还原为原生配置”，配置长度从 10493 返回到 10290。因此候选收集和关闭还原均已有真机通过证据。

再次开启时，Quantumult X 报配置第 107 行语法错误，行内容是未加引号的 `* * * * * /private/var/mobile/Containers/Data/Application/…/Library/Application Support/QXAS/Scripts/qxas-controller.js, tag=QXAS-Controller, enabled=true`。路径中 `Application Support` 的空格会打断任务字段。问题不是候选为零；1.1.37 的实测候选数 43 已排除该猜测。

## 1.1.38 修正

任务仍从 Engine 生成并校验的应用私有 `Application Support/QXAS/Scripts/qxas-controller.js` 读取。修正版本另外安全生成到容器 Documents 下固定无空格目录 `QXAS-Scripts/qxas-controller.js`，并只把这个无空格路径交给原核心形成配置行。旧 `Documents/Scripts/qxas-controller.js` 保留不动，不会覆盖用户的现存文件；新副本通过文件描述符、临时文件、ownership stamp 和原子发布/受保护更新。关闭时仍由原 Engine 备份/还原闸门处理。核心解析格式没有改写。

## 构建与本地验证

- [DEB](output/QXAS_1.1.38_spacefree-task_iphoneos-arm64e.deb)：189220 字节；SHA-256 `6f2cd3b9323c00796d57629b83eefbbb892829e30c58309ba91e3d3649ff9f82`。
- [ZIP](output/QXAS_1.1.38_spacefree-task_test.zip)：188739 字节；SHA-256 `101b43dc689d26e64ead0aa07f68d7584fbe72927712b889f7fb1953c2caf349`，内含 DEB 与独立包字节一致。
- 严格 C 路径/并发测试、三项 Python 集成检查、26 个日志合成场景、控制器七个模拟场景通过；arm64 与 arm64e 构建、每切片 62 个签名页及包身份/元数据检查通过，未加入维护脚本。arm64e 保留对象 ABI 链接警告仍存在。尚未用设备验证 QX 对新任务行的解析及脚本实际执行。

## 设备测试步骤

1. 包管理器覆盖安装 1.1.38，确认版本标记为 `1.1.38`；完全退出后重开 Quantumult X。不要删除或改名任何现有脚本。
2. 从关闭状态只打开一次 QXAS 主开关，不点“立即应用”。若弹错，截下完整行号和语法报错。
3. 回传同次日志中版本、`QXAS task source normalized to Documents/QXAS-Scripts/qxas-controller.js`、wrapper 状态、候选数、Engine 返回与配置读回长度。
4. 若配置解析成功，等待任务触发并确认行为；若无报错但未切换，再据 43 个候选及节点健康结果定位。之后单独关闭一次并确认配置回到原始长度/原生状态。不要发送配置正文。