#!/usr/bin/env python3
"""Build the text-only QXAS 1.1.25 upgrade from the pinned 1.1.24 DEB."""
import argparse
import gzip
import hashlib
import io
from pathlib import Path
import struct
import tarfile

BASELINE = '15d3ac1988a69b9158c2f7f605bb683be87cb6826b895b5b21a157f59f43dbdc'
OLD_VERSION = '1.1.24'
NEW_VERSION = '1.1.25'
DYLIB = 'Library/MobileSubstrate/DynamicLibraries/QXAS.dylib'
PLIST = DYLIB.removesuffix('.dylib') + '.plist'
TEXT = (
    ('无法在隐根创建备份，未修改 QX 配置：%@', '无法创建该配置备份，未修改 QX 配置：%@'),
    ('隐根备份失败，未修改 QX 配置：%@', '本地备份失败，未修改 QX 配置：%@'),
    ('隐根备份校验失败，未修改 QX 配置', '本地备份校验失败，未修改 QX 配置'),
    ('配置操作失败：隐根备份失败，未修改配置', '配置操作失败：本地备份失败，未修改配置'),
    ('无法创建隐根 Scripts 目录（%@ %ld）', '无法创建沙盒 Scripts 目录（%@ %ld）'),
    ('隐根 Scripts 目录不可写或未通过路径检查', '沙盒 Scripts 目录不可写或未通过路径检查'),
    ('控制器脚本路径未通过隐根检查', '控制器脚本路径未通过沙盒检查'),
    ('控制器脚本已写入当前隐根', '控制器脚本已写入应用沙盒'),
    ('脚本模式失败：隐根备份失败，未修改配置', '脚本模式失败：本地备份失败，未修改配置'),
)


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def u32(data, at, order='>'):
    return struct.unpack_from(order + 'I', data, at)[0]


def unpack_ar(package):
    require(package.startswith(b'!<arch>\n'), 'not an ar archive')
    members, pos = {}, 8
    while pos < len(package):
        header = package[pos:pos + 60]
        require(len(header) == 60 and header[58:] == b'\x60\n', 'bad ar header')
        name = header[:16].strip().rstrip(b'/').decode('ascii')
        length = int(header[48:58])
        start, end = pos + 60, pos + 60 + length
        require(name not in members and 0 <= length <= len(package) - start, 'bad ar member')
        members[name] = package[start:end]
        pos = end + (length % 2)
    require(pos == len(package), 'bad ar alignment')
    require(list(members) == ['debian-binary', 'control.tar.gz', 'data.tar.gz'], 'unexpected package members')
    require(members['debian-binary'] == b'2.0\n', 'unexpected debian format')
    return members


def pack_ar(members):
    out = bytearray(b'!<arch>\n')
    for name, payload in members.items():
        out += f'{name:<16}{0:<12}{0:<6}{0:<6}{"100644":<8}{len(payload):<10}'.encode('ascii') + b'\x60\n'
        out += payload
        if len(payload) % 2:
            out += b'\n'
    return bytes(out)


def tar_entries(payload):
    with tarfile.open(fileobj=io.BytesIO(payload), mode='r:gz') as archive:
        rows = []
        for member in archive:
            require(member.isfile() or member.isdir(), 'unexpected tar entry type')
            value = archive.extractfile(member).read() if member.isfile() else None
            rows.append((member, value))
    return rows


def patch_tar(payload, rows):
    buf = bytearray(gzip.decompress(payload))
    for member, value in rows:
        if value is not None:
            start = member.offset_data
            require(len(value) == member.size and start + len(value) <= len(buf), 'tar member size changed')
            buf[start:start + len(value)] = value
    return gzip.compress(buf, compresslevel=9, mtime=0)


def read_macho(image):
    require(u32(image, 0, '<') == 0xFEEDFACF and u32(image, 12, '<') == 6, 'not a 64-bit Mach-O dylib')
    end = 32 + u32(image, 20, '<')
    pos, sections, signature = 32, {}, None
    require(end <= len(image), 'bad Mach-O command region')
    for _ in range(u32(image, 16, '<')):
        cmd, size = struct.unpack_from('<II', image, pos)
        require(8 <= size <= end - pos, 'bad load command')
        if cmd == 0x19:
            n = u32(image, pos + 64, '<')
            require(size == 72 + 80 * n, 'bad section table')
            for j in range(n):
                at = pos + 72 + 80 * j
                name = bytes(image[at:at + 16]).split(b'\0', 1)[0]
                seg = image[at + 16:at + 32].split(b'\0', 1)[0]
                if seg == b'__TEXT' and name in (b'__cstring', b'__ustring', b'__text'):
                    start = u32(image, at + 48, '<')
                    length = struct.unpack_from('<Q', image, at + 40)[0]
                    require(name not in sections and end <= start <= start + length <= len(image), 'bad text section')
                    sections[name] = (start, start + length)
        elif cmd == 0x1D:
            require(signature is None and size == 16, 'bad signature command')
            signature = struct.unpack_from('<II', image, pos + 8)
        pos += size
    require(pos == end and len(sections) == 3 and signature is not None, 'incomplete Mach-O metadata')
    return sections, signature


def code_slots(image, signature):
    start, size = signature
    require(start + size == len(image), 'unexpected signature range')
    magic, length, count = struct.unpack_from('>III', image, start)
    require(magic == 0xFADE0CC0 and 12 + count * 8 <= length <= size, 'bad signature SuperBlob')
    blobs = {}
    for i in range(count):
        slot, offset = struct.unpack_from('>II', image, start + 12 + i * 8)
        require(slot not in blobs and 12 + count * 8 <= offset <= length - 8, 'bad signature index')
        kind, n = struct.unpack_from('>II', image, start + offset)
        require(8 <= n <= length - offset, 'bad signature blob')
        blobs[slot] = (kind, start + offset, n)
    require(set(blobs) == {0, 2}, 'unexpected signature blobs (CMS/alternate/entitlement not supported)')
    magic, at, n = blobs[0]
    version, hash_offset, special, count, limit = (u32(image, at + i) for i in (8, 16, 24, 28, 32))
    require(magic == 0xFADE0C02 and version == 0x20400 and image[at + 36:at + 38] == b'\x20\x02', 'unexpected CodeDirectory')
    require(image[at + 39] == 12 and u32(image, at + 44) == 0 and limit == start, 'unexpected page layout')
    require(special == 2 and 88 <= hash_offset - special * 32 and hash_offset + count * 32 <= n, 'bad slot table')
    req_magic, req_at, req_len = blobs[2]
    require(req_magic == 0xFADE0C01 and image[at + hash_offset - 64:at + hash_offset - 32] == hashlib.sha256(image[req_at:req_at + req_len]).digest(), 'requirements hash mismatch')
    require(count == (limit + 4095) // 4096, 'bad code slot count')
    slots = [(at + hash_offset + i * 32, i * 4096, min((i + 1) * 4096, limit)) for i in range(count)]
    return slots


def patch_slice(image, *, new_version=None):
    sections, signature = read_macho(image)
    slots = code_slots(image, signature)
    for slot, lo, hi in slots:
        require(image[slot:slot + 32] == hashlib.sha256(image[lo:hi]).digest(), 'original code slot hash mismatch')
    out = bytearray(image)
    allowed = set()

    def replace(old, new, section, encoding, count, terminated=False):
        before, after = old.encode(encoding), new.encode(encoding)
        require(len(before) == len(after), f'non-equal replacement: {old}')
        lo, hi = sections[section]
        offsets, cursor = [], lo
        while (pos := image.find(before, cursor, hi)) >= 0:
            if encoding != 'utf-16le' or (pos - lo) % 2 == 0:
                if terminated:
                    width = 2 if encoding == 'utf-16le' else 1
                    zero = b'\0' * width
                    require(image[pos - width:pos] == zero and image[pos + len(before):pos + len(before) + width] == zero, 'replacement is not a complete string')
                offsets.append(pos)
            cursor = pos + 1
        require(len(offsets) == count, f'wrong occurrence count: {old}: {offsets}')
        for pos in offsets:
            window = set(range(pos, pos + len(before)))
            require(not allowed.intersection(window), 'overlapping replacement')
            out[pos:pos + len(before)] = after
            allowed.update(window)

    for old, new in TEXT:
        replace(old, new, b'__ustring', 'utf-16le', 1, terminated=True)
    version = NEW_VERSION if new_version is None else new_version
    replace(OLD_VERSION, version, b'__cstring', 'ascii', 1, terminated=True)
    replace(OLD_VERSION, version, b'__ustring', 'utf-16le', 4)
    refreshed = 0
    for slot, lo, hi in slots:
        digest = hashlib.sha256(out[lo:hi]).digest()
        if out[slot:slot + 32] != digest:
            out[slot:slot + 32] = digest
            allowed.update(range(slot, slot + 32))
            refreshed += 1
    require(refreshed > 0, 'no CodeDirectory page hashes changed')
    require(read_macho(out) == (sections, signature), 'Mach-O layout changed')
    require(code_slots(out, signature) == slots, 'signature layout changed')
    require(all(out[slot:slot + 32] == hashlib.sha256(out[lo:hi]).digest() for slot, lo, hi in slots), 'new code slot hash mismatch')
    require(all(before == after or i in allowed for i, (before, after) in enumerate(zip(image, out))), 'unexpected binary change')
    return bytes(out), refreshed


def patch_fat(fat, *, new_version=None):
    require(u32(fat, 0) == 0xCAFEBABE and u32(fat, 4) == 2, 'expected a two-slice 32-bit fat header')
    out, expected = bytearray(fat), ((0x0100000C, 0), (0x0100000C, 2))
    last = 48
    for i, arch in enumerate(('arm64', 'arm64e')):
        cpu, sub, start, size, align = struct.unpack_from('>IIIII', fat, 8 + i * 20)
        require((cpu, sub & 0xFFFFFF) == expected[i] and align < 32 and start % (1 << align) == 0, 'unexpected fat architecture')
        require(last <= start and size > 0 and start + size <= len(fat), 'bad fat extent')
        image = fat[start:start + size]
        require((u32(image, 4, '<'), u32(image, 8, '<') & 0xFFFFFF) == expected[i], 'slice header disagrees with fat header')
        patched, refreshed = patch_slice(image, new_version=new_version)
        out[start:start + size] = patched
        last = start + size
        print(f'{arch}: 9 message replacements, 5 version replacements, {refreshed} code page hashes refreshed')
    return bytes(out)


def name_of(member):
    return member.name.removeprefix('./')


def build(package):
    require(hashlib.sha256(package).hexdigest() == BASELINE, 'input must be the verified 1.1.24 baseline DEB')
    ar = unpack_ar(package)
    control_rows = tar_entries(ar['control.tar.gz'])
    require([name_of(m) for m, _ in control_rows if m.isfile()] == ['control'], 'unexpected control files (hooks are not allowed)')
    new_control = []
    for m, value in control_rows:
        if m.isfile():
            require(b'Package: com.mikehuang01.qxas2\n' in value and b'Architecture: iphoneos-arm64e\n' in value, 'wrong package identity')
            old = f'Version: {OLD_VERSION}\n'.encode()
            require(value.count(old) == 1, 'wrong package version')
            value = value.replace(old, f'Version: {NEW_VERSION}\n'.encode())
        new_control.append((m, value))
    rows = tar_entries(ar['data.tar.gz'])
    require(sorted(name_of(m) for m, _ in rows if m.isfile()) == sorted((DYLIB, PLIST)), 'unexpected payload files')
    new_rows = [(m, patch_fat(v) if name_of(m) == DYLIB else v) for m, v in rows]
    output = dict(ar)
    output['control.tar.gz'] = patch_tar(ar['control.tar.gz'], new_control)
    output['data.tar.gz'] = patch_tar(ar['data.tar.gz'], new_rows)
    result = pack_ar(output)
    for archive, original, expected_rows in (('control.tar.gz', control_rows, new_control), ('data.tar.gz', rows, new_rows)):
        reread = tar_entries(unpack_ar(result)[archive])
        require(len(reread) == len(original), 'entry count changed')
        for (m, value), (old, _), (_, expected_value) in zip(reread, original, expected_rows):
            require(m.get_info() == old.get_info() and value == expected_value, f'archive round trip changed {m.name}')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('baseline', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    try:
        result = build(args.baseline.read_bytes())
        args.output.parent.mkdir(parents=True, exist_ok=True)
        with args.output.open('xb') as f:
            f.write(result)
    except (ValueError, OSError, struct.error, tarfile.TarError) as error:
        parser.exit(1, f'build failed: {error}\n')
    print(f'{args.output}: {len(result)} bytes SHA256 {hashlib.sha256(result).hexdigest()}')


if __name__ == '__main__':
    main()
